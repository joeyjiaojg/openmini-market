#!/usr/bin/env bash
# 一键构建血战到底小盒子应用包：esbuild 打包 + make-pkg 出 zip
set -e
cd "$(dirname "$0")"

# 1) ES modules -> 单文件 IIFE（WebView 兼容）
npx --yes esbuild src/js/page/play-or-watch.js \
  --bundle --format=iife --outfile=src/js/game-bundle.js

# 2) 打小盒子 zip
version=$(python -c "import json;print(json.load(open('manifest.json', encoding='utf-8'))['version'])")
python ../tools/make-pkg.py . -o "mahjong-v${version}.zip"

echo "构建完成: mahjong-v${version}.zip"
