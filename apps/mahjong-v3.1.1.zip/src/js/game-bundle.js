(() => {
  // src/js/core/utils/math.js
  var max = Math.max;
  var random = (v) => v ? Math.random() * v | 0 : Math.random();

  // src/js/core/utils/prng.js
  function Random(seed) {
    this._seed = seed ? seed % 2147483647 : random(2147483647);
    console.log(`using initial random seed ${this._seed}`);
    if (this._seed <= 0) this._seed += 2147483646;
  }
  Random.prototype.seed = function(v) {
    if (v) this._seed = v;
    return this._seed;
  };
  var rollCount = 0;
  Random.prototype.next = function() {
    rollCount++;
    return this.seed(this._seed * 16807 % 2147483647);
  };
  Random.prototype.nextFloat = function(opt_minOrMax, opt_max) {
    return (this.next() - 1) / 2147483646;
  };

  // src/js/core/utils/logger.js
  var playlog = {
    lines: [],
    prefix: () => `${Date.now()}: `,
    log: (text) => {
      if (typeof text !== "string") text = text.toString();
      text.split("\n").forEach((line) => {
        playlog.lines.push(`${playlog.prefix()}${line}`);
      });
    },
    flush: () => {
      if (config.WRITE_GAME_LOG) {
        let text = playlog.lines.slice().join("\n");
        playlog.openTab(text);
      }
      playlog.lines = [];
    },
    openTab: (text) => {
      let a = document.createElement(`a`);
      a.target = `_blank`;
      a.href = `data:text/plain;charset=utf-8,${encodeURIComponent(text)}`;
      a.style.display = `none`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  // src/js/core/scoring/limit-hands.js
  var LimitHands = class {
    /**
     * Check for thirteen orphans:
     *
     * The 1 and 9 of each suit, once; each wind
     * and dragon, once; a pairing tile for any.
     */
    hasThirteenOrphans(tiles) {
      let thirteen = [0, 8, 9, 17, 18, 26, 27, 28, 29, 30, 31, 32, 33];
      thirteen.forEach((t) => {
        let pos = tiles.indexOf(t);
        if (pos > -1) tiles.splice(pos, 1);
      });
      return tiles.length === 1 && thirteen.indexOf(tiles[0]) > -1;
    }
    /**
     * Check for nine gates:
     *
     * 1,1,1, 2,3,4,5,6,7,8, 9,9,9, and a
     * pairing tile for any. All same suit.
     */
    hasNineGates(tiles, lockedSize) {
      if (lockedSize > 2) return false;
      if (tiles.some((t) => t >= 27)) return false;
      let suit = tiles[0] / 9 | 0;
      if (tiles.some((t) => (t / 9 | 0) !== suit)) return false;
      let offset = suit * 9;
      let nine = [0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 8, 8].map((t) => t + offset);
      nine.forEach((t) => {
        let pos = tiles.indexOf(t);
        if (pos > -1) tiles.splice(pos, 1);
      });
      return tiles.length === 1 && offset < tiles[0] && tiles[0] < offset + 8;
    }
  };

  // src/js/core/scoring/faan-laak-table.js
  var FaakLaakTable = class {
    constructor(no_point_score = 0, limits) {
      this.no_point_score = no_point_score;
      this.limits = limits;
      this.generateConversionTable();
    }
    generateConversionTable() {
      let faan;
      this.table = {};
      let limits = this.limits;
      this.table[0] = this.no_point_score;
      for (faan = 1; faan < limits[0]; faan++) this.table[faan] = 2 ** faan;
      let laak = faan;
      for (let i = 0, e = limits.length - 1; i < e; i++) {
        let limit_s = limits[i];
        let limit_e = limits[i + 1];
        for (let j = limit_s; j < limit_e; j++) this.table[j] = 2 ** laak;
        laak++;
      }
      this.table[limits.slice(-1)] = 2 ** laak;
    }
    get(points, selfdraw, limit) {
      let highest_limit = this.limits.slice(-1);
      if (limit || points >= highest_limit) return this.table[highest_limit];
      return this.table[points];
    }
  };

  // src/js/core/algorithm/hash-printing.js
  function hash(set) {
    let s = `${set.type}`;
    if (set.subtype) {
      s = `${s}s${set.subtype}`;
    }
    if (set.type === Constants.PAIR || set.type === Constants.CHOW) {
      s = `${s}t${set.tile}`;
    }
    return s;
  }
  function unhash2(print, tile) {
    let re = /(\d+)(s(-?\d+))?(t(\d+))?/;
    let m = print.match(re);
    let type = parseInt(m[1]);
    let subtype = m[3] ? parseInt(m[3]) : void 0;
    let required = tile;
    if (type === Constants.CHOW) tile -= subtype;
    let obj = { required, type, subtype, tile };
    return obj;
  }

  // src/js/core/algorithm/pattern-set.js
  var PatternSet = class _PatternSet {
    static from(hash2) {
      return new _PatternSet(unhash(hash2));
    }
    static fromTiles(tiles, locked, concealed) {
      if (typeof tiles[0] !== "number") tiles = tiles.map((t) => t.getTileFace());
      let type = "";
      let tile = tiles[0];
      if (tiles.length === 4) type = "kong";
      if (tiles.length === 3) {
        if (tiles[1] === tile) type = "pung";
        else type = "chow";
      }
      if (tiles.length === 2) type = "pair";
      if (tiles.length === 1) type = "single";
      return new _PatternSet(type, tile, locked, concealed);
    }
    constructor(type, tilenumber2, locked, concealed) {
      if (tilenumber2 === void 0) {
        this.content = type;
      } else {
        this.type = type;
        this.tilenumber = tilenumber2;
        this.locked = locked;
        this.concealed = concealed;
      }
    }
    getSetID() {
      let t = this.type;
      let asLocked = this.locked && !this.concealed;
      if (t === `kong`) return `4k-${this.tilenumber}-${asLocked ? `!` : ``}`;
      if (t === `pung`) return `3p-${this.tilenumber}-${asLocked ? `!` : ``}`;
      if (t === `chow`) return `3c-${this.tilenumber}-${asLocked ? `!` : ``}`;
      if (t === `pair`) return `2p-${this.tilenumber}-${asLocked ? `!` : ``}`;
      if (t === `single`) return `1s-${this.tilenumber}`;
      return "0n";
    }
    tiles() {
      let t = this.type, n = this.tilenumber;
      if (t === "kong") return [n, n, n, n];
      if (t === "pung") return [n, n, n];
      if (t === "chow") return [n, n + 1, n + 2];
      if (t === "pair") return [n, n];
      if (t === "single") return [n];
      return [];
    }
    size() {
      let t = this.type;
      if (t === "kong") return 4;
      if (t === "pung") return 3;
      if (t === "chow") return 3;
      if (t === "pair") return 2;
      if (t === "single") return 1;
      return 0;
    }
    equals(other) {
      return this.type === other.type && this.tilenumber === other.tilenumber;
    }
    // String parity
    split(...args) {
      return this.toString().split(...args);
    }
    indexOf(...args) {
      return this.toString().indexOf(...args);
    }
    valueOf() {
      return this.content ? this.content.valueOf() : this.getSetID();
    }
    toString() {
      return this.content ? this.content.toString() : this.getSetID();
    }
  };

  // src/js/core/algorithm/pattern.js
  var Pattern = class _Pattern {
    constructor(tiles = []) {
      this.keys = [];
      this.tiles = {};
      tiles.slice().sort((a, b) => a - b).forEach((v) => {
        if (this.tiles[v] === void 0) {
          this.tiles[v] = 0;
        }
        this.tiles[v]++;
        this.keys.push(v);
      });
    }
    /**
     * a factory version of a copy constructor
     */
    copy() {
      let p = new _Pattern([], this.canChow);
      p.keys = this.keys.slice();
      p.keys.forEach((k) => p.tiles[k] = this.tiles[k]);
      return p;
    }
    /**
     * Remove a set of tiles from this pattern. If this
     * causes the number of tiles for a specific tile
     * face to reach 0, remove that tile from the tile set.
     */
    remove(tiles) {
      if (!tiles.forEach) tiles = [tiles];
      tiles.forEach((t) => {
        this.tiles[t]--;
        if (this.tiles[t] === 0) {
          delete this.tiles[t];
          this.keys = Object.keys(this.tiles).sort((a, b) => a - b);
        }
      });
    }
    /**
     * utility function to get the suit for an (assumed suited) tile.
     */
    getSuit(tile) {
      return tile / 9 | 0;
    }
    /**
     * utility function for confirming a specific tile is of a specific suit.
     */
    matchSuit(tile, suit) {
      return this.getSuit(tile) === suit;
    }
    /**
     * This lets us know whether or not there are a entries for [tile+1]
     * and [tile+2] in this hand, which lets us make decisions around whether
     * chows are a valid play strategy or not.
     */
    getChowInformation(tile) {
      let suit = tile / 9 | 0;
      let t1 = this.tiles[tile + 1];
      if (t1 !== void 0 && !this.matchSuit(tile + 1, suit)) t1 = void 0;
      let t2 = this.tiles[tile + 2];
      if (t2 !== void 0 && !this.matchSuit(tile + 2, suit)) t2 = void 0;
      let t3 = this.tiles[tile + 3];
      if (t3 !== void 0 && !this.matchSuit(tile + 3, suit)) t3 = void 0;
      return { t1, t2, t3, suit };
    }
    /**
     * mark tile as needed to form a set
     */
    markNeeded(results, tile, claimtype, subtype = void 0) {
      if (!results[tile]) results[tile] = [];
      let print = hash({ type: claimtype, tile, subtype });
      if (results[tile].indexOf(print) === -1) results[tile].push(print);
    }
    /**
     * add a set's hashprint to the list of winpath results
     */
    markWin(results, tile, subtype) {
      this.markNeeded(results, tile, Constants.WIN, subtype);
    }
    /**
     * The recursion function for `expand`, this function checks whether
     * a given count combination of singles, pairs, and sets constitutes a
     * winning combination (e.g. 4 sets and a pair is a winning path, but
     * seven singles and two pairs definitely isn't!)
     */
    recurse(seen, chain, to_remove, results, singles, pairs, sets) {
      let downstream = this.copy();
      downstream.remove(to_remove);
      if (downstream.keys.length > 0) {
        return downstream.runExpand(seen, chain, results, singles, pairs, sets);
      }
      if (sets.length === 4 && pairs.length === 1 && singles.length === 0) {
        if (!results.win) results.win = [];
        results.win.push({
          pair: pairs,
          sets
        });
      } else if (sets.length === 4 && pairs.length === 0 && singles.length === 1) {
        this.markWin(results, singles[0], Constants.PAIR);
      } else if (sets.length === 3 && pairs.length === 2) {
        this.markWin(results, pairs[0], Constants.PUNG);
        this.markWin(results, pairs[1], Constants.PUNG);
      } else if (sets.length === 3 && pairs.length === 1 && singles.length === 2) {
        if (singles[1] < 27 && singles[0] + 1 === singles[1]) {
          let t1 = singles[0] - 1, s1 = this.getSuit(t1), b0 = singles[0], s2 = this.getSuit(b0), b1 = singles[1], s3 = this.getSuit(b1), t2 = singles[1] + 1, s4 = this.getSuit(t2);
          if (s1 === s2 && s1 === s3) this.markWin(results, t1, Constants.CHOW1);
          if (s4 === s2 && s4 === s3) this.markWin(results, t2, Constants.CHOW3);
        } else if (singles[1] < 27 && singles[1] === singles[0] + 2) {
          let middle = singles[0] + 1;
          let s1 = this.getSuit(singles[0]);
          let s2 = this.getSuit(middle);
          let s3 = this.getSuit(singles[1]);
          if (s1 === s3 && s1 === s2) this.markWin(results, middle, Constants.CHOW2);
        }
      }
    }
    /**
     * Determine which set compositions are possible with the current
     * list of tiles. Specifically, which count combination of singles,
     * pairs, and sets can we make with these tiles?
     */
    runExpand(seen = [], paths = [], results = [], singles = [], pairs = [], sets = []) {
      if (!this.keys.length) {
        if (sets.length === 4 && pairs.length === 1 && singles.length === 0) {
          if (!results.win) results.win = [];
          results.win.push({
            pair: pairs,
            sets
          });
        }
        return { results, paths };
      }
      seen = seen.slice();
      let tile = this.keys[0] | 0;
      seen.push(tile);
      let count = this.tiles[tile];
      let head = [];
      let toRemove = [];
      if (count > 3) {
        head = [new PatternSet(`kong`, tile)];
        paths.push(head);
        toRemove = [tile, tile, tile, tile];
        this.recurse(seen, head, toRemove, results, singles, pairs, sets.concat(head));
      }
      if (count > 2) {
        head = [new PatternSet(`pung`, tile)];
        paths.push(head);
        toRemove = [tile, tile, tile];
        this.markNeeded(results, tile, Constants.KONG);
        this.recurse(seen, head, toRemove, results, singles, pairs, sets.concat(head));
      }
      if (count > 1) {
        head = [new PatternSet(`pair`, tile)];
        paths.push(head);
        toRemove = [tile, tile];
        this.markNeeded(results, tile, Constants.PUNG);
        this.recurse(seen, head, toRemove, results, singles, pairs.concat([tile]), sets);
      }
      this.recurse(seen, paths, [tile], results, singles.concat([tile]), pairs, sets);
      if (tile > 26) return { results, paths };
      let { t1, t2, t3 } = this.getChowInformation(tile);
      if (t1 || t2) {
        let suit = this.getSuit(tile);
        if (t1 && t2) {
          head = [new PatternSet(`chow`, tile)];
          paths.push(head);
          toRemove = [tile, tile + 1, tile + 2];
          if (t3) {
            this.markNeeded(results, tile + 1, Constants.CHOW1);
            this.markNeeded(results, tile + 2, Constants.CHOW3);
          }
          if (seen.indexOf(tile - 1) === -1) {
            if (this.matchSuit(tile - 1, suit)) this.markNeeded(results, tile - 1, Constants.CHOW1);
          }
          this.recurse(seen, head, toRemove, results, singles, pairs, sets.concat(head));
        } else if (t1) {
          if (this.matchSuit(tile + 2, suit)) this.markNeeded(results, tile + 2, Constants.CHOW3);
          if (seen.indexOf(tile - 1) === -1) {
            if (this.matchSuit(tile - 1, suit)) this.markNeeded(results, tile - 1, Constants.CHOW1);
          }
          this.recurse(seen, paths, [tile, tile + 1], results, singles, pairs, sets);
        } else {
          this.markNeeded(results, tile + 1, Constants.CHOW2);
          this.recurse(seen, paths, [tile, tile + 2], results, singles, pairs, sets);
        }
      }
      return { results, paths };
    }
    // Convenience function, so calling code doesn't need to know about
    // empty array instantiations for path/results/single
    expand(pair = [], set = []) {
      return this.copy().runExpand(
        [],
        // seen
        [],
        // paths
        [],
        // results
        [],
        // singles
        pair,
        set
      );
    }
  };

  // src/js/core/algorithm/tiles-needed.js
  function tilesNeeded(tiles, locked = []) {
    let p = new Pattern(tiles);
    locked = convertToPatternSets(locked);
    let pair = [];
    locked.some((set, pos) => {
      if (set.type === "pair") {
        pair.push(set);
        return locked.splice(pos, 1);
      }
    });
    let { results, paths } = p.expand(pair.map((s) => s.tilenumber), locked);
    let winpaths = (results.win || []).map((result) => {
      let p2 = pair[0];
      let rpair = new PatternSet("pair", result.pair[0]);
      return [p2 && p2.equals(rpair) ? p2 : rpair, ...result.sets];
    });
    let winner = winpaths.length > 0;
    delete results.win;
    let lookout = results;
    let waiting = !winner && lookout.some((list) => list.some((type) => type.indexOf("32") === 0));
    paths = paths.map((path) => unroll(path));
    let composed = getUniqueCompositions(paths);
    let to_complete = getStillNeeded(locked, composed);
    return { lookout, waiting, composed, to_complete, winner, winpaths };
  }
  function convertToPatternSets(locked) {
    return locked.map((set) => {
      let numbered = set.map((t) => t.getTileFace ? t.getTileFace() : t).sort();
      return PatternSet.fromTiles(numbered, true, set.concealed);
    }).filter((v) => v);
  }
  function getUniqueCompositions(paths) {
    let composed = [];
    paths.forEach((path) => path.forEach((part) => {
      if (composed.some((e) => e === part)) return;
      composed.push(part);
    }));
    composed.sort((a, b) => a.length - b.length);
    let filtered = [];
    for (let i = 0, e = composed.length; i < e; i++) {
      let allFound = false;
      let list = composed[i];
      for (let j = i + 1; j < e; j++) {
        let other = composed[j];
        allFound = list.every((part) => other.find((e2) => e2.equals(part)));
        if (allFound) break;
      }
      if (!allFound) filtered.push(list);
    }
    return filtered;
  }
  function getStillNeeded(locked, composed) {
    let pcount = 1, scount = 4;
    if (locked.length > 0) {
      locked.forEach((set) => {
        if (set.size() === 2) pcount--;
        else scount--;
      });
    }
    let to_complete = [];
    composed.forEach((composition, pos) => {
      let p = pcount, s = scount, list = [];
      composition.forEach((set) => {
        if (set.size() === 2) p--;
        else s--;
      });
      if (p > 0) list.push(Constants.PAIR);
      while (s-- > 0) list.push(Constants.SET);
      to_complete[pos] = list;
    });
    return to_complete;
  }

  // src/js/core/scoring/ruleset.js
  var Ruleset = class _Ruleset {
    // helper functions
    getWindTile(wind) {
      return 27 + wind;
    }
    ownFlower(tile, windTile) {
      return tile - 34 === windTile - 27;
    }
    ownSeason(tile, windTile) {
      return tile - 38 === windTile - 27;
    }
    allFlowers(bonus) {
      return [34, 35, 36, 37].every((t) => bonus.indexOf(t) > -1);
    }
    allSeasons(bonus) {
      return [38, 39, 40, 41].every((t) => bonus.indexOf(t) > -1);
    }
    constructor(scoretype, player_start_score, limit, points_for_winning, no_point_score, losers_settle_scores, east_doubles_up, selfdraw_pays_double, discard_pays_double, reverse_wind_direction, pass_on_east_win) {
      this.scoretype = scoretype;
      this.limits = new LimitHands();
      this.player_start_score = player_start_score;
      this.limit = limit;
      this.points_for_winning = points_for_winning;
      this.no_point_score = no_point_score;
      this.losers_settle_scores = losers_settle_scores;
      this.east_doubles_up = east_doubles_up;
      this.selfdraw_pays_double = selfdraw_pays_double;
      this.discard_pays_double = discard_pays_double;
      this.reverse_wind_direction = reverse_wind_direction;
      this.pass_on_east_win = pass_on_east_win;
      if (scoretype === _Ruleset.FAAN_LAAK) {
        this.limit = limit[0];
        this.faan_laak_limits = limit;
        this.setupFaanLaakTable(no_point_score, limit);
      }
    }
    /**
     * This is its own function, so that subclasses can override it with different values.
     */
    setupFaanLaakTable(no_point_score, limits) {
      this.faan_laak_table = new FaakLaakTable(no_point_score, limits);
    }
    /**
     * calculate the actual number of points awarded under point/double rules.
     */
    getPointsDoubleLimit() {
      return this.limit;
    }
    /**
     * calculate the actual number of points awarded under point/double rules.
     */
    getFaanLaakLimit(selfdraw) {
      return this.faan_laak_table.get(0, selfdraw, true);
    }
    /**
     * perform standard Faan conversion
     */
    convertFaan(points, selfdraw, limit) {
      return this.faan_laak_table.get(points, selfdraw, limit);
    }
    /**
     * perform points/doubles conversion
     */
    convertPoints(points, doubles) {
      if (!points && this.no_point_score) points = this.no_point_score;
      return points * 2 ** doubles;
    }
    /**
     * Limits may require faan/laak computation
     */
    getLimitPoints(selfdraw) {
      if (this.scoretype === _Ruleset.POINTS_DOUBLES) return this.getPointsDoubleLimit();
      if (this.scoretype === _Ruleset.FAAN_LAAK) return this.getFaanLaakLimit(selfdraw);
      console.error("unknown scoring type");
      return 0;
    }
    /**
     * The base ruleset covers two classic limit hands.
     */
    checkForLimit(allTiles, lockedSize) {
      if (allTiles.length < 14) return;
      const tiles = () => allTiles.slice().map((t) => t | 0).sort();
      if (this.limits.hasThirteenOrphans(tiles())) return `Thirteen orphans`;
      if (this.limits.hasNineGates(tiles(), lockedSize)) return `Nine gates`;
    }
    /**
     * Generate a limit hand object
     */
    generateLimitObject(limit, selfdraw) {
      return {
        limit,
        log: [`Limit hand: ${limit}`],
        score: 0,
        doubles: 0,
        total: this.getLimitPoints(selfdraw)
      };
    }
    /**
     * Turn basic tilescores into score adjustments, by running
     * the "how much does the winner get" and "how much do the
     * losers end up paying" calculations.
     */
    settleScores(scores, winningplayer, eastplayer, discardpid) {
      console.debug(`%cSettling payment`, `color: red`);
      let adjustments = [0, 0, 0, 0];
      let eastWinFactor = winningplayer === eastplayer ? 2 : 1;
      let wscore = scores[winningplayer].total;
      let selfdraw = discardpid === false;
      console.debug(`winning score: ${wscore}, double east? ${this.east_doubles_up}`);
      for (let i = 0; i < scores.length; i++) {
        if (i === winningplayer) continue;
        if (i !== winningplayer) {
          let difference = wscore;
          if (this.east_doubles_up) {
            let paysAsEast = i === eastplayer ? 2 : 1;
            difference *= Math.max(eastWinFactor, paysAsEast);
          }
          if (this.discard_pays_double && i === discardpid || this.selfdraw_pays_double && selfdraw) {
            difference *= 2;
          }
          adjustments[winningplayer] += difference;
          console.debug(`${winningplayer} gets ${difference} from ${i}`);
          adjustments[i] -= difference;
          console.debug(`${i} pays ${difference} to ${winningplayer}`);
        }
        if (!this.losers_settle_scores) continue;
        for (let j = i + 1; j < scores.length; j++) {
          if (j === winningplayer) continue;
          let difference = scores[i].total - scores[j].total;
          if (this.east_doubles_up) {
            let paysAsEast = i === eastplayer ? 2 : 1;
            difference *= paysAsEast;
          }
          console.debug(`${i} gets ${difference} from ${j}`);
          adjustments[i] += difference;
          console.debug(`${j} pays ${difference} to ${i}`);
          adjustments[j] -= difference;
        }
      }
      if (this.east_doubles_up) {
        if (winningplayer === eastplayer) scores[eastplayer].log.push(`Player won as East`);
        else scores[eastplayer].log.push(`Player lost as East`);
      }
      return adjustments;
    }
    // implemented by subclasses
    getPairValue() {
      return false;
    }
    getChowValue() {
      return false;
    }
    getPungValue() {
      return false;
    }
    getKongValue() {
      return false;
    }
    /**
     * ...docs go here...
     */
    _tile_score(set, windTile, windOfTheRoundTile) {
      let locked = set.locked;
      let concealed = set.concealed;
      let tiles = set.tiles();
      let tile = tiles[0];
      let names = config.TILE_NAMES;
      if (tiles.length === 2) return this.getPairValue(tile, locked, concealed, names, windTile, windOfTheRoundTile);
      if (tiles.length === 3) {
        if (tile !== tiles[1]) return this.getChowValue(tile, locked, concealed, names, windTile, windOfTheRoundTile);
        else return this.getPungValue(tile, locked, concealed, names, windTile, windOfTheRoundTile);
      }
      if (tiles.length === 4) return this.getKongValue(tile, locked, concealed, names, windTile, windOfTheRoundTile);
    }
    // implemented by subclasses
    checkBonusTilePoints(bonus, windTile, names, result) {
    }
    checkHandPatterns(scorePattern, windTile, windOfTheRoundTile, tilesLeft, result) {
    }
    checkWinnerHandPatterns(scorePattern, winset, selfdraw, windTile, windOfTheRoundTile, tilesLeft, scoreObject) {
    }
    // Aggregate all the points for individual sets into a single score object
    aggregateScorePattern(scorePattern, windTile, windOfTheRoundTile) {
      return scorePattern.map((set) => this._tile_score(set, windTile, windOfTheRoundTile)).filter((v) => v).reduce((t, v) => {
        t.score += v.score;
        t.doubles += v.doubles || 0;
        t.log = t.log.concat(v.log);
        return t;
      }, { score: 0, doubles: 0, log: [] });
    }
    /**
     * ...docs go here...
     */
    getTileScore(scorePattern, windTile, windOfTheRoundTile, bonus, winset, winner = false, selfdraw = false, selftile = false, robbed = false, tilesLeft) {
      let names = config.TILE_NAMES;
      let result = this.aggregateScorePattern(scorePattern, windTile, windOfTheRoundTile);
      result.wind = windTile;
      result.wotr = windOfTheRoundTile;
      this.checkBonusTilePoints(bonus, windTile, names, result);
      this.checkHandPatterns(scorePattern, windTile, windOfTheRoundTile, tilesLeft, result);
      if (winner) {
        if (this.points_for_winning > 0) {
          result.score += this.points_for_winning;
          result.log.push(`${this.points_for_winning} for winning`);
        }
        this.checkWinnerHandPatterns(scorePattern, winset, selfdraw, selftile, robbed, windTile, windOfTheRoundTile, tilesLeft, result);
      }
      if (result.limit) {
        result.score = this.limit;
        result.doubles = 0;
        result.total = this.limit;
        result.log.push(`Limit hand: ${result.limit}`);
      } else {
        result.total = 0;
        if (this.scoretype === _Ruleset.POINTS_DOUBLES) {
          result.total = this.convertPoints(result.score, result.doubles);
          if (result.total > this.limit) {
            result.log.push(`Score limited from ${result.total} to ${this.limit}`);
            result.total = this.limit;
          }
        }
        if (this.scoretype === _Ruleset.FAAN_LAAK) {
          result.total = this.convertFaan(result.score, selfdraw);
        }
      }
      return result;
    }
    /**
     * All possible flags and values necessary for performing scoring, used in checkWinnerHandPatterns
     */
    getState(scorePattern, winset, selfdraw, selftile, robbed, windTile, windOfTheRoundTile, tilesLeft) {
      let state = {
        chowhand: true,
        punghand: true,
        onesuit: true,
        honours: false,
        allhonours: true,
        terminals: true,
        allterminals: true,
        outonPair: true,
        pairTile: -1,
        majorPair: false,
        dragonPair: false,
        windPair: false,
        ownWindPair: false,
        wotrPair: false,
        ownWindPung: false,
        wotrPung: false,
        ownWindKong: false,
        wotrKong: false,
        chowCount: 0,
        windPungCount: 0,
        windKongCount: 0,
        dragonPungCount: 0,
        dragonKongCount: 0,
        concealedCount: 0,
        kongCount: 0,
        suit: false,
        selfdraw,
        robbed,
        lastTile: tilesLeft <= 0
      };
      state.allGreen = scorePattern.every((set) => set.tiles().every((t) => [1, 2, 3, 5, 7, 31].indexOf(t) > -1));
      let tiles, tile, tilesuit;
      scorePattern.forEach((set) => {
        if (!set.locked || set.concealed) state.concealedCount++;
        tiles = set.tiles();
        tile = tiles[0];
        tilesuit = tile / 9 | 0;
        if (tile < 27) {
          if (state.suit === false) state.suit = tilesuit;
          else if (state.suit !== tilesuit) state.onesuit = false;
          if (tiles.some((t) => t % 9 !== 0 && t % 9 !== 8)) {
            state.terminals = false;
            state.allterminals = false;
          }
          state.allhonours = false;
        } else {
          state.honours = true;
          state.allterminals = false;
        }
        if (tiles.length === 2) {
          if (winset) {
            let wintiles = winset.tiles();
            state.outonPair = wintiles.length === 2 && wintiles[0] === tiles[0];
            state.pairTile = wintiles[0];
          } else if (!winset && selfdraw && tiles[0] === selftile) {
            state.outonPair = true;
            state.pairTile = selftile;
          } else {
            state.outonPair = false;
            if (tile > 26 && tile < 31) {
              state.windPair = true;
              state.majorPair = true;
            }
            if (tile > 30) {
              state.dragonPair = true;
              state.majorPair = true;
            }
            if (tile === windTile) {
              state.ownWindPair = true;
              state.majorPair = true;
            }
            if (tile === windOfTheRoundTile) {
              state.wotrPair = true;
              state.majorPair = true;
            }
          }
        }
        if (tiles.length === 3) {
          if (tile === tiles[1]) {
            if (tile > 26 && tile < 31) {
              state.windPungCount++;
              if (tile === windTile) state.ownWindPung = true;
              if (tile === windOfTheRoundTile) state.wotrPung = true;
            }
            if (tile > 30) state.dragonPungCount++;
            state.chowhand = false;
          } else {
            state.chowCount++;
            state.punghand = false;
          }
        }
        if (tiles.length === 4) {
          state.kongCount++;
          if (tile > 26 && tile < 31) {
            state.windKongCount++;
            if (tile === windTile) state.ownWindKong = true;
            if (tile === windOfTheRoundTile) state.wotrKong = true;
          }
          if (tile > 30) state.dragonKongCount++;
          state.chowhand = false;
        }
      });
      return state;
    }
    /**
     * Scoring tiles means first seeing how many different
     * things can be formed with the not-revelead tiles,
     * and then for each of those things, calculate the
     * total hand score by adding in the locked tiles.
     *
     * Whichever combination of pattersn scores highest
     * is the score the player will be assigned.
     */
    scoreTiles(disclosure, id, windOfTheRound, tilesLeft) {
      console.debug("SCORE TILES", id, disclosure, windOfTheRound, tilesLeft);
      let winner = disclosure.winner;
      let selfdraw = disclosure.selfdraw;
      let selftile = disclosure.selftile ? disclosure.selftile.getTileFace() : false;
      let robbed = disclosure.robbed;
      let tiles = disclosure.concealed;
      let locked = disclosure.locked;
      let bonus = disclosure.bonus;
      let winset = false;
      let windTile = this.getWindTile(disclosure.wind);
      let windOfTheRoundTile = this.getWindTile(windOfTheRound);
      let allTiles = tiles.slice();
      locked = locked.map((set) => {
        if (set.length === 4) {
          let ccount = set.reduce((tally, t) => tally + (t.isConcealed() ? 1 : 0), 0);
          if (ccount >= 3) set.concealed = `${ccount}`;
        }
        return set;
      });
      let tileInformation = tilesNeeded(tiles, locked);
      let openCompositions = tileInformation.composed;
      locked = locked.map((set) => {
        let newset = PatternSet.fromTiles(set, true, set.concealed);
        allTiles.push(...set);
        if (!!set[0].isWinningTile()) winset = newset;
        return newset;
      });
      if (winner) {
        let limit = this.checkForLimit(allTiles, locked.reduce((t, s) => t + s.length, 0));
        if (limit) {
          config.log("limit hand");
          return this.generateLimitObject(limit, selfdraw);
        }
        openCompositions = tileInformation.winpaths;
      } else {
        if (!this.losers_settle_scores) {
          config.log("losers do not require score computation");
          return { score: 0, doubles: 0, log: [], total: 0 };
        }
        if (openCompositions.length === 0) openCompositions.push([]);
      }
      let possibleScores = openCompositions.map((chain) => {
        return this.getTileScore(
          chain.concat(winner ? [] : locked),
          windTile,
          windOfTheRoundTile,
          bonus,
          winset,
          winner,
          selfdraw,
          selftile,
          robbed,
          tilesLeft
        );
      });
      config.log("possible scores:", possibleScores);
      let finalScore = possibleScores.sort((a, b) => {
        a = a.total;
        b = b.total;
        return a - b;
      }).slice(-1)[0];
      config.log("final score:", finalScore);
      if (!finalScore) {
        disclosure.locked = disclosure.locked.map((set) => set.map((tile) => tile.values ? tile.values.tile : tile));
        console.log(disclosure);
        console.log(possibleScores);
        throw new Error("no score could be computed");
      }
      return finalScore;
    }
    /**
    * Determine how this hand could be improved
    */
    _determineImprovement(concealed, locked, composed, to_complete, tiletracker) {
      return [];
    }
    /**
     * ...docs go here...
     */
    determineImprovement(player, tilesLeft, winner = false) {
      let concealed = player.getTileFaces();
      let locked = player.locked;
      let data = this.scoreTiles({
        winner,
        wind: player.wind,
        concealed,
        locked,
        bonus: player.bonus
      }, player.id, player.windOfTheRound, tilesLeft);
      let { composed, to_complete } = player.tilesNeeded();
      data.improvement = this._determineImprovement(concealed, locked, composed, to_complete, player.tracker);
      return data;
    }
  };
  Ruleset.FAAN_LAAK = /* @__PURE__ */ Symbol();
  Ruleset.POINTS_DOUBLES = /* @__PURE__ */ Symbol();
  (() => {
    let rulesets = {};
    Ruleset.register = function(RulesetClass) {
      let naturalName = RulesetClass.name.replace(/([a-z])([A-Z])/g, (_, b, c) => `${b} ${c}`);
      rulesets[naturalName] = new RulesetClass();
    };
    Ruleset.getRuleset = (name) => rulesets[name];
    Ruleset.getRulesetNames = () => Object.keys(rulesets);
  })();

  // src/js/core/scoring/cantonese.js
  var Cantonese = class extends Ruleset {
    constructor() {
      super(
        Ruleset.FAAN_LAAK,
        500,
        // start score
        [5, 7, 10],
        // tiered limits
        0,
        // points for winning
        0.5,
        // no-point hand score
        false,
        // losers do not pay each other
        false,
        // east does not doubles up
        true,
        // selfdraw wins pay double
        true,
        // discarding player pays double
        true,
        // reverse wind direction
        true
        // deal passes when east wins
      );
    }
    /**
     * What are considered point-scoring pungs in this ruleset?
     */
    getPungValue(tile, locked, concealed, names, windTile, windOfTheRoundTile) {
      let prefix = locked && !concealed ? "" : "concealed ";
      if (tile > 26) {
        if (tile > 30) {
          return { score: 1, log: [`1 faan for ${prefix}pung of dragons (${names[tile]})`] };
        }
        let scoreObject = { score: 0, log: [] };
        if (tile === windTile) {
          scoreObject.score += 1;
          scoreObject.log.push(`1 faan for ${prefix}pung of player's own wind (${names[tile]})`);
        }
        if (tile === windOfTheRoundTile) {
          scoreObject.score += 1;
          scoreObject.log.push(`1 faan for ${prefix}pung of wind of the round (${names[tile]})`);
        }
        return scoreObject;
      }
    }
    /**
     * What are considered point-scoring kongs in this ruleset?
     */
    getKongValue(tile, locked, concealed, names, windTile, windOfTheRoundTile) {
      let prefix = locked && !concealed ? "" : "concealed ";
      if (tile > 26) {
        if (tile > 30) {
          return { score: 1, log: [`1 faan for ${prefix}kong of dragons (${names[tile]})`] };
        }
        let scoreObject = { score: 0, log: [] };
        if (tile === windTile) {
          scoreObject.score += 1;
          scoreObject.log.push(`1 faan for ${prefix}kong of player's own wind (${names[tile]})`);
        }
        if (tile === windOfTheRoundTile) {
          scoreObject.score += 1;
          scoreObject.log.push(`1 faan for ${prefix}kong of wind of the round (${names[tile]})`);
        }
        return scoreObject;
      }
    }
    /**
     * There are special points that any player can get
     * at the end of the hand. Calculate those here:
     */
    checkHandPatterns(scorePattern, windTile, windOfTheRoundTile, tilesLeft, scoreObject) {
      let r, g, w;
      scorePattern.forEach((set) => {
        let tile = set[0];
        if (tile === 31) g = set.length;
        if (tile === 32) r = set.length;
        if (tile === 33) w = set.length;
      });
      if (r + g + w >= 8 && (r === 2 || g === 2 || w === 2)) {
        scoreObject.score += 4;
        scoreObject.log.push(`4 faan for little three dragons`);
      }
    }
    /**
     * There are special points that you can only get
     * by winning the hand. Calculate those here:
     */
    checkWinnerHandPatterns(scorePattern, winset, selfdraw, selftile, robbed, windTile, windOfTheRoundTile, tilesLeft, scoreObject) {
      let names = config.TILE_NAMES;
      let suits = config.SUIT_NAMES;
      let state = this.getState(scorePattern, winset, selfdraw, selftile, robbed, windTile, windOfTheRoundTile, tilesLeft);
      if (state.selfdraw) {
        scoreObject.score += 1;
        scoreObject.log.push(`1 faan for self-drawn win (${names[selftile]})`);
      }
      if (state.robbed) {
        scoreObject.score += 1;
        scoreObject.log.push(`1 faan for robbing a kong (${names[winset[0]]})`);
      }
      if (state.chowhand && !state.majorPair) {
        scoreObject.score += 1;
        scoreObject.log.push(`1 faan for chow hand`);
      }
      if (state.onesuit) {
        if (state.honours) {
          scoreObject.score += 1;
          scoreObject.log.push(`1 faan for one suit (${suits[state.suit]}) and honours hand`);
        } else {
          scoreObject.score += 5;
          scoreObject.log.push(`5 faan for clean one suit hand (${suits[state.suit]})`);
        }
      }
      if (state.allterminals) {
        scoreObject.limit = `all terminals hand`;
      }
      if (state.allhonours) {
        scoreObject.limit = `all honours hand`;
      }
      if (state.punghand) {
        scoreObject.score += 3;
        scoreObject.log.push(`3 faan for all pung hand`);
      }
      if (state.dragonPungCount + state.dragonKongCount === 3) {
        scoreObject.limit = `Three great scholars (pung or kong of each dragon)`;
      }
      if (state.windPungCount + state.windKongCount === 3 && state.windPair) {
        scoreObject.limit = `Little four winds (pung or kong of three wind, pair of last wind)`;
      }
      if (state.windPungCount + state.windKongCount === 4) {
        scoreObject.limit = `Big four winds (pung or kong of each wind)`;
      }
      if (state.concealedCount === 5) {
        scoreObject.score += 1;
        scoreObject.log.push(`1 faan for fully concealed hand`);
      }
      if (scoreObject.score === 0) {
        scoreObject.log.push(`${this.no_point_score} for no-point hand`);
      }
    }
    /**
     * Award points based on bonus tiles.
     */
    checkBonusTilePoints(bonus, windTile, names, result) {
      let hasOwnFlower = false;
      let hasOwnSeason = false;
      bonus.forEach((tile) => {
        if (this.ownFlower(tile, windTile)) hasOwnFlower = true;
        if (this.ownSeason(tile, windTile)) hasOwnSeason = true;
      });
      if (bonus.length === 0) {
        result.score += 1;
        result.log.push(`1 faan for no flowers or seasons`);
      }
      if (hasOwnFlower) {
        result.score += 1;
        result.log.push(`1 faan for own flower and season`);
      }
      if (hasOwnSeason) {
        result.score += 1;
        result.log.push(`1 faan for own flower and season`);
      }
      if (this.allFlowers(bonus)) {
        result.score += 1;
        result.log.push(`1 faan for having all flowers`);
      }
      if (this.allSeasons(bonus)) {
        result.score += 1;
        result.log.push(`1 faan for having all seasons`);
      }
    }
  };
  Ruleset.register(Cantonese);

  // src/js/core/scoring/chinese-classical.js
  var ChineseClassical = class extends Ruleset {
    constructor() {
      super(
        Ruleset.POINTS_DOUBLES,
        2e3,
        // start score
        1e3,
        // single limit
        10,
        // 10 points for winning
        false,
        // no-point hand does not exist in this ruleset
        true,
        // losers pay each other
        true,
        // east doubles up
        false,
        // selfdraw wins do not pay double
        false,
        // discarding player does not pay double
        true,
        // reverse wind direction
        false
        // deal does not pass when east wins
      );
    }
    /**
     * What are considered point-scoring pairs in this ruleset?
     */
    getPairValue(tile, locked, concealed, names, windTile, windOfTheRoundTile) {
      if (tile > 30) return {
        score: 2,
        log: [`2 for pair of dragons (${names[tile]})`]
      };
      if (tile === windTile) return {
        score: 2,
        log: [`2 for pair of own wind (${names[tile]})`]
      };
      if (tile === windOfTheRoundTile) return {
        score: 2,
        log: [`2 for pair of wind of the round (${names[tile]})`]
      };
    }
    /**
     * What are considered point-scoring pungs in this ruleset,
     * and do those incur any doubles?
     */
    getPungValue(tile, locked, concealed, names, windTile, windOfTheRoundTile) {
      let prefix = locked && !concealed ? "" : "concealed ";
      let value = 0;
      if (tile > 30) {
        value = locked ? 4 : 8;
        return {
          score: value,
          doubles: 1,
          log: [
            `${value} for ${prefix}pung of dragons (${names[tile]})`,
            `1 double for pung of dragons (${names[tile]})`
          ]
        };
      }
      if (tile > 26) {
        value = locked ? 4 : 8;
        let scoreObject = {
          score: value,
          doubles: 0,
          log: [`${value} for ${prefix}pung of winds (${names[tile]})`]
        };
        if (tile === windTile) {
          scoreObject.doubles += 1;
          scoreObject.log.push(`1 double for pung of player's own wind (${names[tile]})`);
        }
        if (tile === windOfTheRoundTile) {
          scoreObject.doubles += 1;
          scoreObject.log.push(`1 double for pung of wind of the round (${names[tile]})`);
        }
        return scoreObject;
      }
      if (tile < 27) {
        let type;
        if (tile % 9 === 0 || tile % 9 === 8) {
          type = `terminals`;
          value = locked ? 4 : 8;
        } else {
          type = `simple`;
          value = locked ? 2 : 4;
        }
        return {
          score: value,
          log: [`${value} for ${prefix}pung of ${type} (${names[tile]})`]
        };
      }
    }
    /**
     * What are considered point-scoring kongs in this ruleset,
     * and do those incur any doubles?
     */
    getKongValue(tile, locked, concealed, names, windTile, windOfTheRoundTile) {
      let value = 0;
      let prefix = ``;
      let ccount = concealed;
      if (!ccount) prefix = `melded `;
      else if (ccount === 3) prefix = `claimed `;
      else if (ccount === 4) prefix = `concealed `;
      if (tile > 30) {
        value = locked || ccount === 3 ? 16 : 32;
        ;
        return {
          score: value,
          doubles: 1,
          log: [
            `${value} for ${prefix}kong of dragons (${names[tile]})`,
            `1 double for kong of dragons (${names[tile]})`
          ]
        };
      }
      if (tile > 26) {
        value = locked || ccount === 3 ? 16 : 32;
        let scoreObject = {
          score: value,
          doubles: 0,
          log: [`${value} for ${prefix}kong of winds (${names[tile]})`]
        };
        if (tile === windTile) {
          scoreObject.doubles += 1;
          scoreObject.log.push(`1 double for kong of player's own wind (${names[tile]})`);
        }
        if (tile === windOfTheRoundTile) {
          scoreObject.doubles += 1;
          scoreObject.log.push(`1 double for kong of wind of the round (${names[tile]})`);
        }
        return scoreObject;
      }
      if (tile < 27) {
        let type;
        if (tile % 9 === 0 || tile % 9 === 8) {
          type = `terminals`;
          value = locked || ccount === 3 ? 16 : 32;
        } else {
          type = `simple`;
          value = locked || ccount === 3 ? 8 : 16;
        }
        return {
          score: value,
          log: [`${value} for ${prefix}kong of ${type} (${names[tile]})`]
        };
      }
    }
    /**
     * There are special points and doubles that any player
     * can get at the end of the hand. Calculate those here:
     */
    checkHandPatterns(scorePattern, windTile, windOfTheRoundTile, tilesLeft, scoreObject) {
      let r, g, w;
      scorePattern.forEach((set) => {
        let tile = set[0];
        if (tile === 31) g = set.length;
        if (tile === 32) r = set.length;
        if (tile === 33) w = set.length;
      });
      if (r + g + w >= 8 && (r === 2 || g === 2 || w === 2)) {
        scoreObject.doubles += 1;
        scoreObject.log.push(`1 double for little three dragons`);
      }
    }
    /**
     * There are special points and doubles that you can only
     * get by winning the hand. Calculate those here:
     */
    checkWinnerHandPatterns(scorePattern, winset, selfdraw, selftile, robbed, windTile, windOfTheRoundTile, tilesLeft, scoreObject) {
      let names = config.TILE_NAMES;
      let suits = config.SUIT_NAMES;
      let state = this.getState(scorePattern, winset, selfdraw, selftile, robbed, windTile, windOfTheRoundTile, tilesLeft);
      if (state.selfdraw) {
        scoreObject.score += 2;
        scoreObject.log.push(`2 for self-drawn win (${names[selftile]})`);
      }
      if (state.robbed) {
        scoreObject.doubles += 1;
        scoreObject.log.push(`1 double for robbing a kong (${names[winset[0]]})`);
      }
      if (state.outonPair) {
        scoreObject.score += 2;
        scoreObject.log.push(`2 for winning on a pair (${names[state.pairTile]})`);
      }
      if (state.outonPair && state.majorPair) {
        scoreObject.score += 2;
        scoreObject.log.push(`2 for winning on a major pair`);
      }
      if (state.chowhand && !state.majorPair) {
        scoreObject.doubles += 1;
        scoreObject.log.push(`1 double for chow hand`);
      }
      if (state.onesuit) {
        if (state.honours) {
          scoreObject.doubles += 1;
          scoreObject.log.push(
            `1 double for one suit (${suits[state.suit]}) and honours hand`
          );
        } else {
          scoreObject.doubles += 3;
          scoreObject.log.push(`3 doubles for clean one suit hand (${suits[state.suit]})`);
        }
      }
      if (state.allterminals) {
        scoreObject.limit = `all terminals hand`;
      }
      if (state.allhonours) {
        scoreObject.limit = `all honours hand`;
      }
      if (state.terminals && state.honours) {
        scoreObject.doubles += 1;
        scoreObject.log.push(`1 double for terminals an honours hand`);
      }
      if (state.punghand) {
        scoreObject.doubles += 1;
        scoreObject.log.push(`1 double for all pung hand`);
      }
      if (state.kongCount === 4) {
        scoreObject.limit = `All kong hand`;
      }
      if (state.dragonPungCount + state.dragonKongCount === 3) {
        scoreObject.limit = `Three great scholars (pung or kong of each dragon)`;
      }
      if (state.windPungCount + state.windKongCount === 3 && state.windPair) {
        scoreObject.limit = `Little four winds (pung or kong of three wind, pair of last wind)`;
      }
      if (state.windPungCount + state.windKongCount === 4) {
        scoreObject.limit = `Big four winds (pung or kong of each wind)`;
      }
      if (state.concealedCount === 5) {
        scoreObject.doubles += 1;
        scoreObject.log.push(`1 double for fully concealed hand`);
      }
      if (state.concealedCount === 5 && state.punghand) {
        scoreObject.limit = `Fully concealed pung hand`;
      }
      if (state.lastTile) {
        scoreObject.doubles += 1;
        if (selfdraw) {
          scoreObject.log.push(
            `1 double for winning with the last available wall tile`
          );
        } else {
          scoreObject.log.push(`1 double for winning with the last discard`);
        }
      }
      if (state.allGreen) {
        scoreObject.limit = `"All Green" (bamboos 2, 3, 4, 6, 8 and/or green dragons)`;
      }
    }
    /**
     * Award points based on bonus tiles. A flat 4 points per
     * bonus, but Chinese classical also awards some doubles
     * based on having specific flowers/seasons.
     */
    checkBonusTilePoints(bonus, windTile, names, result) {
      let hasOwnFlower = false;
      let hasOwnSeason = false;
      bonus.forEach((tile) => {
        result.score += 4;
        result.log.push(`4 for bonus tile (${names[tile]})`);
        if (this.ownFlower(tile, windTile)) hasOwnFlower = true;
        if (this.ownSeason(tile, windTile)) hasOwnSeason = true;
      });
      if (hasOwnFlower && hasOwnSeason) {
        result.doubles += 1;
        result.log.push(`1 double for own flower and season`);
      }
      if (this.allFlowers(bonus)) {
        result.doubles += 2;
        result.log.push(`1 double for having all flowers`);
      }
      if (this.allSeasons(bonus)) {
        result.doubles += 2;
        result.log.push(`1 double for having all seasons`);
      }
    }
  };
  Ruleset.register(ChineseClassical);

  // src/js/core/scoring/sichuan.js
  var Sichuan = class extends Ruleset {
    constructor() {
      super(
        Ruleset.POINTS_DOUBLES,
        0,
        // starting score (relative)
        32,
        // fan cap
        0,
        // points for winning: handled by our own fan calculation
        false,
        // no-point hand does not exist
        false,
        // losers never settle amongst themselves
        false,
        // no east doubling
        false,
        // handled in processWinSichuan
        false,
        // handled in processWinSichuan
        false,
        // no reverse wind direction
        true
        // wind passes on every win
      );
      this.blood_battle = true;
      this.no_chow = true;
      this.missing_suit = true;
      this.base_points = 1;
    }
    /** Human-friendly names for the three suits (0 bamboo 条, 1 chars 万, 2 dots 筒). */
    getSuitName(suit) {
      return ["\u6761", "\u4E07", "\u7B52"][suit] || "?";
    }
    /**
     * Compute the fan value of a completed hand.
     * Used by Game.processWinSichuan for each winner.
     */
    scoreTiles(disclosure, id, windOfTheRound, tilesLeft) {
      if (!disclosure.winner) return { score: 0, doubles: 0, total: 0, log: [], fan: 0 };
      let concealed = disclosure.concealed.slice().filter((t) => t < 34);
      let locked = disclosure.locked || [];
      let kongCount = locked.filter((set) => set.length === 4).length;
      let faces = concealed.concat(
        ...locked.map((set) => set.map((t) => t.getTileFace ? t.getTileFace() : t))
      );
      let suits = new Set(faces.filter((t) => t < 27).map((t) => t / 9 | 0));
      let onesuit = suits.size === 1;
      let log = [];
      let fan = 0;
      let counts = new Array(34).fill(0);
      concealed.forEach((t) => counts[t]++);
      let sevenPairs = concealed.length === 14 && locked.length === 0 && counts.every((c) => c % 2 === 0);
      let dragonSeven = sevenPairs && counts.some((c) => c === 4);
      if (dragonSeven) {
        fan += 4;
        log.push("\u9F99\u4E03\u5BF9 4\u756A");
      } else if (sevenPairs) {
        fan += 2;
        log.push("\u4E03\u5BF9 2\u756A");
      } else {
        let { winpaths } = tilesNeeded(concealed, locked);
        let path = winpaths[0] || [];
        let sets = path.map((set) => {
          let tiles = set.tiles().map((t) => t.getTileFace ? t.getTileFace() : t);
          return { type: set.type, tiles };
        });
        let allPungs = sets.filter((s) => s.type === "pung" || s.type === "kong").length >= 3 && sets.every((s) => s.type !== "chow");
        if (allPungs) {
          fan += 2;
          log.push("\u5BF9\u5BF9\u80E1 2\u756A");
        } else {
          fan += 1;
          log.push("\u5E73\u80E1 1\u756A");
        }
      }
      if (onesuit) {
        fan += 4;
        log.push("\u6E05\u4E00\u8272 4\u756A");
      }
      if (kongCount) {
        fan += kongCount;
        log.push(`${kongCount}\u6839 ${kongCount}\u756A`);
      }
      if (tilesLeft <= 0) {
        fan += 1;
        log.push("\u6D77\u5E95\u635E\u6708 1\u756A");
      }
      fan = Math.min(fan, this.limit);
      return {
        score: fan,
        doubles: 0,
        total: fan,
        fan,
        log,
        limit: false,
        wind: 0,
        wotr: 0
      };
    }
    /**
     * Never let the generic ruleset award limit hands that need honour tiles.
     */
    checkForLimit(allTiles, lockedSize) {
      if (allTiles.length < 14) return;
      const tiles = allTiles.slice().map((t) => t | 0).sort();
      if (this.limits.hasNineGates(tiles, lockedSize)) return "\u4E5D\u83B2\u5B9D\u706F";
    }
    generateLimitObject(limit, selfdraw) {
      return {
        limit,
        log: [`${limit} 16\u756A`],
        score: 0,
        doubles: 0,
        fan: 16,
        total: 16,
        limitHand: true
      };
    }
  };
  Ruleset.register(Sichuan);

  // src/config.js
  var noop = () => {
  };
  var __console_debug = console.debug.bind(console);
  var DEFAULT_CONFIG = {
    // This flag needs no explanation
    DEBUG: false,
    // This flag also needs no explanation
    USE_SOUND: true,
    // The pseudo-random number generator seed.
    // This value lets us "replay" problematic
    // games to find out where things go wrong.
    SEED: 0,
    // The ruleset to play with.
    RULES: `Sichuan`,
    // This determines whether you get asked to
    // choose normal vs. automated play when you
    // load the page.
    PLAY_IMMEDIATELY: false,
    // Do not pause games when the page loses focus
    PAUSE_ON_BLUR: true,
    // Debugging around drawn hands requires
    // being able to force a draw
    FORCE_DRAW: false,
    // This determines whether we bypass the
    // separation of concern and force bots to
    // update the player's ui, even though they
    // normally would have no way to access it.
    FORCE_OPEN_BOT_PLAY: false,
    // Highlight discarded tiles if the human
    // player can claim them for something.
    SHOW_CLAIM_SUGGESTION: true,
    // Work play suggestions as determined by
    // the bot that underpins the human player
    // into the game UI.
    SHOW_BOT_SUGGESTION: true,
    // How likely are bots to go for chicken
    // hands, rather than for hands worth points?
    //
    // Set this to 1 to turn all bots into chickens!
    //
    // Set this to 0 to turn off chicken hands
    // (except when a bot goes into panic mode).
    //
    // Defaults to a roughly 1:72 chance to
    // chicken. Note that once panic mode sets in,
    // this value doubles with each check.
    BOT_CHICKEN_THRESHOLD: 8e-4,
    // The number of milliseconds the game
    // allows players to lay claim to a discard.
    // Bots need nowhere near this much, but
    // humans tend to need more than a few ms!
    CLAIM_INTERVAL: 5e3,
    // The number of milliseconds between
    // players taking their turn.
    PLAY_INTERVAL: 100,
    // The number of milliseconds pause
    // between playing "hands".
    HAND_INTERVAL: 3e3,
    // The number of milliseconds that
    // the bots will wait before putting
    // in their claim for a discard.
    // If this is 0, humans feel like they
    // are playing bots. Which they are.
    // But if this is a few hundred ms,
    // game play "Feel" more natural.
    BOT_DELAY_BEFORE_DISCARD_ENDS: 300,
    // When autoplay is enabled, how fast
    // should the bots play, for people to
    // be able to enjoy what's happening?
    BOT_PLAY_DELAY: 50,
    // Turning on wall hacks will set the wall
    // to very specific walls for debugging
    // purposes. This option simple fixes the
    // wall to a pattern on reset() so you can't
    // play a game if you use this. You just
    // get to debug a very specific situation.
    WALL_HACK: "",
    // Write the game log to disk, or to a new
    // tab as a text file.
    WRITE_GAME_LOG: false
  };
  var fromStorage = JSON.parse(localStorage.getItem("mahjongConfig") || "{}");
  var currentConfig = Object.assign(fromStorage, DEFAULT_CONFIG);
  var queryArgs = globalThis.location.search.replace(
    /([a-z_]+)=/g,
    (a, b) => b.toUpperCase() + "="
  );
  var params = new URLSearchParams(queryArgs);
  var urlConfig = Object.fromEntries(params.entries());
  currentConfig = Object.assign(currentConfig, urlConfig);
  for (const [key, value] of Object.entries(currentConfig)) {
    if (value === "true") currentConfig[key] = true;
    if (value === "false") currentConfig[key] = false;
    if (value == parseFloat(value)) currentConfig[key] = parseFloat(value);
  }
  console.log("playing with", currentConfig);
  if (currentConfig.WALL_HACK || currentConfig.PLAY_IMMEDIATELY) {
    currentConfig.FORCE_OPEN_BOT_PLAY = true;
    currentConfig.USE_SOUND = true;
  }
  var CLAIM2 = {
    IGNORE: 0,
    PAIR: 1,
    CHOW: 2,
    CHOW1: 4,
    // first tile in pattern: X**
    CHOW2: 5,
    // middle tile in pattern: *X*
    CHOW3: 6,
    // last time in pattern: **X
    PUNG: 8,
    KONG: 16,
    SET: 30,
    // masks 0b.0001.1110
    WIN: 32
  };
  var Constants = {
    PAIR: CLAIM2.PAIR,
    CHOW: CLAIM2.CHOW,
    CHOW1: CLAIM2.CHOW1,
    CHOW2: CLAIM2.CHOW2,
    CHOW3: CLAIM2.CHOW3,
    PUNG: CLAIM2.PUNG,
    KONG: CLAIM2.KONG,
    SET: CLAIM2.SET,
    WIN: CLAIM2.WIN
  };
  var TILE_NAMES = {
    0: "bamboo 1",
    1: "bamboo 2",
    2: "bamboo 3",
    3: "bamboo 4",
    4: "bamboo 5",
    5: "bamboo 6",
    6: "bamboo 7",
    7: "bamboo 8",
    8: "bamboo 9",
    9: "characters 1",
    10: "characters 2",
    11: "characters 3",
    12: "characters 4",
    13: "characters 5",
    14: "characters 6",
    15: "characters 7",
    16: "characters 8",
    17: "characters 9",
    18: "dots 1",
    19: "dots 2",
    20: "dots 3",
    21: "dots 4",
    22: "dots 5",
    23: "dots 6",
    24: "dots 7",
    25: "dots 8",
    26: "dots 9",
    27: "east",
    28: "south",
    29: "west",
    30: "north",
    31: "green dragon",
    32: "red dragon",
    33: "white dragon",
    34: "flower 1",
    35: "flower 2",
    36: "flower 3",
    37: "flower 4",
    38: "season 1",
    39: "season 2",
    40: "season 3",
    41: "season 4"
  };
  var TILE_GLYPHS = {
    0: "b1",
    // '🀐',
    1: "b2",
    // '🀑',
    2: "b3",
    // '🀒',
    3: "b4",
    // '🀓',
    4: "b5",
    // '🀔',
    5: "b6",
    // '🀕',
    6: "b7",
    // '🀖',
    7: "b8",
    // '🀗',
    8: "b9",
    // '🀘',
    9: "c1",
    // '🀇',
    10: "c2",
    // '🀈',
    11: "c3",
    // '🀉',
    12: "c4",
    // '🀊',
    13: "c5",
    // '🀋',
    14: "c6",
    // '🀌',
    15: "c7",
    // '🀍',
    16: "c8",
    // '🀎',
    17: "c9",
    // '🀏',
    18: "d1",
    // '🀙',
    19: "d2",
    // '🀚',
    20: "d3",
    // '🀛',
    21: "d4",
    // '🀜',
    22: "d5",
    // '🀝',
    23: "d6",
    // '🀞',
    24: "d7",
    // '🀟',
    25: "d8",
    // '🀠',
    26: "d9",
    // '🀡',
    27: "E",
    // '🀀',
    28: "S",
    // '🀁',
    29: "W",
    // '🀂',
    30: "N",
    // '🀃',
    31: "F",
    // '🀅',
    32: "C",
    // '🀄',
    33: "P",
    // '🀆',
    34: "f1",
    // '🀢',
    35: "f2",
    // '🀣',
    36: "f3",
    // '🀤',
    37: "f4",
    // '🀥',
    38: "s1",
    // '🀦',
    39: "s2",
    // '🀧',
    40: "s3",
    // '🀨',
    41: "s4"
    // '🀩'
  };
  var SUIT_NAMES = {
    0: "bamboo",
    1: "characters",
    2: "dots",
    3: "winds",
    4: "dragons",
    5: "bonus"
  };
  var config = Object.assign(
    {
      set: (opt) => {
        Object.keys(opt).forEach((key) => {
          let value = opt[key];
          if (typeof config[key] !== "undefined") {
            config[key] = value;
            if (key === `DEBUG`) {
              if (value) {
                console.log("activating");
                console.debug = __console_debug;
              } else {
                console.log("deactivating");
                console.debug = noop;
              }
            }
          }
        });
      },
      // which settings can the user update?
      DEFAULT_CONFIG,
      // The pseudo-random number generator used by
      // any code that needs to randomise data.
      PRNG: new Random(currentConfig.SEED),
      DEBUG: currentConfig.DEBUG,
      log: noop,
      flushLog: noop,
      // For debugging purposes, if we're messing
      // with which hand/draw it is, we need to
      // probably also peg the PRNG seed.
      START_OVERRIDE_SEED: 0,
      // For debugging purposes, we can tell
      // the game to effectively start on a
      // hand other than hand 1.
      START_ON_HAND: 0,
      // For debugging purposes, we can tell
      // the game to effectively pause play
      // at the end of the following "hand".
      // A value of 0 means "don't pause".
      PAUSE_ON_HAND: 0,
      // For debugging purposes, we prespecify
      // the number of draws.
      START_ON_DRAWS: 0,
      // For debugging purposes, we can tell
      // the game to effectively pause play
      // at the end of the following "draw".
      // A value of 0 means "don't pause".
      PAUSE_ON_DRAW: 0,
      // For debugging purposes, we can tell
      // the game to pause play after a specific
      // tile getting dealt during a hand.
      // A value of 0 means "don't pause".
      PAUSE_ON_PLAY: 0,
      // This setting determines which type of play
      // is initiated if PLAY_IMMEDIATELY is true
      BOT_PLAY: false,
      // This value determines how long bots will
      // "wait" before discarding a tile. This is
      // a purely cosmetic UX thing, where humans
      // enjoy a game more if it doesn't feel like
      // they're playing against perfect machines.
      // We're weird that way.
      ARTIFICIAL_BOT_DELAY: 300,
      // Determine whether we award points based on
      // the losers paying the winner, or the losers
      // also paying each other.
      //
      // Note that this is purely a fallback value,
      // and rulesets should specify this instead.
      LOSERS_SETTLE_SCORES: true,
      // See above
      CLAIM: CLAIM2,
      // See above
      Constants,
      // See above
      TILE_NAMES,
      TILE_GLYPHS,
      SUIT_NAMES,
      // A conversion function for turning computer
      // chow differences into claim types. This will
      // probably be migrated to somewhere else soon.
      convertSubtypeToClaim: (diff) => {
        if (diff === -1) return CLAIM2.CHOW3;
        if (diff === 1) return CLAIM2.CHOW2;
        if (diff === 2) return CLAIM2.CHOW1;
        return diff;
      }
    },
    currentConfig
  );
  config.set({ DEBUG: currentConfig.DEBUG });
  config.log = playlog.log;
  config.flushLog = playlog.flush;

  // src/js/core/game/game-tile.js
  var GameTile = class extends HTMLElement {
    constructor(tile) {
      super();
      tile = tile ?? this.getAttribute(`tile`) ?? -1;
      this.values = { tile };
      this.setAttribute(`tile`, this.values.tile);
      this.setAttribute(`title`, TILE_NAMES[tile]);
      this.setAttribute(`alt`, TILE_NAMES[tile]);
    }
    static get observedAttributes() {
      return [
        `bonus`,
        `tile`,
        `locked`,
        `locknum`,
        `hidden`,
        `concealed`,
        `supplement`
      ];
    }
    attributeChangedCallback(attr, oldVal, newVal) {
      if (oldVal === newVal) return;
      this.onChange(attr, newVal);
    }
    onChange(attributeName, attributeValue) {
      let asBool = new Boolean(attributeValue).toString();
      if (attributeValue == asBool) {
        return this.values[attributeName] = asBool;
      }
      let asInt = parseInt(attributeValue);
      if (attributeValue == asInt) {
        return this.values[attributeName] = asInt;
      }
      let asFloat = parseFloat(attributeValue);
      if (attributeValue == asFloat) {
        return this.values[attributeName] = asFloat;
      }
      this.values[attributeName] = attributeValue;
    }
    // TODO: refactor these two functions out of existence
    mark(...labels) {
      labels.forEach((label) => this.classList.add(label));
    }
    unmark(...labels) {
      labels.forEach((label) => this.classList.remove(label));
    }
    // TODO: refactor these two functions out of existence
    getFrom() {
      return this.values.from;
    }
    setFrom(pid) {
      this.setAttribute(`from`, pid);
    }
    setTitle(title = false) {
      if (title) {
        this.setAttribute(`title`, title);
      } else {
        this.removeAttribute(`title`);
      }
    }
    hide() {
      this.setAttribute(`hidden`, true);
    }
    isHidden() {
      return this.values.hidden;
    }
    reveal() {
      this.removeAttribute(`hidden`);
    }
    conceal() {
      this.setAttribute(`concealed`, true);
    }
    isConcealed() {
      return this.values.concealed;
    }
    unconceal() {
      this.removeAttribute(`concealed`);
    }
    winning() {
      this.setAttribute(`winning`, true);
    }
    isWinningTile() {
      return this.values.winning;
    }
    lock(locknum) {
      this.setAttribute(`locked`, true);
      if (locknum) {
        this.setAttribute(`locknum`, locknum);
      }
    }
    meld() {
      this.setAttribute(`meld`, true);
    }
    isLocked() {
      return this.values.locked;
    }
    getLockNumber() {
      return this.values.locknum;
    }
    unlock() {
      this.removeAttribute(`locked`);
      this.removeAttribute(`locknum`);
    }
    bonus() {
      this.setAttribute(`bonus`, true);
      this.lock();
    }
    isBonus() {
      return this.values.bonus;
    }
    supplement() {
      this.setAttribute(`supplement`, true);
    }
    isSupplement() {
      return this.values.supplement;
    }
    setTileFace(tile) {
      this.setAttribute(`tile`, tile);
    }
    getTileFace() {
      return this.values.tile;
    }
    getTileSuit() {
      let num = this.getTileFace();
      if (num < 9) return 0;
      if (num < 18) return 1;
      if (num < 27) return 2;
      if (num < 30) return 3;
      return 4;
    }
    valueOf() {
      return this.values.tile;
    }
    toString() {
      return `GameTile(${this.values.tile})`;
    }
  };
  globalThis.customElements.define(`game-tile`, GameTile);
  function declare(label, tilenumber2) {
    globalThis.customElements.define(
      label,
      class extends GameTile {
        constructor() {
          super(tilenumber2);
        }
      }
    );
  }
  var numeral = [
    `one`,
    `two`,
    `three`,
    `four`,
    `five`,
    `six`,
    `seven`,
    `eight`,
    `nine`
  ];
  var tilenumber = 0;
  [`bamboo`, `characters`, `dots`].forEach(
    (suit) => numeral.forEach((number) => declare(`${suit}-${number}`, tilenumber++))
  );
  declare(`east-wind`, 27);
  declare(`south-wind`, 28);
  declare(`west-wind`, 29);
  declare(`north-wind`, 30);
  declare(`green-dragon`, 31);
  declare(`red-dragon`, 32);
  declare(`white-dragon`, 33);
  tilenumber = 34;
  [`flower`, `season`].forEach(
    (b) => numeral.slice(0, 4).forEach((number) => declare(`${b}-${number}`, tilenumber++))
  );
  var create = (tileNumber, hidden) => {
    let span;
    if (typeof process !== `undefined`) {
      span = new GameTile(tileNumber);
    } else {
      let GameTile2 = customElements.get(`game-tile`);
      span = new GameTile2(tileNumber);
    }
    if (tileNumber < 34) {
      if (hidden) {
        span.hide();
      }
    } else span.bonus();
    return span;
  };

  // src/js/core/utils/utils.js
  Array.prototype.last = function last() {
    return this[this.length - 1];
  };
  Array.prototype.asyncAll = async function asyncAll(fn) {
    return await Promise.all(
      this.map(
        (e) => new Promise((resolve) => {
          fn(e);
          resolve();
        })
      )
    );
  };
  var __roll_sort = (a, b) => a < b ? -1 : b > a ? 1 : 0;
  function unroll(list, seen = [], result = []) {
    list = list.slice();
    seen.push(list.shift());
    if (!list.length) {
      seen.sort(__roll_sort);
      let print = seen.toString();
      let found = result.some((sofar) => sofar.toString() === print);
      if (!found) result.push(seen);
    } else list.forEach((tail) => unroll(tail, seen.slice(), result));
    return result;
  }

  // src/js/page/virtual-keys.js
  var VK_LEFT = {
    "37": true,
    // left cursor
    "65": true
    // 'a' key
  };
  var VK_RIGHT = {
    "39": true,
    // right cursor
    "68": true
    // 'd' key
  };
  var VK_UP = {
    "38": true,
    // up cursor
    "87": true
    // 'w' key
  };
  var VK_DOWN = {
    "40": true,
    // down cursor
    "83": true
    // 's' key
  };
  var VK_START = {
    "36": true
    // home
  };
  var VK_END = {
    "35": true
    // end
  };
  var VK_SIGNAL = {
    "13": true,
    // enter
    "32": true
    // space
  };
  var vk_signal_lock = false;
  function lock_vk_signal() {
    vk_signal_lock = true;
    document.addEventListener("keyup", unlock_vk_signal);
  }
  function unlock_vk_signal(evt) {
    let code = evt.keyCode;
    if (VK_UP[code] || VK_SIGNAL[code]) {
      vk_signal_lock = false;
      document.removeEventListener("keyup", unlock_vk_signal);
    }
  }

  // src/js/page/modal/options-dialog.js
  var OptionsDialog = class {
    constructor(modal2) {
      this.modal = modal2;
    }
    /**
     * This modal offers a label and a set of button choices
     * to pick from. Buttons can be navigated with the
     * cursor keys for one handed play.
     */
    show(label, options, resolve, cancel) {
      let panel = this.modal.makePanel();
      if (options.fixed) panel.fixed = true;
      panel.innerHTML = `<h1>${label}</h1>`;
      let bid = 0;
      let btns = [];
      options.filter((v) => v).forEach((data) => {
        if (Object.keys(data).length === 0) {
          return panel.appendChild(document.createElement("br"));
        }
        if (data.heading) {
          let heading = document.createElement("h1");
          heading.textContent = data.heading;
          return panel.appendChild(heading);
        }
        if (data.description) {
          let description = document.createElement("p");
          if (data.align) description.classList.add(data.align);
          description.textContent = data.description;
          return panel.appendChild(description);
        }
        let btn = document.createElement("button");
        btn.textContent = data.label;
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          if (!data.back) this.modal.close([{ object: this.modal.gameBoard, evntName: "focus", handler: panel.gainFocus }]);
          resolve(data.value);
        });
        btn.addEventListener("keydown", (e) => {
          e.stopPropagation();
          let code = e.keyCode;
          let willBeHandled = VK_UP[code] || VK_DOWN[code] || VK_START[code] || VK_END[code];
          if (!willBeHandled) return;
          e.preventDefault();
          if (VK_UP[code]) bid = bid === 0 ? btns.length - 1 : bid - 1;
          if (VK_DOWN[code]) bid = bid === btns.length - 1 ? 0 : bid + 1;
          if (VK_START[code]) bid = 0;
          if (VK_END[code]) bid = btns.length - 1;
          btns[bid].focus();
        });
        panel.appendChild(btn);
      });
      if (cancel) {
        let handleKey = (evt) => {
          if (evt.keyCode === 27) {
            evt.preventDefault();
            this.modal.close([
              { object: document, evntName: "focus", handler: panel.gainFocus },
              { object: this.modal.gameBoard, evntName: "keydown", handler: handleKey }
            ]);
            cancel();
          }
        };
        this.modal.gameBoard.addEventListener("keydown", handleKey);
      }
      btns = panel.querySelectorAll(`button`);
      panel.gainFocus = () => btns[bid].focus();
      document.addEventListener("focus", panel.gainFocus);
      panel.addEventListener("click", panel.gainFocus);
      panel.addEventListener("touchstart", panel.gainFocus, { passive: true });
      panel.gainFocus();
    }
  };

  // src/js/core/game/wall/wall-hack.js
  var WallHack = {
    hacks: {
      self_drawn_win_clean: [
        1,
        1,
        1,
        2,
        2,
        2,
        3,
        3,
        3,
        4,
        4,
        4,
        5,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        19,
        19,
        19,
        27,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        15,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        5
        // p0 win
      ],
      self_drawn_win: [
        1,
        1,
        1,
        23,
        23,
        23,
        2,
        3,
        4,
        24,
        24,
        24,
        5,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        19,
        19,
        19,
        27,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        15,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        5
        // p0 win
      ],
      form_melded_kong_off_initial: [
        0,
        3,
        6,
        9,
        21,
        15,
        18,
        21,
        24,
        12,
        3,
        9,
        13,
        // p0
        1,
        1,
        1,
        2,
        2,
        2,
        12,
        19,
        21,
        4,
        4,
        4,
        0,
        // p1
        7,
        7,
        7,
        8,
        8,
        8,
        10,
        10,
        10,
        11,
        11,
        11,
        0,
        // p2
        16,
        16,
        16,
        17,
        17,
        17,
        20,
        20,
        20,
        6,
        6,
        6,
        25,
        // p3
        5,
        // p0 discard
        5,
        // p1 discards 21, p0 pungs, discard 24
        9,
        // p1 not a win, discards
        13,
        // p2 not a win, discards
        12,
        // p3 not a win, discard
        21
        // p0 can now meld a kong
      ],
      kong_in_initial_deal: [
        1,
        1,
        1,
        2,
        2,
        2,
        3,
        3,
        3,
        4,
        4,
        4,
        4,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        19,
        19,
        19,
        5,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        15,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        5,
        // p0 supplement
        5
        // p0 win
      ],
      kong_from_first_discard: [
        1,
        1,
        1,
        2,
        2,
        2,
        3,
        3,
        3,
        4,
        4,
        4,
        5,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        19,
        19,
        19,
        4,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        20,
        14,
        15,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        16,
        // p1 kong
        5
        // p0 win
      ],
      robbing_a_kong: [
        1,
        1,
        1,
        2,
        2,
        2,
        3,
        3,
        3,
        4,
        4,
        22,
        23,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        14,
        14,
        14,
        15,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        24,
        24,
        24,
        15,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        5,
        // p0 discard
        24
        // p1 kong
        // p0 can win by robbing this kong.
      ],
      robbing_a_selfdrawn_kong: [
        1,
        1,
        1,
        2,
        2,
        2,
        3,
        3,
        3,
        4,
        4,
        22,
        23,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        24,
        24,
        24,
        4,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        15,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        5,
        // p0 discard
        24
        // p1 kong
        // p0 can win by robbing this kong.
      ],
      melded_kong: [
        1,
        1,
        1,
        2,
        2,
        2,
        3,
        3,
        3,
        4,
        5,
        28,
        28,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        19,
        19,
        19,
        28,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        20,
        14,
        15,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        30,
        // gets discarded by p0
        27,
        // discard by p1, pung by p0, discard 4
        30,
        // gets discarded by p1
        30,
        // gets discarded by p2
        30,
        // gets discarded by p3
        28
        // melded kong for p0
      ],
      chow_by_player_1: [
        1,
        1,
        1,
        2,
        2,
        2,
        3,
        3,
        3,
        4,
        4,
        4,
        5,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        20,
        20,
        20,
        23,
        24,
        26,
        5,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        26,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        25
        // chow for p1
      ],
      all_bonus_to_player: [
        34,
        35,
        36,
        37,
        38,
        39,
        40,
        41,
        // p0 bonus tiles
        1,
        1,
        24,
        2,
        2,
        26,
        3,
        3,
        28,
        4,
        4,
        30,
        5,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        19,
        19,
        19,
        5,
        // p0
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        26,
        // p0
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10
        // p0
      ],
      thirteen_orphans: [
        0,
        8,
        9,
        17,
        18,
        26,
        27,
        28,
        29,
        30,
        31,
        32,
        33,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        19,
        19,
        19,
        5,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        26,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        27
        // p0 win
      ],
      all_green: [
        1,
        2,
        3,
        2,
        2,
        2,
        5,
        5,
        5,
        7,
        7,
        7,
        31,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        19,
        19,
        19,
        5,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        26,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        31
        // p0 win (pair)
      ],
      nine_gates: [
        0,
        0,
        0,
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        8,
        8,
        // p0
        16,
        16,
        16,
        17,
        17,
        17,
        18,
        18,
        18,
        19,
        19,
        19,
        5,
        // p1
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        26,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        3
        // p0 win
      ],
      little_three_dragons: [
        1,
        1,
        1,
        23,
        23,
        23,
        2,
        3,
        4,
        24,
        24,
        24,
        5,
        // p0
        31,
        31,
        31,
        32,
        32,
        32,
        33,
        33,
        18,
        19,
        19,
        19,
        27,
        // p1, pung of green, pung of red, pair of white
        11,
        11,
        11,
        12,
        12,
        12,
        13,
        13,
        13,
        14,
        14,
        14,
        15,
        // p2
        6,
        6,
        6,
        7,
        7,
        7,
        8,
        8,
        8,
        9,
        9,
        9,
        10,
        // p3
        5
        // p0 win
      ],
      chow_for_player_0: [
        0,
        3,
        6,
        9,
        24,
        25,
        18,
        21,
        24,
        12,
        3,
        9,
        13,
        // p0
        1,
        1,
        1,
        2,
        2,
        2,
        12,
        19,
        21,
        4,
        4,
        4,
        0,
        // p1
        7,
        7,
        7,
        8,
        8,
        8,
        10,
        10,
        10,
        11,
        11,
        11,
        0,
        // p2
        16,
        16,
        16,
        17,
        17,
        17,
        20,
        20,
        20,
        6,
        6,
        6,
        25,
        // p3
        5,
        // p0 discard
        5,
        // p1 discards 21
        5,
        // p2 discards 5
        23
        // p3 discards 14
      ],
      "5_6_7_plus_5": [
        0,
        3,
        6,
        9,
        14,
        15,
        22,
        23,
        24,
        30,
        3,
        9,
        13,
        // p0
        1,
        1,
        1,
        2,
        2,
        2,
        12,
        19,
        21,
        4,
        4,
        4,
        0,
        // p1
        7,
        7,
        7,
        8,
        8,
        8,
        10,
        10,
        10,
        11,
        11,
        11,
        0,
        // p2
        16,
        16,
        16,
        17,
        17,
        17,
        20,
        20,
        20,
        6,
        6,
        6,
        26,
        // p3
        5,
        // p0 discard
        5,
        // p1 discards
        5,
        // p2 discards
        22
        // p3 discards
      ],
      "5_6_7_plus_6": [
        0,
        3,
        6,
        9,
        14,
        15,
        22,
        23,
        24,
        30,
        3,
        9,
        13,
        // p0
        1,
        1,
        1,
        2,
        2,
        2,
        12,
        19,
        21,
        4,
        4,
        4,
        0,
        // p1
        7,
        7,
        7,
        8,
        8,
        8,
        10,
        10,
        10,
        11,
        11,
        11,
        0,
        // p2
        16,
        16,
        16,
        17,
        17,
        17,
        20,
        20,
        20,
        6,
        6,
        6,
        26,
        // p3
        5,
        // p0 discard
        5,
        // p1 discards
        5,
        // p2 discards
        23
        // p3 discards
      ],
      "5_6_7_plus_7": [
        0,
        3,
        6,
        9,
        14,
        15,
        22,
        23,
        24,
        30,
        3,
        9,
        13,
        // p0
        1,
        1,
        1,
        2,
        2,
        2,
        12,
        19,
        21,
        4,
        4,
        4,
        0,
        // p1
        7,
        7,
        7,
        8,
        8,
        8,
        10,
        10,
        10,
        11,
        11,
        11,
        0,
        // p2
        16,
        16,
        16,
        17,
        17,
        17,
        20,
        20,
        20,
        6,
        6,
        6,
        26,
        // p3
        5,
        // p0 discard
        5,
        // p1 discards
        5,
        // p2 discards
        24
        // p3 discards
      ],
      "5_6_7_8_plus_6": [
        0,
        3,
        6,
        9,
        14,
        15,
        22,
        23,
        24,
        25,
        3,
        9,
        13,
        // p0
        1,
        1,
        1,
        2,
        2,
        2,
        12,
        19,
        21,
        4,
        4,
        4,
        0,
        // p1
        7,
        7,
        7,
        8,
        8,
        8,
        10,
        10,
        10,
        11,
        11,
        11,
        0,
        // p2
        16,
        16,
        16,
        17,
        17,
        17,
        20,
        20,
        20,
        6,
        6,
        6,
        26,
        // p3
        5,
        // p0 discard
        5,
        // p1 discards 21
        5,
        // p2 discards 5
        23
        // p3 discards 14
      ],
      pung_chow_conflict: [
        0,
        3,
        6,
        9,
        14,
        15,
        22,
        24,
        25,
        3,
        9,
        13,
        32,
        // p0
        1,
        1,
        1,
        2,
        2,
        2,
        12,
        19,
        21,
        23,
        23,
        0,
        4,
        // p1
        7,
        7,
        7,
        8,
        8,
        8,
        10,
        10,
        10,
        11,
        11,
        11,
        0,
        // p2
        16,
        16,
        16,
        17,
        17,
        17,
        20,
        20,
        20,
        6,
        6,
        6,
        26,
        // p3
        5,
        // p0 discard
        5,
        // p1 discards
        5,
        // p2 discards
        23
        // p3 discards
      ],
      cantonese_chicken_hand: [
        1,
        1,
        1,
        2,
        2,
        2,
        6,
        7,
        8,
        23,
        23,
        9,
        9,
        // p1
        3,
        3,
        21,
        21,
        14,
        15,
        22,
        24,
        25,
        3,
        9,
        13,
        32,
        // p0
        7,
        7,
        7,
        8,
        8,
        8,
        10,
        10,
        10,
        11,
        11,
        11,
        0,
        // p2
        16,
        16,
        16,
        17,
        17,
        17,
        20,
        20,
        20,
        6,
        6,
        6,
        26,
        // p3
        36,
        // p0 bonus tile
        5,
        5,
        5,
        15,
        15,
        1
        // p0 selfdrawn win
      ]
    },
    set(wall, tiles) {
      tiles = tiles.slice();
      if (typeof tiles[0] === "object") {
        let conf = tiles.splice(0, 1)[0];
        config.PRNG.seed(conf.seed || 1);
      } else config.PRNG.seed(1);
      let base2 = wall.getBase();
      tiles.forEach((tile) => base2.splice(base2.indexOf(tile), 1));
      wall.tiles = tiles.concat(wall.shuffle(base2));
    }
  };

  // src/js/page/modal/settings.js
  var SettingsModal = class {
    constructor(modal2) {
      this.modal = modal2;
    }
    show() {
      let panel = this.modal.makePanel(`settings`);
      panel.innerHTML = `
      <h3>\u6E38\u620F\u8BBE\u7F6E</h3>
      <p>
        The follow settings change how the game works, but while
        the first three options are related to playing the game,
        all the other options are primarily intended for debugging.
      </p>
    `;
      const options = this.getOptions();
      const form = this.modal.buildPanelContent(options, true);
      form.setAttribute("name", "settings");
      form.setAttribute("action", "index.html");
      form.setAttribute("method", "GET");
      this.addFormControls(panel, form, options);
      this.modal.addFooter(panel, "Closing without saving");
    }
    addFormControls(panel, form, options) {
      const table = form.querySelector(`table`);
      let row = document.createElement(`tr`);
      row.classList.add(`spacer-1`);
      row.innerHTML = `
      <td>
        <input id="reset" type="reset" value="\u6062\u590D\u9ED8\u8BA4">
      </td>
      <td>
        <input id="ok" type="submit" value="\u6309\u6B64\u8BBE\u7F6E\u5F00\u59CB">
      </td>
    `;
      table.appendChild(row);
      form.addEventListener(`submit`, (evt) => {
        evt.preventDefault();
        let suffix = options.filter((e) => e.value != e.default_value).map((e) => `${e.key}=${e.value}`).join("&");
        globalThis.location.search = suffix ? `?${suffix}` : ``;
      });
      let ok = table.querySelector(`#ok`);
      panel.gainFocus = () => ok.focus();
      let reset = table.querySelector(`#reset`);
      reset.addEventListener("click", (evt) => globalThis.location.search = "");
    }
    getOptions() {
      const options = [
        // 本应用固定为四川血战到底规则，不提供切换入口
        {
          // basic boolean flags:
        },
        {
          label: `\u{1F004} Always show everyone's tiles`,
          key: `force_open_bot_play`,
          toggle: true
        },
        {
          label: `\u2728 Highlight claimable discards`,
          key: `show_claim_suggestion`,
          toggle: true
        },
        {
          label: `\u{1F4AC} Show bot play suggestions`,
          key: `show_bot_suggestion`,
          toggle: true
        },
        {
          // additional boolean flags:
        },
        {
          label: `\u{1F3B5} Play sounds`,
          key: `use_sound`,
          toggle: true
        },
        {
          label: `\u{1F7E2} Start play immediately`,
          key: `play_immediately`,
          toggle: true
        },
        {
          label: `\u23F8\uFE0F Pause game unless focused`,
          key: `pause_on_blur`,
          toggle: true
        },
        {
          label: `\u{1F4BB} Turn on debug mode`,
          key: `debug`,
          toggle: true
        },
        {
          label: `\u274C Pretend previous round was a draw`,
          key: `force_draw`,
          toggle: true,
          debug_only: true
        },
        {
          label: `\u{1F4C3} Generate game log after play`,
          key: `write_game_log`,
          toggle: true,
          debug_only: true
        },
        {
          // numerical values:
        },
        {
          label: `Set game PRNG seed`,
          key: `seed`,
          debug_only: true
        },
        {
          label: `Bot quick play threshold`,
          key: `bot_chicken_threshold`,
          debug_only: true
        },
        {
          label: `Delay (in ms) between player turns`,
          key: `play_interval`
        },
        {
          label: `Delay (in ms) before starting next hand`,
          key: `hand_interval`
        },
        {
          label: `Delay (in ms) for bots reacting to things`,
          key: `bot_delay_before_discard_ends`
        },
        {
          label: `Delay (in ms) during full bot play`,
          key: `bot_play_delay`
        },
        // and debug hacking
        {
          label: `Set up a specific wall`,
          key: `wall_hack`,
          options: [``, ...Object.keys(WallHack.hacks)],
          debug_only: true
        }
      ];
      options.forEach((entry) => {
        const { key } = entry;
        if (key) {
          const CONFIG_KEY = key.toUpperCase();
          entry.value = config[CONFIG_KEY];
          entry.default_value = config.DEFAULT_CONFIG[CONFIG_KEY];
        }
      });
      return options;
    }
  };

  // src/js/page/modal/scores.js
  var ScoreModal = class {
    constructor(modal2) {
      this.modal = modal2;
    }
    /**
     * Show the entire game's score progression
     */
    showFinalScores(gameui, rules, scoreHistory, resolve) {
      let panel = this.modal.makePanel(`final-scores`);
      panel.innerHTML = `<h3>Game finished</h3>`;
      let base2 = new Array(4).fill(rules.player_start_score);
      let table = document.createElement("table");
      let tbody = document.createElement("tbody");
      table.appendChild(tbody);
      tbody.innerHTML = `
      <tr>
        <th>hand</th>
        <th>player 0</th>
        <th>player 1</th>
        <th>player 2</th>
        <th>player 3</th>
        <th>&nbsp;</th>
      </tr>
      <tr>
        <td>&nbsp;</td>
        ${base2.map((v) => `<td>${v}</td>`).join("\n")}
        <td>&nbsp;</td>
      </tr>
    `;
      scoreHistory.forEach((record, hand) => {
        hand = hand + 1;
        let row = document.createElement("tr");
        let content = [0, 1, 2, 3].map((id) => {
          let winner = record.fullDisclosure[id].winner;
          let value = record.adjustments[id];
          let score = base2[id] = base2[id] + value;
          let wind = record.fullDisclosure[id].wind;
          let title = [winner ? "winner" : false, wind === 0 ? "east" : false].filter((v) => v).join(", ");
          return `
          <td title="${title}">
            <span${wind === 0 ? ` class="east"` : ``} >${winner ? `<strong>${score}</strong>` : score}</span>
          </td>
        `;
        });
        row.innerHTML = `
        <td>${hand}</td>
        ${content.join("\n")}
        <td><button>details</button></td>
      `;
        row.querySelector("button").addEventListener("click", () => {
          gameui.loadHandPostGame(record.fullDisclosure);
          this.show(hand, rules, record.scores, record.adjustments);
        });
        tbody.appendChild(row);
      });
      panel.appendChild(table);
      this.modal.addFooter(panel, "Back to the menu", resolve);
      panel.scrollTop = 0;
    }
    /**
     * Show the end-of-hand score breakdown.
     */
    show(hand, rules, scores, adjustments, resolve) {
      let panel = this.modal.makePanel(`scores`);
      panel.innerHTML = `<h3>Scores for hand ${hand}</h3>`;
      let faanSystem = rules.scoretype === Ruleset.FAAN_LAAK;
      let winner = 0;
      scores.some((e, id) => {
        winner = id;
        return e.winner;
      });
      let builder = document.createElement("div");
      builder.innerHTML = `
    <table>
      <tr>
        <th>&nbsp;</th>
        <th>player 0</th>
        <th>player 1</th>
        <th>player 2</th>
        <th>player 3</th>
      </tr>
      <tr>
        <td>winner</td>
        <td>${scores[0].winner ? "*" : ""}</td>
        <td>${scores[1].winner ? "*" : ""}</td>
        <td>${scores[2].winner ? "*" : ""}</td>
        <td>${scores[3].winner ? "*" : ""}</td>
      </tr>
      <tr>
        <td>${faanSystem ? `points` : `basic`}</td>
        <td>${scores[0].score}</td>
        <td>${scores[1].score}</td>
        <td>${scores[2].score}</td>
        <td>${scores[3].score}</td>
      </tr>
      ${faanSystem ? `` : `
      <tr>
        <td>doubles</td>
        <td>${scores[0].doubles}</td>
        <td>${scores[1].doubles}</td>
        <td>${scores[2].doubles}</td>
        <td>${scores[3].doubles}</td>
      </tr>
      `}
      <tr>
        <td>total</td>
        <td>${scores[0].total}</td>
        <td>${scores[1].total}</td>
        <td>${scores[2].total}</td>
        <td>${scores[3].total}</td>
      </tr>
      <tr>
        <td>win/loss</td>
        <td>${adjustments[0]}</td>
        <td>${adjustments[1]}</td>
        <td>${adjustments[2]}</td>
        <td>${adjustments[3]}</td>
      </tr>
      <tr class="details">
        <td>&nbsp;</td>
        <td>${!faanSystem || faanSystem && winner === 0 ? `<button>details</button>` : ``}</td>
        <td>${!faanSystem || faanSystem && winner === 1 ? `<button>details</button>` : ``}</td>
        <td>${!faanSystem || faanSystem && winner === 2 ? `<button>details</button>` : ``}</td>
        <td>${!faanSystem || faanSystem && winner === 3 ? `<button>details</button>` : ``}</td>
      </tr>
    </table>
    `;
      let table = builder.querySelector("table");
      Array.from(table.querySelectorAll("tr.details td")).slice(1).map((e, pid) => {
        e.addEventListener("click", (evt) => {
          this.showScoreDetails(pid, scores[pid].log, faanSystem);
        });
      });
      panel.appendChild(table);
      if (resolve) this.modal.addFooter(panel, "Play next hand", resolve, true);
      else this.modal.addFooter(panel, "OK");
    }
    /**
     * Show a detailed score log for a particular player.
     */
    showScoreDetails(pid, log, faanSystem) {
      let panel = this.modal.makePanel(`score-breakdown`);
      panel.innerHTML = `<h3>Score breakdown for player ${pid}</h3>`;
      let table = document.createElement("table");
      let data = [
        `<tr><th>points</th><th>element</th></tr>`,
        ...log.map((line) => {
          let mark = ` for `;
          if (line.indexOf(mark) > -1) {
            let parts = line.split(mark);
            let pts = parts[0].replace(/doubles?/, `dbl`).replace(/faan/, "");
            return `<tr><td>${pts}</td><td>${parts[1]}</td></tr>`;
          } else {
            if (faanSystem) return ``;
            return `<tr><td colspan="2">${line}</td></tr>`;
          }
        })
      ];
      table.innerHTML = data.join(`
`);
      panel.appendChild(table);
      this.modal.addFooter(panel, "Back to the scores");
    }
  };

  // src/js/page/utils.js
  function setStyleSheet(id, css) {
    let style = document.getElementById(id);
    if (style) {
      style.parentNode.removeChild(style);
    } else {
      style = document.createElement(`style`);
    }
    style.id = id;
    style.textContent = css;
    document.body.append(style);
  }
  var TileSetManager = class _TileSetManager {
    static loadDefault() {
      this.createTileSetCSS(`./img/tiles/default-tileset.png`).then(
        (css) => setStyleSheet(`default-tiles`, css)
      );
    }
    static createTileSetCSS(dataURL) {
      return new Promise((resolve) => {
        const img = new Image();
        img.src = dataURL;
        img.onload = (evt) => {
          const css = [];
          const tileWidth = img.width / 9;
          const tileHeight = img.height / 5;
          console.log(img.width, img.height, tileWidth, tileHeight);
          const canvas = document.createElement(`canvas`);
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext(`2d`);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          for (let r = 0; r < 5; r++) {
            for (let c = 0; c < 9; c++) {
              const tileNumber = _TileSetManager.getTileNumber(r, c);
              if (tileNumber === false) continue;
              const [x, y, w, h] = [
                tileWidth * c + 1,
                tileHeight * r + 1,
                tileWidth - 2,
                tileHeight - 2
              ];
              const crop = document.createElement(`canvas`);
              crop.width = w;
              crop.height = h;
              crop.getContext("2d").drawImage(canvas, x, y, w, h, 0, 0, w, h);
              css.push(
                `[tile="${tileNumber}"] { background-image: url(${crop.toDataURL()}); }`
              );
            }
          }
          resolve(css.join(`
`));
        };
      });
    }
    static getTileNumber(row, col) {
      if (row < 3) return col + 9 * row;
      if (row === 3) {
        if (col < 4) return 27 + col;
        if (col === 4) return false;
        if (col < 8) return 31 - 5 + col;
      }
      if (row === 4) {
        if (col !== 8) return 34 + col;
        return -1;
      }
      return false;
    }
  };

  // src/js/page/modal/theming.js
  function fileLoader(evt) {
    return new Promise((resolve, reject) => {
      const file = evt.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          file.dataURL = e.target.result;
          if (file.size > 5e5) {
            alert("Images over 500kb are not supported");
            return reject();
          }
          resolve(file);
        };
        reader.readAsDataURL(file);
      } else reject();
    });
  }
  var ThemeModal = class {
    constructor(modal2) {
      this.modal = modal2;
      this.init();
    }
    init() {
      this.loadBackground();
      this.loadSidebar();
      this.loadPlayerBanks();
      this.loadTileset();
    }
    reset() {
      [
        `mahjongBackground`,
        `mahjongSidebar`,
        `mahjongPlayerBanks`,
        `mahjongTileset`,
        `mahjongCSS`
      ].forEach((key) => {
        localStorage.removeItem(key);
        const e = document.getElementById(`mahjongBackground`);
        if (e) {
          e.parentNode.removeChild(e);
        }
      });
      globalThis.location.reload();
    }
    loadBackground() {
      const dataURL = localStorage.getItem("mahjongBackground");
      if (dataURL) {
        setStyleSheet(
          `mahjongBackground`,
          `.board .discards { background-image: url(${dataURL}); }`
        );
      }
      return !!dataURL;
    }
    saveBackground(background) {
      localStorage.setItem("mahjongBackground", background);
    }
    loadSidebar() {
      const dataURL = localStorage.getItem("mahjongSidebar");
      if (dataURL) {
        setStyleSheet(
          `mahjongSidebar`,
          `.board .sidebar { background-image: url(${dataURL}); }`
        );
      }
      return !!dataURL;
    }
    saveSidebar(background) {
      localStorage.setItem("mahjongSidebar", background);
    }
    loadPlayerBanks() {
      const dataURL = localStorage.getItem("mahjongPlayerBanks");
      if (dataURL) {
        setStyleSheet(
          `mahjongPlayerBanks`,
          `.players .player { background-image: url(${dataURL}); }`
        );
      }
      return !!dataURL;
    }
    savePlayerBanks(background) {
      localStorage.setItem("mahjongPlayerBanks", background);
    }
    async loadTileset() {
      const dataURL = localStorage.getItem("mahjongTileset");
      if (dataURL) {
        setStyleSheet(
          `mahjongTileset`,
          await TileSetManager.createTileSetCSS(dataURL)
        );
      } else {
        TileSetManager.loadDefault();
      }
      return !!dataURL;
    }
    saveTileset(background) {
      localStorage.setItem("mahjongTileset", background);
    }
    /**
     * Configure all the configurable options and
     * then relaunch the game on the appropriate URL.
     */
    show() {
      const panel = this.modal.makePanel(`settings`);
      panel.innerHTML = `<h3>Change the game theme</h3>`;
      const options = this.getOptions();
      const table = this.modal.buildPanelContent(options);
      this.addFormControls(panel, table, options);
      this.modal.addFooter(panel, "Close");
    }
    addFormControls(panel, table, options) {
      let row = document.createElement(`tr`);
      row.classList.add(`spacer-1`);
      row.innerHTML = `
      <td colspan="2">
        <input id="reset" type="reset" value="Reset to default settings">
      </td>
    `;
      table.appendChild(row);
      let reset = table.querySelector(`#reset`);
      reset.addEventListener("click", () => this.reset());
    }
    getOptions() {
      const handle = (fnName) => (entry, evt) => fileLoader(evt).then((file) => {
        this[`save${fnName}`](file.dataURL);
        this[`load${fnName}`]();
      });
      const options = [
        {
          label: "Background image",
          type: `file`,
          handler: handle("Background")
        },
        {
          label: "Sidebar image",
          type: `file`,
          handler: handle("Sidebar")
        },
        {
          label: "Player banks",
          type: `file`,
          handler: handle("PlayerBanks")
        },
        {
          label: "Tileset",
          type: `file`,
          handler: handle("Tileset")
        },
        {
          label: "CSS colors",
          button_label: "Change...",
          type: `button`,
          evtType: `click`,
          handler: (entry, evt) => {
            this.modal.pickColors();
          }
        }
      ];
      return options;
    }
  };

  // src/js/page/modal/colors.js
  var ColorModal = class {
    constructor(modal2) {
      this.modal = modal2;
      this.overrides = {};
      this.loadColorScheme();
    }
    reset() {
      const style = document.querySelector(`style#mahjongCSS`);
      if (style) style.parentNode.removeChild(style);
    }
    saveColor(entry) {
      if (entry.value !== entry.default_value) {
        this.overrides[entry.label] = entry;
      } else {
        this.overrides[entry.label] = void 0;
      }
      const colorCSS = `:root {${Object.entries(this.overrides).filter(([label, entry2]) => !!entry2).map(([label, entry2]) => `${entry2.key}: ${entry2.value};`).join(`
`)}}`;
      localStorage.setItem(`mahjongCSS`, colorCSS);
      setStyleSheet(`mahjongCSS`, colorCSS);
    }
    loadColorScheme() {
      const colorCSS = localStorage.getItem("mahjongCSS");
      if (colorCSS) {
        setStyleSheet(`mahjongCSS`, colorCSS);
      }
      return !!colorCSS;
    }
    /**
     * Configure all the configurable options and
     * then relaunch the game on the appropriate URL.
     */
    show() {
      const panel = this.modal.makePanel(`settings`);
      panel.innerHTML = `<h3>Change CSS Colors</h3>`;
      const options = this.getOptions(panel);
      const table = this.modal.buildPanelContent(options);
      this.addFormControls(table);
      this.modal.addFooter(panel, "Close");
    }
    addFormControls(table) {
      let row = document.createElement(`tr`);
      row.classList.add(`spacer-1`);
      row.innerHTML = `
        <td colspan="2">
          <input id="reset" type="reset" value="Reset to default settings">
        </td>
      `;
      table.appendChild(row);
      let reset = table.querySelector(`#reset`);
      reset.addEventListener("click", () => this.reset());
    }
    getCSSColors() {
      const s = Array.from(document.styleSheets).find(
        (s2) => s2.ownerNode.href.includes(`/colors.css`)
      );
      const colors = Array.from(s.rules[0].style);
      const colorsForHumans = colors.map(
        (v) => v.replace(/^--/, "").replaceAll("-", " ")
      );
      const values = colors.map(
        (v) => getComputedStyle(document.documentElement).getPropertyValue(v)
      );
      return { colors, colorsForHumans, values };
    }
    getOptions() {
      const colors = this.getCSSColors();
      const get = (l) => this.overrides[l]?.value;
      const hex = (c) => this.getHexColor(c);
      const save = (entry) => this.saveColor(entry);
      const options = colors.colorsForHumans.map((label, i) => {
        return {
          label,
          key: colors.colors[i],
          value: get(label) || hex(colors.values[i]),
          default_value: hex(colors.values[i]),
          type: `color`,
          evtType: `input`,
          get handler() {
            return (entry, evt, opacity) => {
              if (evt) this.value = hex(evt.target.value);
              if (opacity) {
                this.value = this.value.substring(0, 7) + parseInt(opacity).toString(16).padStart(2, "0");
              }
              save(this);
            };
          }
        };
      });
      return options;
    }
    getHexColor(cssColor) {
      const canvas = document.createElement(`canvas`);
      canvas.width = canvas.height = 1;
      const ctx = canvas.getContext("2d");
      ctx.beginPath();
      ctx.rect(-1, -1, 2, 2);
      ctx.fillStyle = cssColor;
      ctx.fill();
      const [r, g, b, a] = Array.from(ctx.getImageData(0, 0, 1, 1).data);
      if (a < 255) {
        const v2 = ((r << 24) + (g << 16) + (b << 8) + a).toString(16);
        return `#${v2.padStart(8, "0")}`;
      }
      const v = ((r << 16) + (g << 8) + b).toString(16);
      return `#${v.padStart(6, "0")}`;
    }
  };

  // src/js/page/modal/modal.js
  var Modal = class {
    constructor(fixed = false) {
      this.fixed = fixed;
      this.modal = document.querySelector(".modal");
      this.gameBoard = document.querySelector(".board");
      this.panels = [];
      this.choice = new OptionsDialog(this);
      this.settings = new SettingsModal(this);
      this.theming = new ThemeModal(this);
      this.colors = new ColorModal(this);
      this.scores = new ScoreModal(this);
    }
    // show the modal stack
    reveal() {
      this.modal.classList.remove("hidden");
    }
    // is the modal stack visible?
    isHidden() {
      return this.modal.classList.contains("hidden");
    }
    // hide the modal stack
    hide() {
      this.modal.classList.add("hidden");
    }
    /**
     * Create a new modal panel to show data in.
     */
    makePanel(name) {
      let panels = this.panels;
      let panel = document.createElement("div");
      panel.classList.add("panel");
      if (name) panel.classList.add(name);
      panels.forEach((p) => p.style.display = "none");
      panels.push(panel);
      this.modal.appendChild(panel);
      return panel;
    }
    /**
     * Close the currently-active modal, which will either
     * reveal the underlying modal, or hide the master overlay.
     */
    close(unbind = []) {
      unbind.forEach((opt) => {
        opt.object.addEventListener(opt.evtName, opt.handler);
      });
      let modal2 = this.modal;
      let panels = this.panels;
      let panel = panels.pop();
      if (panel) modal2.removeChild(panel);
      if (panels.length) {
        let panel2 = panels[panels.length - 1];
        panel2.style.display = "block";
        if (panel2.gainFocus) panel2.gainFocus();
      } else {
        this.hide();
        this.gameBoard.focus();
      }
    }
    /**
     * TODO: merge options, values, and differs, because
     * there is no reason at all for those to not be unified.
     */
    buildPanelContent(options, wrapInForm = false) {
      const debug = config.DEBUG;
      const form = wrapInForm ? document.createElement(`form`) : void 0;
      const table = document.createElement(`table`);
      this.panels.last().append(table);
      options.forEach((entry) => {
        const { label, button_label, key, value, default_value } = entry;
        const { toggle, type, evtType, handler, debug_only } = entry;
        let options2 = entry.options;
        let row;
        if (!label) {
          row = document.createElement(`tr`);
          row.innerHTML = `<td colspan="2">&nbsp;</td>`;
          return table.appendChild(row);
        }
        if (debug_only && !debug) {
          return;
        }
        row = document.createElement(`tr`);
        let field = `<input class="${key} field" type"${type || `text`}" value="${value}">`;
        if (options2 || toggle) {
          options2 = toggle ? [true, false] : options2;
          field = `
          <select class="${key} field">
            ${options2.map(
            (opt) => `<option value="${opt}"${opt === value ? ` selected` : ``}>${`${opt}`.replace(/_/g, " ")}</option>`
          )}
          </select>`;
        }
        if (type === `file`) {
          field = `<input class="${key} picker field" type="${type}" value="pick...">`;
        }
        if (type === `button`) {
          field = `<input class="${key} picker field" type="${type}" value="${button_label}">`;
        }
        if (type === `color`) {
          field = `<input class="${key} picker field" type="${type}" value="${value.substring(
            0,
            7
          )}">`;
          if (value.length === 9) {
            field += `<input class="${key} opacity" type="range" min="0" max="255" step="1" value="${parseInt(
              value.substring(7),
              16
            )}">`;
          }
        }
        row.innerHTML = `
        <td style="white-space: nowrap;" data-toggle="${key}" ${toggle && !value ? `class="greyed"` : ``}>${label}</td>
        <td ${value != default_value ? ` class="custom"` : ``}>${field}</td>
      `;
        table.appendChild(row);
        const input = row.querySelector(`.field`);
        input.addEventListener(evtType || `input`, (evt) => {
          if (handler) {
            handler(entry, evt);
          } else {
            entry.value = evt.target.value;
          }
        });
        input.addEventListener(`input`, () => {
          console.log(input.value, default_value);
          if (input.value !== default_value.toString()) {
            input.parentNode.classList.add(`custom`);
          } else {
            input.parentNode.classList.remove(`custom`);
          }
        });
        if (toggle) {
          const inputLabel = row.querySelector(`[data-toggle="${key}"]`);
          input.addEventListener(`input`, () => inputLabel.classList.toggle(`greyed`));
        }
        if (type === `color`) {
          const opacity = row.querySelector(`.field + .opacity`);
          if (opacity) {
            opacity.addEventListener(`input`, (evt) => {
              handler(entry, false, evt.target.value);
            });
          }
        }
      });
      if (wrapInForm) {
        form.append(table);
        this.panels.last().append(form);
        return form;
      }
      this.panels.last().append(table);
      return table;
    }
    /**
     * Add a generic footer with an "OK" button,
     * and automated focus handling.
     */
    addFooter(panel, modalLabel = "OK", resolve = () => {
    }, botDismissible) {
      let ok = document.createElement("button");
      ok.textContent = modalLabel;
      ok.addEventListener("click", () => {
        this.close([
          { object: document, evntName: "focus", handler: panel.gainFocus }
        ]);
        resolve();
      });
      panel.appendChild(ok);
      if (config.BOT_PLAY && botDismissible) {
        let dismiss = () => ok.click();
        setTimeout(() => dismiss(), config.HAND_INTERVAL);
        panel.addEventListener("click", () => dismiss = () => {
        });
      }
      panel.gainFocus = () => ok.focus();
      document.addEventListener("focus", panel.gainFocus);
      let defaultFocus = (evt) => {
        let name = evt.target.nodeName.toLowerCase();
        if (name === "select" || name === "input") return;
        panel.gainFocus();
      };
      panel.addEventListener("click", defaultFocus);
      panel.addEventListener("touchstart", defaultFocus, { passive: true });
      panel.gainFocus();
    }
    /**
     * Offer a button dialog modal
     */
    choiceInput(label, options, resolve, cancel) {
      this.reveal();
      this.choice.show(label, options, resolve, cancel);
    }
    /**
     * Show the end-of-hand score breakdown.
     */
    setScores(hand, rules, scores, adjustments, resolve) {
      this.reveal();
      this.scores.show(hand, rules, scores, adjustments, resolve);
    }
    /**
     * Show the end-of-game score breakdown.
     */
    showFinalScores(gameui, rules, scoreHistory, resolve) {
      this.reveal();
      this.scores.showFinalScores(gameui, rules, scoreHistory, resolve);
    }
    /**
     * Show all available settings for the game.
     */
    pickPlaySettings() {
      this.reveal();
      this.settings.show();
    }
    /**
     * Show theming options for the game
     */
    pickTheming() {
      this.reveal();
      this.theming.show();
    }
    /**
     * Show theming options for the game
     */
    pickColors() {
      this.reveal();
      this.colors.show();
    }
  };
  var modal = new Modal();

  // src/js/core/players/tracking/tile-tracker.js
  var TileTracker = class {
    constructor(id) {
      this.id = id;
      this.tiles = [];
      this.ui = false;
      this.reset();
    }
    setUI(ui) {
      this.ui = ui;
    }
    /**
     * Reset all tiles to "there are four".
     */
    reset() {
      let tiles = new Array(34).fill(4);
      tiles.push(1, 1, 1, 1, 1, 1, 1, 1);
      this.tiles = Object.assign({}, tiles);
      if (this.ui) this.ui.resetTracker(this.tiles);
    }
    /**
     * Fetch the count associated with a specific tile.
     */
    get(tileNumber) {
      return this.tiles[tileNumber];
    }
    /**
     * Mark a specific tile as having been revealed to this
     * player (but not necessarily to all players!)
     */
    seen(tileNumber) {
      if (tileNumber.dataset) {
        console.log(`Player ${this.id} tracker was passed an HTMLElement instead of a tile`);
        console.trace();
        throw new Error("why is the tracker being given an HTML element?");
      }
      this.tiles[tileNumber]--;
      if (this.ui) this.ui.reduceTracker(tileNumber);
    }
  };

  // src/js/core/players/player-master.js
  var PlayerMaster = class {
    constructor(id) {
      this.el = document.createElement("div");
      this.el.setAttribute("class", "player");
      this.el.id = id;
      this.id = id;
      this.tracker = new TileTracker(this.id);
      this.ui = false;
      this.wincount = 0;
      this.reset();
    }
    reset(wind, windOfTheRound, hand, draws) {
      this.wind = wind;
      this.windOfTheRound = windOfTheRound;
      this.draws = draws;
      this.discards = [];
      this.tiles = [];
      this.locked = [];
      this.bonus = [];
      this.waiting = false;
      this.has_won = false;
      this.missingSuit = void 0;
      this.selfdraw = false;
      this.robbed = false;
      this.tracker.reset();
      this.el.innerHTML = "";
      this.el.classList.add("winner");
      if (this.ui) this.ui.reset(wind, windOfTheRound, hand, draws);
    }
    /**
     * Pause play as far as this player is concerned.
     */
    pause(lock) {
      this.paused = lock;
      if (this.ui) this.ui.pause(lock);
    }
    /**
     * Resume play as far as this player is concerned.
     */
    resume() {
      if (this.ui) this.ui.resume();
      this.paused = false;
    }
    /**
     * Signal that the game will start
     */
    gameWillStart(game, rules) {
      if (this.ui) this.ui.gameWillStart();
      this.setActiveGame(game);
      this.setRules(rules);
    }
    /**
     * Set the game this player is now playing in.
     */
    setActiveGame(game) {
      this.game = game;
    }
    /**
     * Bind the ruleset that this player should "follow"
     * during the game they are currently in.
     */
    setRules(rules) {
      this.rules = rules;
      this._score = this.rules.player_start_score;
      if (this.ui) this.ui.setRules(rules);
    }
    /**
     * Signal that a specific hand will start
     */
    handWillStart(redraw, resolve) {
      if (this.ui) this.ui.handWillStart(redraw, resolve);
      else resolve();
    }
    /**
     * Signal that actual play is about to start
     * during a hand. This is called after all the
     * initial tiles have been dealt, and all players
     * have declared any kongs they might have had
     * in their hand as a consequence.
     */
    playWillStart() {
      if (this.ui) this.ui.playWillStart();
    }
    /**
     * Take note of how many tiles there are left
     * for playing with during this hand.
     */
    markTilesLeft(left, dead) {
      this.tilesLeft = left;
      this.tilesDead = dead;
      if (this.ui) this.ui.markTilesLeft(left, dead);
    }
    /**
     * Disclose this player's hand information.
     */
    getDisclosure() {
      return {
        // tile information
        concealed: this.getTileFaces().filter((v) => v < 34),
        locked: this.locked,
        bonus: this.bonus,
        // play information,
        discards: this.discards.map((t) => t ? t.getTileFace() : t),
        // player information
        wind: this.wind,
        winner: this.has_won,
        wincount: this.getWinCount(),
        // If this player has won, did they self-draw their winning tile?
        selfdraw: this.has_won ? this.selfdraw : false,
        selftile: this.has_won && this.selfdraw ? this.latest : false,
        robbed: this.robbed,
        // If this player has won, the last-claimed tile can matter.
        final: this.has_won ? this.latest.getTileFace() : false
      };
    }
    /**
     * Signal that the hand has ended. If the hand
     * was a draw, there will no arguments passed.
     * If the hand was won, the `fullDisclosures`
     * object contains all player's disclosures.
     */
    endOfHand(fullDisclosure) {
      if (this.ui) this.ui.endOfHand(fullDisclosure);
    }
    /**
     * Signal that the game has ended, with the final
     * game scores provided in the `scores` object.
     */
    endOfGame(scores) {
      if (this.ui) this.ui.endOfGame(scores);
    }
    /**
     * Work a score adjustment into this player's
     * current score.
     */
    recordScores(adjustments) {
      this._score += adjustments[this.id];
      if (this.ui) this.ui.recordScores(adjustments);
    }
    /**
     * Get this player's current game score.
     */
    getScore() {
      return this._score;
    }
    /**
     * Signal that this is now the active player.
     */
    activate(id) {
      if (this.ui) this.ui.activate(id);
    }
    /**
     * Signal that this is not an active player.
     */
    disable() {
      if (this.ui) this.ui.disable();
    }
    /**
     * Internal function for marking self as waiting
     * to win, using any tile noted in `winTiles`.
     */
    markWaiting(winTiles = {}) {
      this.waiting = winTiles;
      if (this.ui) this.ui.markWaiting(winTiles);
    }
    /**
     * Mark this player as winner of the current hand.
     */
    markWinner() {
      if (!this.has_won) {
        this.has_won = true;
        this.wincount++;
        if (this.ui) this.ui.markWinner(this.wincount);
      }
    }
    /**
     * How many times has this player won?
     */
    getWinCount() {
      return this.wincount;
    }
    /**
     * Add a tile to this player's hand.
     */
    append(tile, claimed, supplement) {
      let face;
      let revealed = false;
      if (typeof tile !== "object") {
        face = tile;
        tile = create(tile);
      } else {
        face = tile.getTileFace();
      }
      this.latest = tile;
      if (tile.isBonus()) {
        revealed = face;
        this.bonus.push(face);
      } else {
        this.tiles.push(tile);
      }
      if (!claimed) {
        this.tracker.seen(tile.getTileFace());
        this.lastClaim = false;
      }
      if (supplement) tile.supplement();
      if (this.ui) this.ui.append(tile);
      return revealed;
    }
    /**
     * Remove a tile from this player's hand
     * (due to a discard, or locking tiles, etc).
     */
    remove(tile) {
      let pos = this.tiles.indexOf(tile);
      this.tiles.splice(pos, 1);
      if (this.ui) this.ui.remove(tile);
    }
    /**
     * Can we chow off of the indicated player?
     * 四川麻将没有吃，只有碰和杠。
     */
    mayChow(pid) {
      if (this.rules && this.rules.no_chow) return false;
      return (pid + 1) % 4 == this.id;
    }
    /** The suits (0=条 1=万 2=筒) still present in this player's hand. */
    suitsInHand() {
      let suits = /* @__PURE__ */ new Set();
      this.getTileFaces().forEach((face) => {
        if (face < 27) suits.add(face / 9 | 0);
      });
      return suits;
    }
    /** 定缺之后必须先把手上该花色的牌打完才能胡。 */
    canWinNow() {
      if (this.missingSuit === void 0) return true;
      return !this.getTileFaces().some((face) => face < 27 && (face / 9 | 0) === this.missingSuit);
    }
    /**
     * Player formed a kong by having a pung on
     * the table, and drawing the fourth tile
     * themselves.
     */
    meldKong(tile) {
      this.remove(tile);
      let set = this.locked.find((set2) => set2[0].getTileFace() === tile.getTileFace());
      let meld = set[0].cloneNode(true);
      meld.meld();
      set.push(meld);
      if (this.ui) this.ui.meldKong(tile);
    }
    /**
     * Check whether this player has, and if so,
     * wants to declare, a kong. Implement by bot.
     */
    async checkKong() {
      return false;
    }
    /**
     * Take note of the fact that a player revealed
     * one or more tiles, either due to discarding,
     * revealing a bonus tile, or by claiming/melding
     * a set.
     */
    see(tiles, player) {
      if (player === this) return;
      if (!tiles.map) tiles = [tiles];
      tiles.forEach((tile) => this.tracker.seen(tile));
      if (this.ui) this.ui.see(tiles, player);
    }
    /**
     * Take note of the fact that a different player
     * received a tile for whatever reason.
     */
    receivedTile(player) {
      if (this.ui) this.ui.receivedTile(player);
    }
    /**
     * Get the play information in terms of what this player
     * might be looking for, whether they're ready to win,
     * etc. based on Pattern expansion.
     */
    tilesNeeded() {
      return tilesNeeded(this.getTileFaces(), this.locked);
    }
    /**
     * Take note of the fact that a different player
     * discarded a specific tile.
     */
    playerDiscarded(player, discard, playcounter) {
      let tile = discard.getTileFace();
      if (this.id != player.id) this.tracker.seen(tile);
      if (this.ui) this.ui.playerDiscarded(player, tile, playcounter);
    }
    /**
     * Take note of the fact that a different player
     * declared a kong.
     */
    async seeKong(tiles, player, tilesRemaining, resolve) {
      this.see(tiles.map((t) => t.getTileFace()), player);
      this.robKong(player.id, tiles, tilesRemaining, resolve);
    }
    /**
     * Implemented by subclasses: this function tries
     * to rob a kong. If it can't, call `resolve()`,
     * but if it can, form a `claim` and then call
     * `resolve(claim)` with the appropriate wintype
     * set, as well as `from`, `tile`, and `by`:
     *
     * `from`: the player id of the person we're robbing.
     * `tile`: the tile number we're robbing.
     * `by`: our player id.
     *
     */
    async robKong(pid, tiles, tilesRemaining, resolve) {
      resolve();
    }
    /**
     * Give up a kong tile, if someone robbed it to win.
     */
    giveUpKongTile(tile) {
      let set = this.locked.find((set2) => set2.length === 4 && set2[0].getTileFace() === tile);
      let discard = set.splice(0, 1)[0];
      discard.unconceal();
      return discard;
    }
    /**
     * Take note of a player having to give up a kong
     * because someone just robbed it to win.
     */
    playerGaveUpKongTile(pid, tilenumber2) {
      if (this.ui) this.ui.playerGaveUpKongTile(pid, tilenumber2);
    }
    /**
     * Take note of the fact that a different player
     * claimed a discard to form a set.
     */
    seeClaim(tiles, player, claimedTile, claim) {
      if (player === this) return;
      if (!tiles.map) tiles = [tiles];
      tiles.forEach((tile, pos) => {
        if (tile === claimedTile) return;
        this.tracker.seen(tile.getTileFace());
      });
      if (this.ui) this.ui.seeClaim(tiles, player, claim);
    }
    /**
     * Signal that the current player is done.
     */
    nextPlayer() {
      if (this.ui) this.ui.nextPlayer();
    }
    getAvailableTiles() {
      return this.tiles;
    }
    getSingleTileFromHand(tile) {
      return this.tiles.find((t) => t.getTileFace() == tile);
    }
    getAllTilesInHand(tile) {
      return this.tiles.filter((t) => t.getTileFace() == tile);
    }
    getTiles(allTiles) {
      return allTiles ? [...this.tiles, ...this.bonus] : this.tiles;
    }
    getTileFaces(allTiles) {
      return this.getTiles(allTiles).map((t) => t.getTileFace ? t.getTileFace() : t).sort((a, b) => a - b);
    }
    getLockedTileFaces() {
      return this.locked.map((set) => `[${set.map((v) => v.getTileFace()).sort((a, b) => a - b)}]${set.winning ? "!" : ""}`);
    }
    sortTiles() {
      if (this.ui) this.ui.sortTiles();
    }
    /**
     * Check whether a chow can be formed using `tile` from
     * player with id `pid`, by looking at our hand tiles.
     */
    async chowExists(pid, tile) {
      if (tile > 26) return CLAIM.IGNORE;
      let next = (pid + 1) % 4;
      let valid = next == this.id;
      if (!valid) return CLAIM.IGNORE;
      let tiles = this.getTileFaces();
      let face = tile % 9;
      let tm2 = face > 1 ? tiles.indexOf(tile - 2) >= 0 : false;
      let tm1 = face > 0 ? tiles.indexOf(tile - 1) >= 0 : false;
      let t1 = face < 8 ? tiles.indexOf(tile + 1) >= 0 : false;
      let t2 = face < 7 ? tiles.indexOf(tile + 2) >= 0 : false;
      let c1 = t1 && t2;
      let c2 = tm1 && t1;
      let c3 = tm2 && tm1;
      if (c1) return CLAIM.CHOW1;
      if (c3) return CLAIM.CHOW3;
      if (c2) return CLAIM.CHOW2;
      return CLAIM.IGNORE;
    }
  };

  // src/js/core/utils/task-timer.js
  var TaskTimer = class _TaskTimer {
    static id = 0;
    static timers = {};
    /**
     * Create a timed task monitor.
     *
     * @param {function} startWaiting the function that gets called when the task timer starts, with the timer itself as function argument.
     * @param {function} timeoutFunction the function that will get called if the allocated task time runs out.
     * @param {milliseconds} timeoutInterval the timeout interval in milliseconds.
     * @param {function} signalHandler (optional) function that can be called at regular intervals over the course of the timeout.
     * @param {int} signalCount (optional) the number of signals to send over the course of the timeout, INCLUDING signal "0" at the start.
     */
    constructor(startWaiting, timeoutFunction, timeoutInterval, signalHandler = false, signalCount = 0) {
      this.id = _TaskTimer.id++;
      this.paused = false;
      this.created = Date.now();
      this.overrideKickedIn = false;
      this.timeoutInterval = timeoutInterval;
      this.timeoutFunction = () => {
        _TaskTimer.__forget__(this);
        timeoutFunction();
      };
      if (signalHandler && signalCount > 0) {
        this.signalHandler = signalHandler;
        this.totalSignalCount = signalCount + 1;
        if (this.totalSignalCount < 1) this.totalSignalCount = 1;
        this.signalCount = this.totalSignalCount;
        this.sendSignal();
      }
      setTimeout(() => startWaiting(this), 0);
      this.startTimeout();
      _TaskTimer.__record__(this);
    }
    /**
     * Class function: record this timer in the list of active timers.
     */
    static __record__(timer2) {
      _TaskTimer.timers[timer2.id] = timer2;
    }
    /**
     * Class function: remove this timer from the list of active timers.
     */
    static __forget__(timer2) {
      delete _TaskTimer.timers[timer2.id];
    }
    /**
     * activate the override function
     */
    startTimeout() {
      this.overrideTrigger = setTimeout(() => {
        this.overrideKickedIn = true;
        this.timeoutFunction();
      }, this.timeoutInterval);
    }
    /**
     * send a regular(ish) signal while the timeout is active.
     */
    sendSignal() {
      let handler = this.signalHandler;
      if (!handler) return;
      let signalNumber = this.totalSignalCount - this.signalCount--;
      handler(signalNumber);
      if (!this.isPaused() && this.signalCount > 0) {
        let elapsed = Date.now() - this.created;
        let remaining = this.timeoutInterval - elapsed;
        let timeoutValue = remaining / this.signalCount;
        this.nextSignal = setTimeout(() => this.sendSignal(), timeoutValue);
      }
    }
    /**
     * has this timer timed out?
     */
    hasTimedOut() {
      return this.overrideKickedIn;
    }
    /**
     * cancel the timeout part of this timer, and
     * remove it from the list of active timers,
     * as the "timer" part no longer applies.
     *
     * If `__preserveTimer` is true, this timer
     * is not removed from the list of known
     * timers, which is important, because the
     * `pause()` function relies on  `cancel()`!
     */
    cancel(__preserveTimer) {
      if (this.nextSignal) clearTimeout(this.nextSignal);
      if (!this.overrideKickedIn) {
        clearTimeout(this.overrideTrigger);
        if (!__preserveTimer) {
          if (this.signalHandler) this.signalHandler(this.totalSignalCount - 1);
          _TaskTimer.__forget__(this);
        }
      }
    }
    /**
     * Is this timer currently paused? If so,
     * return the promise for await'ing purposes.
     */
    isPaused() {
      return this.paused;
    }
    /**
     * Temporarily suspend this timer's timeout.
     */
    pause() {
      this.cancel(true);
      let elapsed = Date.now() - this.created;
      this.timeoutInterval = this.timeoutInterval - elapsed;
      let resolver = (resolve) => this._resolve_pause_lock = resolve;
      this.paused = new Promise(resolver);
      return this.paused;
    }
    /**
     * Resume this timer's timeout.
     */
    resume() {
      if (this._resolve_pause_lock) {
        this.paused = false;
        this.created = Date.now();
        this._resolve_pause_lock();
        this.startTimeout();
        this.sendSignal();
      }
    }
    /**
     * Class function: pause all known timers.
     */
    static pause() {
      for (timer of _TaskTimer.timers) timer.pause();
      if (!_TaskTimer.paused) {
        let resolver = (resolve) => _TaskTimer._resolve_pause_lock = resolve;
        _TaskTimer.paused = new Promise(resolver);
      }
      return _TaskTimer.paused;
    }
    /**
     * Class function: resume all known timers.
     */
    static resume() {
      _TaskTimer._resolve_pause_lock();
      _TaskTimer.paused = false;
      for (timer of _TaskTimer.timers) timer.resume();
    }
  };
  TaskTimer.id = 0;
  TaskTimer.timers = {};

  // src/js/core/players/player.js
  var Player = class extends PlayerMaster {
    constructor(id) {
      super(id);
    }
    async getDiscard(tilesRemaining, resolve) {
      let resolveProxy = (discard) => {
        this.discards.push(discard);
        resolve(discard);
      };
      return this.determineDiscard(tilesRemaining, resolveProxy);
    }
    /**
     * players have a way to determine what the discard,
     * but we're not going to specify _how_ to determine
     * that here. We'll leave that up to the specific
     * player types instead.
     */
    determineDiscard(tilesRemaining, resolve) {
      resolve(void 0);
    }
    /**
     * In terms of universal behaviour, we want
     * to make sure that we exit early if this is
     * "our own" discard. No bidding on that please.
     */
    async getClaim(pid, discard, tilesRemaining, resolve) {
      if (pid == this.id) return resolve({ claimtype: CLAIM2.IGNORE });
      new TaskTimer(
        (timer2) => {
          let claimfn = (claim) => timer2.hasTimedOut() ? false : resolve(claim);
          let cancelfn = () => timer2.cancel();
          this.determineClaim(pid, discard, tilesRemaining, claimfn, cancelfn, timer2);
        },
        () => resolve({ claimtype: CLAIM2.IGNORE }),
        config.CLAIM_INTERVAL
      );
    }
    /**
     * Just like determineDiscard, players have a way
     * to determine whether they want a discard, and
     * for what, but we're not going to say how to
     * determine that in this class.
     */
    determineClaim(pid, discard, tilesRemaining, resolve, interrupt, claimTimer) {
      resolve({ claimtype: CLAIM2.IGNORE });
    }
    /**
     * Handle receiving a tile in order to fulfill a
     * claim that was put out on a discard by this
     * player during a play turn.
     */
    receiveDiscardForClaim(claim, discard) {
      this.lastClaim = claim;
      let tile = discard.getTileFace();
      let claimtype = claim.claimtype;
      let set = [];
      set.push(discard);
      set.locked = true;
      if (claimtype === CLAIM2.WIN) {
        this.markWinner();
        if (!set.winning) claimtype = claim.wintype;
        set.winning = true;
        if (claimtype === CLAIM2.CHOW) {
          claimtype = convertSubtypeToClaim(claimtype);
        }
      }
      this.append(discard, true);
      discard.lock();
      if (this.has_won) discard.winning();
      if (claimtype === CLAIM2.PAIR || claimtype === CLAIM2.PUNG || claimtype === CLAIM2.KONG) {
        let count = 0;
        if (claimtype === CLAIM2.PAIR) count = 1;
        if (claimtype === CLAIM2.PUNG) count = 2;
        if (claimtype === CLAIM2.KONG) count = 3;
        let tiles = this.getAllTilesInHand(tile);
        tiles = Array.from(tiles).slice(0, count);
        Array.from(tiles).forEach((t) => {
          if (t.getTileFace() == tile) {
            t.reveal();
            t.lock();
            if (this.has_won) t.winning();
            set.push(t);
          }
        });
        this.lockClaim(set);
        return set;
      }
      let t1, t2;
      if (claimtype === CLAIM2.CHOW1) {
        t1 = this.getSingleTileFromHand(tile + 2);
        t2 = this.getSingleTileFromHand(tile + 1);
      } else if (claimtype === CLAIM2.CHOW2) {
        t1 = this.getSingleTileFromHand(tile + 1);
        t2 = this.getSingleTileFromHand(tile - 1);
      } else if (claimtype === CLAIM2.CHOW3) {
        t1 = this.getSingleTileFromHand(tile - 1);
        t2 = this.getSingleTileFromHand(tile - 2);
      }
      [t1, t2].forEach((t) => {
        t.reveal();
        t.lock();
        if (this.has_won) t.winning();
        set.push(t);
      });
      this.lockClaim(set);
      return set;
    }
    /**
     * Lock away a set of tiles, for all
     * to see and know about.
     */
    lockClaim(tiles, concealed = false) {
      let kong = tiles.length === 4;
      tiles.forEach((tile) => {
        this.remove(tile);
        tile.unmark("latest");
        tile.setTitle(``);
        tile.lock();
        if (kong) tile.conceal();
      });
      if (kong && !concealed) {
        delete tiles[0].conceal();
      }
      this.locked.push(tiles);
      if (this.ui) this.ui.lockClaim(tiles);
    }
  };

  // src/js/core/players/personality/stats.js
  function buildStatsContainer(player) {
    let tiles = player.tiles.map((t) => t.getTileFace()).sort();
    let locked = player.locked.map((s) => s.map((t) => t.getTileFace()).sort());
    let tileCount = new Array(42).fill(0);
    let suit = (t) => t / 9 | 0;
    let stats = {
      cpairs: 0,
      // connected pairs: {t,t+1} or {t,t+2}
      pairs: 0,
      chows: 0,
      pungs: 0,
      bigpungs: 0,
      // dragons, own wind, wotr
      tiles: 0,
      // how many tiles total
      counts: {},
      // tile->howmany tracking object
      numerals: 0,
      terminals: 0,
      honours: 0,
      winds: 0,
      dragons: 0,
      suits: [0, 0, 0],
      // Separate container specific to locked sets:
      locked: { chows: 0, pungs: 0, bigpungs: 0, tiles: 0, numerals: 0, suits: [0, 0, 0] }
    };
    locked.forEach((set) => {
      let tileNumber = set[0];
      if (tileNumber === set[1]) {
        stats.pungs++;
        stats.locked.pungs++;
        if (tileNumber < 27) {
          stats.numerals += set.length;
          stats.locked.numerals += set.length;
          stats.suits[suit(tileNumber)]++;
          stats.locked.suits[suit(tileNumber)]++;
        }
        if (tileNumber + 27 === player.wind) {
          stats.bigpungs++;
          stats.locked.bigpungs++;
        }
        if (tileNumber + 27 === player.windOfTheRound) {
          stats.bigpungs++;
          stats.locked.bigpungs++;
        }
        if (tileNumber > 30) {
          stats.bigpungs++;
          stats.locked.bigpungs++;
        }
      } else {
        stats.chows++;
        stats.locked.chows++;
        stats.numerals += set.length;
        stats.locked.numerals += set.length;
        stats.suits[suit(tileNumber)]++;
        stats.locked.suits[suit(tileNumber)]++;
      }
      stats.tiles += set.length;
      stats.locked.tiles += set.length;
    });
    tiles.forEach((tileNumber) => {
      if (tileNumber <= 26) {
        stats.numerals++;
        let face = tileNumber % 9;
        if (face === 0 || face === 8) stats.terminals++;
        stats.suits[suit(tileNumber)]++;
      } else {
        stats.honours++;
        if (26 < tileNumber && tileNumber <= 30) stats.winds++;
        if (30 < tileNumber && tileNumber <= 33) stats.dragons++;
      }
      tileCount[tileNumber]++;
      stats.tiles++;
      if (!stats.counts[tileNumber]) stats.counts[tileNumber] = 0;
      stats.counts[tileNumber]++;
    });
    tileCount.forEach((count, tileNumber) => {
      if (count && tileNumber <= 24) {
        let c2, c3;
        let tsuit = suit(tileNumber);
        let t2 = tileNumber + 1;
        if (suit(t2) === tsuit) {
          c2 = tileCount[t2];
          let t3 = tileNumber + 2;
          if (suit(t3) === tsuit) {
            c3 = tileCount[t3];
          }
        }
        if (c2 && c3) stats.chows++;
        else if (c2 || c3) stats.cpairs++;
      }
      if (count === 2) stats.pairs++;
      if (count >= 3) {
        stats.pungs++;
        if (tileNumber + 27 === player.wind) {
          stats.bigpungs++;
        }
        if (tileNumber + 27 === player.windOfTheRound) {
          stats.bigpungs++;
        }
        if (tileNumber > 30) {
          stats.bigpungs++;
        }
      }
    });
    return stats;
  }

  // src/js/core/players/personality/personality.js
  var Personality = class {
    constructor(player) {
      this.player = player;
      this.allowScoringChicken = true;
      this.cleanThreshold_low = 0.6;
      this.cleanThreshold_high = 0.7;
      this.playClean = false;
      this.playChowHand = false;
      this.chickenThreshold = config.BOT_CHICKEN_THRESHOLD;
      this.chicken = false;
      this.basePanicThreshold = 16;
      this.panicThreshold = this.basePanicThreshold;
    }
    /**
     * Check whether we should just start chickening.
     */
    checkChicken(tilesRemaining) {
      if (this.chicken) return;
      if (this.chickenThreshold < 1 && tilesRemaining < this.panicThreshold) {
        this.chickenThreshold += this.chickenThreshold;
      }
      if (config.PRNG.nextFloat() < this.chickenThreshold) {
        this.chicken = true;
        let notice = `player ${this.player.id} will be going for chicken hands at ${tilesRemaining} tiles left!`;
        console.log(notice);
        config.log(notice);
      }
    }
    // utility function
    suit(t) {
      return t / 9 | 0;
    }
    /**
     * Decide how panicky we are, based on the number
     * of draws we've seen for this hand so far.
     */
    setDraws(draws = 0) {
      this.panicThreshold = this.basePanicThreshold + draws * this.basePanicThreshold;
      console.debug(`panic for ${this.player.id} set to ${this.panicThreshold}`);
    }
    /**
     * Analyze the start tiles in a hand, to see what a
     * reasonable policy is going to be for these tiles.
     */
    determinePersonality() {
      this.chickenThreshold = config.BOT_CHICKEN_THRESHOLD;
      this.chicken = false;
      this.analyse();
    }
    /**
     * Decide what an acceptable play policy is.
     */
    analyse() {
      let player = this.player;
      let stats = buildStatsContainer(player);
      let most = max(...stats.suits);
      let total = stats.numerals;
      if (this.playClean === false && !this.stopClean && most / total > this.cleanThreshold_high) {
        this.playClean = stats.suits.indexOf(most);
        console.debug(`${player.id} will play clean (${this.playClean})`);
      }
      if (this.playClean !== false) {
        if (player.locked.length > 0) {
          let mismatch = player.locked.some((set) => set[0].getTileFace() !== this.playClean);
          if (mismatch) {
            this.playClean = false;
          }
        }
        if (most / total < this.cleanThreshold_low) {
          this.playClean = false;
        }
        if (this.playClean === false) {
          this.stopClean = true;
          console.debug(`${player.id} will stop trying to play clean.`);
        }
      }
      if (!player.locked.length) {
        let chowScore = stats.cpairs / 2 + stats.chows;
        this.playChowHand = stats.honours <= 3 && chowScore >= 2 && stats.pungs < stats.chows;
      }
      return stats;
    }
    /**
     * Do we want a particular tile?
     */
    want(tileNumber, reason, tilesRemaining) {
      this.checkChicken(tilesRemaining);
      if (this.chicken) {
        console.debug(this.player.id, "is going for chickens");
        return true;
      }
      let stats = this.analyse();
      if (false === this.checkClean(tileNumber, reason, tilesRemaining)) return false;
      if (!this.checkChow(tileNumber, reason, tilesRemaining, stats)) return false;
      if (!this.checkPung(tileNumber, reason, tilesRemaining, stats)) return false;
      return true;
    }
    /**
     * Would claiming this tile violate our clean policy? (if we don't have
     * one set, then obviously the answer is "no").
     */
    checkClean(tileNumber, reason, tilesRemaining, stats = false) {
      if (this.playClean !== false && tileNumber < 27) {
        let tilesuit = this.suit(tileNumber);
        if (tilesuit !== this.playClean) {
          console.debug(this.player.id, "not claiming ", tileNumber, "due to playing clean", "(", tilesRemaining, "left)");
          return false;
        }
      }
      if (stats) {
        console.debug(this.player.id, `checkClean with stats`.stats);
        let scount = stats.suits.reduce((t, v) => v > 0 ? t + 1 : t, 0);
        if (scount > 1) {
          console.debug(this.player.id, `trying to win clean, so we can't claim ${tileNumber} to win`);
          console.debug(this.player.id, this.playClean, tileNumber);
          if (reason >= CLAIM2.CHOW) {
            console.debug(this.player.id, `claim ${reason}`);
            return reason;
          }
          console.debug(this.player.id, `no claim`);
          return false;
        }
      }
      return true;
    }
    /**
     * Can we declare a chow, given the play policy we've settled on at this point?
     */
    checkChow(tileNumber, reason, tilesRemaining, stats) {
      if (CLAIM2.CHOW <= reason && reason < CLAIM2.PUNG) {
        let canChicken = this.allowScoringChicken && (stats.bigpungs > 0 || stats.locked.bigpungs > 0);
        if (stats.locked.pungs > 0 && !canChicken) {
          console.debug(this.player.id, "not claiming chow because we have a pung", "(", tilesRemaining, "left)");
          return false;
        }
      }
      return true;
    }
    /**
     * Can we declare a pung/kong, given the play policy we've settled on at this point?
     */
    checkPung(tileNumber, reason, tilesRemaining, stats) {
      if (reason === CLAIM2.PUNG || reason === CLAIM2.KONG) {
        let canChicken = this.allowScoringChicken && (stats.bigpungs > 0 || stats.locked.bigpungs > 0);
        let isBig = tileNumber + 27 === this.player.wind || tileNumber + 27 === this.player.windOfTheRound || tileNumber > 30;
        if ((this.playChowHand || stats.locked.chows) > 0 && !canChicken && !isBig) {
          console.debug(this.player.id, "not claiming pung/kong because we have a chow, and", tileNumber, "is not scoring", "(", tilesRemaining, "left)");
          return false;
        }
      }
      return true;
    }
    /**
     * Do we want to win on a particular tile?
     */
    determineWhetherToWin(tileNumber, reason, tilesRemaining) {
      this.checkChicken(tilesRemaining);
      if (this.chicken) {
        console.debug(this.player.id, "is going for chickens");
        return true;
      }
      let stats = this.analyse();
      let cleancheck = this.checkClean(tileNumber, reason, tilesRemaining, stats);
      if (cleancheck !== true) return cleancheck;
      if (!this.checkChow(tileNumber, reason, tilesRemaining, stats)) return false;
      if (!this.checkPung(tileNumber, reason, tilesRemaining, stats)) return false;
      return true;
    }
    /**
     * When this function is called, the player HAS a winning hand,
     * but it doesn't know whether it's valid in terms of play policy
     * yet (e.g. winning on a chow when going for a pung hand).
     */
    isValidWin(tilesRemaining) {
      this.checkChicken(tilesRemaining);
      if (this.chicken) {
        console.debug(this.player.id, "is going for chickens");
        return true;
      }
      let stats = this.analyse();
      let canChicken = this.allowScoringChicken && (stats.bigpungs > 0 || stats.locked.bigpungs > 0);
      let scount = stats.suits.reduce((t, v) => v > 0 ? t + 1 : t, 0);
      console.debug(this.player.id, this.playClean, scount, stats);
      if (this.playClean !== false && scount > 1) {
        if (!canChicken) return false;
      }
      if (stats.pungs > 0 && stats.chows > 0) {
        if (!canChicken) return false;
      }
      return true;
    }
    /**
     * Is this tile, that is in our hand, a dead tile in terms of play
     * policy? E.g. is it a dots tile while we're trying to play clean
     * on the characters suit instead?
     */
    deadTile(tile, tilesRemaining) {
      this.checkChicken(tilesRemaining);
      if (this.chicken) return false;
      if (this.playClean !== false && tile < 27) {
        let suit = this.suit(tile);
        if (this.playClean !== suit) {
          return this.player.tiles.map((t) => this.suit(t.getTileFace())).filter((s) => s === suit).length;
        }
      }
      let stats = this.analyse();
      if (stats.locked.chows > 0 && stats.counts[tile] > 2) {
        return true;
      }
      return false;
    }
  };

  // src/js/core/players/bot.js
  var BotPlayer = class extends Player {
    constructor(id, chicken = false) {
      super(id);
      this.personality = new Personality(this);
      this.chicken = chicken;
      if (config.FORCE_OPEN_BOT_PLAY) this.enableShowTilesAnyway();
    }
    /**
     * Inform the personality object how many draws
     * we've seen for the hand we're about to play,
     * because that will change how much we'll be
     * willing to go harder-to-achieve hands.
     */
    reset(hand, wind, windOfTheRound, draws) {
      super.reset(hand, wind, windOfTheRound, draws);
      if (this.personality) {
        this.personality.setDraws(this.draws);
        if (this.chicken) this.personality.chicken = true;
      }
    }
    // We only assign this a function body in the constructor,
    // and use an empty function so that calls don't error out.
    showTilesAnyway() {
    }
    // And this is where we do that assigning.
    enableShowTilesAnyway() {
      this.showTilesAnyway = () => {
        if (!config.FORCE_OPEN_BOT_PLAY) return;
        if (globalThis.PLAYER_BANKS && this.id !== 0) {
          let bank = globalThis.PLAYER_BANKS[this.id];
          bank.innerHTML = "";
          this.getTileFaces().forEach((t) => {
            t = create(t);
            bank.appendChild(t);
          });
          this.locked.forEach((s, sid) => {
            s.forEach((t) => {
              t.lock(1 + sid);
              bank.appendChild(t);
            });
          });
          this.bonus.forEach((t) => {
            t = create(t);
            t.lock();
            bank.appendChild(t);
          });
          if (this.waiting) bank.classList.add("waiting");
          else bank.classList.remove("waiting");
          globalThis.PLAYER_BANKS.sortTiles(bank);
        }
      };
    }
    // pass-through for "show tiles anyway" functionality
    append(tile, claimed, supplement) {
      let _ = super.append(tile, claimed, supplement);
      this.showTilesAnyway();
      return _;
    }
    // pass-through for "show tiles anyway" functionality
    remove(tile) {
      super.remove(tile);
      this.showTilesAnyway();
    }
    /**
     * When real play is about to start, examine our start
     * tiles to determine the kind of plays we'll make.
     */
    playWillStart() {
      super.playWillStart();
      this.personality.determinePersonality();
    }
    /**
     * This is the override for the function that Player calls in order
     * to determine which tile to remove from the hand. The `resolve` function
     * is a promise callback that will allow the game to "unpause" itself.
     *
     * Bot discards are based on what can be meaningfully formed with the
     * tiles currently in hand, and throwing out the tile that contributes
     * the least. Tile availability based on the bot's local knowledge of
     * which tiles might still be available in the game is used to determine
     * whether things like pairs or chows can still be formed.
     *
     * Additionally, the tile value is balanced against its score potential.
     * For example, in a one-suit hand that also has a set of a second suit,
     * the potential payoff for getting rid of that already formed set may
     * outweigh the fact that the tiles involved are already contributing
     * to winning the hand.
     *
     * Note: returning an falsey value leads to the game understanding that
     * as meaning this play has won.
     */
    determineDiscard(tilesRemaining, resolve, showAllSuggestions) {
      if (this.has_won) return resolve(void 0);
      let tiles = this.getAvailableTiles();
      if (!tiles.length) return resolve(void 0);
      let { winpaths } = this.tilesNeeded();
      if (winpaths.length > 0 && this.canWinNow()) {
        if (this.personality.isValidWin(tilesRemaining)) {
          if (!this.lastClaim) {
            this.selfdraw = true;
            console.debug(`Self-drawn win for player ${this.id} on ${this.latest.getTileFace()}`);
          }
          return resolve(void 0);
        }
        this.waiting = false;
      }
      if (this.waiting) return resolve(this.determineWhatToWaitFor());
      let allTiles = this.getTileFaces(true).filter((t) => t < 34);
      let limithand = this.rules.checkForLimit(allTiles);
      if (limithand) return resolve(void 0);
      this.determineDiscardCarefully(tilesRemaining, resolve, showAllSuggestions);
    }
    /**
     * If we're waiting on a pair, then we can throw out either the
     * tile we already had, or the tile we just got. So, decide on
     * which to throw based on how nice the tile is for the hand.
     *
     * If we're _not_ waiting on a pair, but we reached this
     * function, then we're simply not interested in the tile we
     * just picked up: get rid of it.
     */
    determineWhatToWaitFor() {
      console.debug(this.id, "waiting to win but", this.latest, "is not in our wait list", this.waiting);
      let winTiles = Object.keys(this.waiting);
      if (winTiles.length === 1) {
        let tileNumber = winTiles[0] | 0;
        let ways = this.waiting[tileNumber];
        if (ways.length === 1 && ways[0] === "32s1") {
          let had = this.getSingleTileFromHand(tileNumber);
          let received = this.latest;
          console.debug(`${this.id} has two singles in hand:`, had, received);
          let tile = this.determineWhichPairTileToThrow(had, received);
          console.debug(`${this.id} wants to throw out:`, tile);
          if (tile === had) {
            let nid = received.getTileFace();
            let oid = had.getTileFace();
            console.debug(`${this.id} swapping win information from ${oid} to ${nid}`);
            this.waiting[nid] = this.waiting[oid];
            delete this.waiting[oid];
            console.debug(`${this.id} post-swap:`, this.waiting);
          }
          return tile;
        }
      }
      return this.latest;
    }
    /**
     * Determine what the inate value of a tile is in terms
     * of using it to win on a pair, given the rest of our hand.
     */
    determineWhichPairTileToThrow(had, received) {
      if (this.tracker.get(had.getTileFace()) === 0) return had;
      if (this.tracker.get(received.getTileFace()) === 0) return received;
      let tiles = this.getAvailableTiles(true).slice();
      let pos = tiles.indexOf(had);
      tiles.splice(pos, 1);
      let suits = [0, 0, 0, 0, 0];
      tiles.forEach((tile) => {
        suits[tile.getTileSuit()]++;
      });
      let hsuit = had.getTileSuit();
      let rsuit = received.getTileSuit();
      if (hsuit < 3 && suits[hsuit] === 0) return had;
      if (rsuit < 3 && suits[rsuit] === 0) return received;
      let hnum = had.getTileFace();
      let rnum = received.getTileFace();
      if (hnum > 26) {
        if (rnum > 26) {
          if (hnum > 30) return received;
          if (hnum === 27 + this.wind) return received;
          if (hnum === 27 + this.windOfTheRound) return received;
          if (rnum > 30) return had;
          if (rnum === 27 + this.wind) return had;
          if (rnum === 27 + this.windOfTheRound) return had;
          return received;
        }
        return received;
      }
      if (rnum > 26) return had;
      return received;
    }
    /**
     * This is the second part of determineDiscard, which handles all
     * the "we didn't just win" cases.
     */
    determineDiscardCarefully(tilesRemaining, resolve, showAllSuggestions) {
      let tiles = this.getAvailableTiles();
      if (this.missingSuit !== void 0) {
        let missing = this.getAvailableTiles().filter((t) => {
          let face = t.getTileFace();
          return face < 27 && (face / 9 | 0) === this.missingSuit;
        });
        if (missing.length) {
          missing.sort((a, b) => this.tracker.get(a.getTileFace()) - this.tracker.get(b.getTileFace()));
          return resolve(missing[0]);
        }
      }
      let tileCount = [];
      let immediateValue = [];
      let faces = Array.from(tiles).map((tile) => {
        let id = tile.getTileFace();
        if (!tileCount[id]) {
          tileCount[id] = 0;
        }
        tileCount[id]++;
        return id;
      });
      faces.forEach((tile) => {
        let value = 0;
        let availability = this.tracker.get(tile);
        let deadScore = this.personality.deadTile(tile, tilesRemaining);
        if (deadScore) return immediateValue[tile] = deadScore;
        if (tileCount[tile] >= 3) value = max(value, availability > 0 ? 100 : 90);
        else if (tileCount[tile] === 2) value = max(value, availability > 0 ? 90 : 50);
        else if (tileCount[tile] === 1) {
          if (tile < 27)
            value = max(value, this.determineDiscardValueForChow(value, tile, tileCount));
          if (tile === 27 + this.wind || tile === 27 + this.windOfTheRound || tile > 30)
            value = max(value, availability > 0 ? 45 : 0);
          if (tile === 27 + this.wind && tile === 27 + this.windOfTheRound)
            value = max(value, availability > 0 ? 60 : 0);
        }
        immediateValue[tile] = value;
      });
      let sorted = immediateValue.map((score, tile) => ({ tile, score })).sort((a, b) => {
        let diff = a.score - b.score;
        if (diff !== 0) return diff;
        return a.tile - b.tile;
      });
      let lowest = sorted[0];
      let candidates = sorted.filter((v) => v.score === lowest.score);
      if (showAllSuggestions) {
        return resolve(candidates.map((candidate2) => this.getSingleTileFromHand(candidate2.tile)));
      }
      let idx = Math.floor(config.PRNG.nextFloat() * candidates.length);
      let candidate = candidates[idx].tile;
      resolve(this.getSingleTileFromHand(candidate));
    }
    /**
     * determineDiscard helper function dedicated to determining
     * whether chows are an option or not.
     */
    determineDiscardValueForChow(value, tile, tileCount) {
      let face = tile % 9;
      let m2 = face > 1 && tileCount[tile - 2];
      let m1 = face > 0 && tileCount[tile - 1];
      let p1 = face < 8 && tileCount[tile + 1];
      let p2 = face < 7 && tileCount[tile + 2];
      let m2a = this.tracker.get(tile - 2);
      let m1a = this.tracker.get(tile - 1);
      let p1a = this.tracker.get(tile + 1);
      let p2a = this.tracker.get(tile + 2);
      if (face < 7) {
        if (p1 && p2) value = max(value, 90);
        else if (p1 && p2a) value = max(value, 80);
        else if (p1a && p2) value = max(value, 70);
      }
      if (face > 0 && face < 8) {
        if (m1 && p1) value = max(value, 90);
        else if (m1 && p1a) value = max(value, 80);
        else if (m1a && p1) value = max(value, 80);
      }
      if (face > 1) {
        if (m2 && m1) value = max(value, 90);
        else if (m2 && m1a) value = max(value, 70);
        else if (m2a && m1) value = max(value, 80);
      }
      if (value === 0) {
        for (let i = 3, c1, c2; i <= 8; i++) {
          c1 = tileCount[tile - i] && (tile - i) % 9 < face;
          c2 = tileCount[tile + i] && (tile + i) % 9 > face;
          if (c1 || c2) return 8 - i;
        }
      }
      return value;
    }
    /**
     * Automated claim policy
     */
    async determineClaim(pid, discard, tilesRemaining, resolve, interrupt, claimTimer) {
      let ignore = { claimtype: CLAIM2.IGNORE };
      let tile = discard.getTileFace();
      let mayChow = this.mayChow(pid);
      let canWin = this.canWinNow();
      if (this.rules && this.rules.missing_suit && this.missingSuit !== void 0 && tile < 27 && (tile / 9 | 0) === this.missingSuit) {
        return resolve(ignore);
      }
      let tiles = this.getTileFaces();
      tiles.sort();
      let { lookout, waiting } = this.tilesNeeded();
      if (waiting) {
        let winTiles = {};
        lookout.forEach((list, tileNumber) => {
          if (list) {
            list = list.filter((v) => v.indexOf("32") === 0);
            if (list.length) winTiles[tileNumber] = list;
          }
        });
        this.markWaiting(winTiles);
        console.debug(this.id, "waiting to win", winTiles, this.getTileFaces(), this.getLockedTileFaces(), "tile", tile, "in list?", winTiles[tile]);
        let ways = winTiles[tile] || [];
        if (!ways.length || !canWin) {
          if (lookout[tile] && lookout[tile].indexOf("16") !== -1) {
            let allowed = this.personality.want(tile, CLAIM2.KONG, tilesRemaining);
            console.debug(`${this.id} wants to claim a kong ${tile} - allowed by policy? ${allowed}`);
            if (allowed) return resolve({ claimtype: CLAIM2.KONG });
          }
          resolve(ignore);
        } else {
          let wintype2 = ways.map((v) => parseInt(v.substring(3))).sort((a, b) => b - a)[0];
          let allowed = this.personality.determineWhetherToWin(tile, wintype2, tilesRemaining);
          if (allowed === false) return resolve(ignore);
          if (allowed === wintype2) {
            if (CLAIM2.CHOW <= allowed && allowed < CLAIM2.PUNG && !mayChow) {
              return resolve(ignore);
            }
            return resolve({ claimtype: allowed });
          }
          return resolve({ claimtype: CLAIM2.WIN, wintype: wintype2 });
        }
      }
      if (lookout[tile]) {
        let claims = lookout[tile].map((print) => unhash2(print, tile)).map((set) => {
          let type = set.type;
          console.debug(`lookout for ${tile} = type: ${type}, mayChow: ${mayChow}`);
          if (type === Constants.CHOW1 || type === Constants.CHOW2 || type === Constants.CHOW3) {
            if (!mayChow) return;
          }
          if (type === CLAIM2.WIN && !canWin) return false;
          if (!this.personality.want(tile, type, tilesRemaining)) return false;
          if (type === CLAIM2.WIN) wintype = set.subtype ? set.subtype : "normal";
          return { claimtype: type };
        });
        claims = claims.filter((v) => v).sort((a, b) => b.claimtype - a.claimtype);
        if (!claims.length) return resolve(ignore);
        return resolve(claims[0]);
      }
      return resolve(ignore);
    }
    /**
     * Check whether this player has, and if so,
     * wants to declare, a kong.
     */
    async checkKong() {
      if (this.ui && !config.BOT_PLAY) return false;
      let tiles = this.getTileFaces();
      let counts = new Array(34).fill(0);
      tiles.forEach((t) => counts[t]++);
      for (let tile = 0, e = 27, count; tile < e; tile++) {
        if (this.missingSuit !== void 0 && (tile / 9 | 0) === this.missingSuit) continue;
        count = counts[tile];
        if (count === 4) {
          let tiles2 = this.tiles.filter((t) => t.getTileFace() == tile);
          this.lockClaim(tiles2);
          return tiles2;
        }
      }
      return false;
    }
    /**
     * See if this bot wants to rob the kong that was
     * just played in order to win the current hand.
     */
    robKong(pid, tiles, tilesRemaining, resolve) {
      let { lookout, waiting } = this.tilesNeeded();
      if (waiting) {
        let tile = tiles[0].getTileFace();
        let need = lookout[tile];
        if (need && need.some((v) => v.indexOf("32") === 0)) {
          let reasons = need.filter((v) => v.indexOf("32") === 0).map((v) => parseInt(v.replace("32s", "")));
          if (reasons.length > 0) {
            let reason = reasons[0];
            if (reasons.length > 1) {
              reasons.sort((a, b) => a - b);
              reason = reasons[0];
              if (reason >= CLAIM2.CHOW && reason <= CLAIM2.PUNG) {
                if (reasons.indexOf(CLAIM2.PUNG) > 0) {
                  let chows = true;
                  let pungs = true;
                  this.locked.forEach((set) => {
                    if (set[0].getTileFace() !== set[1].getTileFace()) pungs = false;
                    else chows = false;
                  });
                  if (chows && !pungs) {
                    reason = reasons[0];
                  }
                  if (!chows && pungs) {
                    reason = CLAIM2.PUNG;
                  }
                  if (!chows && !pungs) {
                    reason = CLAIM2.PUNG;
                  }
                }
              }
            }
            if (this.personality.determineWhetherToWin(tile, reason, tilesRemaining)) return resolve({
              claimtype: CLAIM2.WIN,
              wintype: reason,
              from: pid,
              tile,
              by: this.id
            });
          }
        }
      }
      resolve();
    }
  };

  // src/js/page/audio.js
  var filenames = {
    thud: [
      `play-01.mp3`,
      `play-02.mp3`,
      `play-03.mp3`,
      `play-04.mp3`,
      `play-05.mp3`,
      `play-06.mp3`,
      `play-07.mp3`
    ],
    click: [
      `click-01.mp3`,
      `click-02.mp3`,
      `click-03.mp3`,
      `click2-01.mp3`,
      `click2-02.mp3`
    ],
    multi: [`click-multi-01.mp3`, `click-multi-02.mp3`, `click-multi-03.mp3`],
    kong: [`click-multi-large-01.mp3`, `click-multi-large-02.mp3`],
    start: [`start.mp3`],
    win: [`win.mp3`],
    draw: [`draw.mp3`],
    end: [`end.mp3`]
  };
  var buildBin = (filename) => {
    let audio = document.createElement("audio");
    audio.src = `audio/${filename}`;
    audio.type = `mp3`;
    return audio;
  };
  var clips = {};
  Object.keys(filenames).forEach(
    (bin) => clips[bin] = filenames[bin].map(buildBin)
  );
  function playClip(name, id) {
    if (!config.USE_SOUND) return;
    let bin = clips[name];
    if (!bin) {
      return console.error(`audio bin ${name} does not exist`);
    }
    let pos = id || random(bin.length);
    let audio = bin[pos];
    if (!audio) {
      return console.error(`audio bin ${name} does not have a clip ${pos}`);
    }
    audio.cloneNode().play();
  }

  // src/js/core/players/ui/windicator.js
  var rotateWinds = (function generateRotateWindsFunction() {
    const winds = Array.from(document.querySelectorAll(".player-wind"));
    const indicator = document.querySelector(".windicator");
    const handcount = indicator.querySelector(".hand-counter");
    let previous = 0;
    function rotateWinds2(rules, wind = false, wotr = false, hand = "", draws = "") {
      handcount.innerHTML = `\u7B2C${1 + wotr}\u5708<br>\u7B2C${hand}\u5C40`;
      if (draws) {
        handcount.innerHTML += `<br>\u91CD\u53D1${draws}`;
      }
      let h = wotr * 4 + wind;
      if (h === previous) return;
      previous = h;
      let p = (h / 4 | 0) % 4;
      let offset = 2 * p;
      indicator.style.setProperty("--slide", offset + "em");
      if (rules.reverse_wind_direction) {
        winds.forEach((e) => {
          if (e.classList.contains("tc")) {
            e.classList.remove("tc");
            e.classList.add("lc");
          } else if (e.classList.contains("rc")) {
            e.classList.remove("rc");
            e.classList.add("tc");
          } else if (e.classList.contains("bc")) {
            e.classList.remove("bc");
            e.classList.add("rc");
          } else if (e.classList.contains("lc")) {
            e.classList.remove("lc");
            e.classList.add("bc");
          }
        });
      } else {
        winds.forEach((e) => {
          if (e.classList.contains("tc")) {
            e.classList.remove("tc");
            e.classList.add("rc");
          } else if (e.classList.contains("rc")) {
            e.classList.remove("rc");
            e.classList.add("bc");
          } else if (e.classList.contains("bc")) {
            e.classList.remove("bc");
            e.classList.add("lc");
          } else if (e.classList.contains("lc")) {
            e.classList.remove("lc");
            e.classList.add("tc");
          }
        });
      }
    }
    rotateWinds2.reset = function() {
      previous = 0;
      indicator.style.setProperty("--slide", "0em");
      winds[0].setAttribute("class", "player-wind tc e");
      winds[1].setAttribute("class", "player-wind rc");
      winds[2].setAttribute("class", "player-wind bc");
      winds[3].setAttribute("class", "player-wind lc");
      indicator.classList.remove("done");
    };
    rotateWinds2.done = function() {
      return indicator.classList.add("done");
    };
    return rotateWinds2;
  })();

  // src/js/core/players/ui/client-ui-master.js
  var ClientUIMaster = class {
    constructor(player, tracker) {
      this.player = player;
      this.tracker = tracker;
      this.tracker.setUI(this);
      this.id = player.id;
      this.discards = document.querySelector(`.discards`);
      this.playerbanks = document.querySelectorAll(`.player`);
      this.knowledge = document.querySelector(`.knowledge`);
      this.settings = document.querySelector(`.settings`);
      this.theming = document.querySelector(`.theming`);
      this.gameBoard = document.querySelector(`.board`);
      if (config.PAUSE_ON_BLUR) {
        this.gameBoard.addEventListener(`blur`, async (evt) => {
          let resume = await this.player.game.pause();
          let handleResume = () => {
            this.gameBoard.removeEventListener(`focus`, handleResume);
            resume();
            this.pause_protection = true;
          };
          this.gameBoard.addEventListener(`focus`, handleResume);
        });
      }
      this.settings.addEventListener(`click`, () => modal.pickPlaySettings());
      this.theming.addEventListener(`click`, () => modal.pickTheming());
      this.el = this.playerbanks[this.id];
      this.reset(0, 0);
      if (config.FORCE_OPEN_BOT_PLAY) {
        globalThis.PLAYER_BANKS = this.playerbanks;
        globalThis.PLAYER_BANKS.sortTiles = (e) => this.sortTiles(e);
      }
    }
    /**
     * ...docs go here...
     */
    reset(wind, windOfTheRound, hand, draws) {
      if (!this.el) return;
      this.el.setAttribute(`class`, `player`);
      this.playerbanks.forEach((b) => {
        b.innerHTML = ``;
        b.setAttribute(`class`, `player`);
      });
      this.el.innerHTML = ``;
      this.el.dataset.wind = [`\u6771`, `\u5357`, `\u897F`, `\u5317`][wind];
      let discards = this.discards;
      discards.innerHTML = ``;
      discards.setAttribute(`class`, `discards`);
      this.bar = document.createElement(`div`);
      this.bar.classList.add(`countdown-bar`);
      this.discards.appendChild(this.bar);
      let claimBar = document.querySelector(`.claim-bar`);
      if (claimBar) {
        claimBar.innerHTML = ``;
        claimBar.classList.add(`hidden`);
      }
      if (this.countdownTimer) this.countdownTimer.cancel();
      this.countdownTimer = false;
      rotateWinds(this.rules, wind, windOfTheRound, hand, draws);
    }
    /**
     * Reset the player`s tile tracker panel
     */
    resetTracker(tiles) {
      if (!this.knowledge) return;
      this.knowledge.innerHTML = ``;
      Object.keys(tiles).forEach((tile) => {
        let div = document.createElement(`div`);
        div.classList.add(`tile-count`);
        if (tile > 33) div.classList.add(`hidden`);
        for (let i = 0; i < 4; i++) {
          let e = create(tile);
          div.appendChild(e);
        }
        this.knowledge.appendChild(div);
      });
    }
    /**
     * Remove a tile from the tile tracker panel.
     */
    reduceTracker(tileNumber) {
      if (tileNumber > 33) return;
      let tile = this.knowledge.querySelector(`game-tile[tile='${tileNumber}']`);
      tile.remove();
    }
    /**
     * Bind the rules to this UI, which can be handy for
     * things like generating a rules/scoring explanation.
     */
    setRules(rules) {
      this.rules = rules;
    }
    /**
     * Effect a lock on the UI. Note that UI elements can still
     * listen for events like document.blur etc. on their own.
     */
    pause(lock) {
      this.paused = lock;
      if (this.countdownTimer) {
        this.countdownTimer.pause();
      }
      if (modal.isHidden()) {
        this.discards.classList.add(`paused`);
      }
    }
    /**
     * Release the lock on the UI.
     */
    resume() {
      this.discards.classList.remove(`paused`);
      if (this.countdownTimer) {
        this.countdownTimer.resume();
      }
      this.paused = false;
    }
    /**
     * If we need to do anything once the claim timer
     * ticks over, that can get bound here.
     */
    setClaimTimerCleanup(fn) {
      this.claimCleanup = fn;
    }
    /**
     * Start a count-down bar that signals to the user
     * that there is `some time remaining` without
     * giving them (milli)second accurate numbers.
     */
    startCountDown(ms) {
      new TaskTimer(
        (timer2) => {
          this.countdownTimer = timer2;
        },
        () => {
          this.countdownTimer = false;
        },
        ms,
        (count) => {
          let fraction = count === 10 ? 1 : count / 10;
          this.bar.style.width = `${100 - 100 * fraction}%`;
          if (fraction === 1) {
            this.bar.classList.remove(`active`);
            this.countdownTimer = false;
            if (this.claimCleanup) this.claimCleanup();
            this.claimCleanup = false;
          }
        },
        10
      );
      this.bar.classList.add(`active`);
    }
    /**
     * Triggered at the start of the game, before any hand is
     * started, so that players can be reset properly if more
     * than one game is played consecutively.
     */
    gameWillStart() {
      rotateWinds.reset();
      playClip(`start`);
      this.playerbanks.forEach((b) => {
        if (this.rules) b.dataset.score = this.rules.player_start_score;
        b.dataset.wins = 0;
      });
    }
    /**
     * Triggered after players have been dealt their initial
     * tiles, but before the first discard is prompted for.
     */
    handWillStart(redraw, resolve) {
      if (config.BOT_PLAY) return resolve();
      let heading = `\u8840\u6218\u5230\u5E95 \xB7 \u724C\u5C40\u5C31\u7EEA`;
      if (redraw) heading = `\u8840\u6218\u5230\u5E95 \xB7 \u65B0\u7684\u4E00\u5C40`;
      modal.choiceInput(heading, [{ label: `\u5F00\u6253\uFF01`, value: false }], resolve);
    }
    /**
     * Called right before play(), after all players have been given a chance
     * to declare any kongs, but right before the first player gets their
     * first player tile, to set up the first discard.
     */
    playWillStart() {
    }
    /**
     * Note how many tiles are left to be played with in the current hand.
     */
    markTilesLeft(remaining) {
      let ui = document.querySelector(`.wall.data`);
      ui.textContent = `\u5269 ${remaining} \u5F20`;
    }
    /**
     * Have the player confirm whether they want to declare
     * a self-drawn kong or not.
     */
    async confirmKong(tile, resolve) {
      if (config.BOT_PLAY) return resolve(true);
      let cancel = () => resolve(false);
      modal.choiceInput(`\u8981\u6760\u8FD9\u5F20 ${config.TILE_NAMES[tile]} \u5417\uFF1F`, [
        { label: `\u6760\uFF01`, value: `yes` },
        { label: `\u4E0D\u6760`, value: `no` }
      ], (result) => {
        if (result === `yes`) resolve(true);
        else resolve(false);
      }, cancel);
    }
    /**
     * Several actions require removing the most recent discard,
     * such as players claiming it to form sets from their hand.
     */
    removeLastDiscard() {
      if (this.discards.lastChild) {
        this.discards.removeChild(this.discards.lastChild);
      }
    }
    /**
     * Triggered when play moves from one player to another.
     */
    nextPlayer() {
      this.discards.lastChild.unmark(`selectable`);
    }
    /**
     * Utility function: checks if this player is holding (at least one of) this tile.
     */
    haveSingle(tile) {
      let tiles = this.getAllTilesInHand(tile.dataset ? tile.getTileFace() : tile);
      return tiles.length >= 1;
    }
    /**
     * Utility function: checks if this player can form a pung with this tile.
     */
    canPung(tile) {
      let tiles = this.getAllTilesInHand(tile.dataset ? tile.getTileFace() : tile);
      return tiles.length >= 2;
    }
    /**
     * Utility function: checks if this player can form a kong with this tile.
     */
    canKong(tile) {
      let tiles = this.getAllTilesInHand(tile.dataset ? tile.getTileFace() : tile);
      return tiles.length === 3;
    }
    /**
     * Utility function: checks if this player can form a particular type of
     * chow with this tile either as first, second, or third tile in the set.
     */
    canChow(tile, type) {
      tile = tile.dataset ? tile.getTileFace() : tile;
      if (tile > 26) return false;
      let face = tile % 9;
      let t1, t2;
      if (type === CLAIM2.CHOW1) {
        if (face > 6) return false;
        t1 = tile + 1;
        t2 = tile + 2;
      }
      if (type === CLAIM2.CHOW2) {
        if (face === 0 || face === 8) return false;
        t1 = tile - 1;
        t2 = tile + 1;
      }
      if (type === CLAIM2.CHOW3) {
        if (face < 2) return false;
        t1 = tile - 2;
        t2 = tile - 1;
      }
      return this.getSingleTileFromHand(t1) && this.getSingleTileFromHand(t2);
    }
    /**
     * Triggered when either the hand was a draw, or someone won,
     * with the full game disclosure available in case of a win.
     */
    endOfHand(disclosure, force_reveal_player = false) {
      if (!disclosure) {
        playClip(`draw`);
        this.discards.classList.add(`exhausted`);
        return;
      }
      if (!force_reveal_player) playClip(`win`);
      disclosure.forEach((res, id) => {
        if (id == this.id && !force_reveal_player) return;
        let bank = this.playerbanks[id];
        bank.innerHTML = ``;
        bank.setAttribute(`class`, `player`);
        res.bonus.forEach((t) => {
          t = create(t);
          t.bonus();
          bank.appendChild(t);
        });
        let locknum = 1 + this.getLockedTiles(bank).length;
        res.locked.forEach((s) => {
          s.forEach((t) => {
            let n = create(t.getTileFace());
            n.lock(locknum);
            if (t.isWinningTile()) n.winning();
            bank.appendChild(n);
          });
          locknum += s.length;
        });
        res.concealed.sort((a, b) => a - b).forEach((t) => bank.appendChild(create(t)));
        if (res.winner) {
          this.discards.classList.add(`winner`);
          bank.classList.add(`winner`);
        }
        bank.dataset.wincount = res.wincount;
        this.sortTiles(bank);
      });
    }
    /**
     * Triggered after all hands have been played and the game is over,
     * with the full score history for the game available for presenting
     * to the user.
     */
    endOfGame(scores) {
      rotateWinds.done();
      playClip(`end`);
      let v = 0, b = -1;
      scores.forEach((score, id) => {
        if (score > v) {
          v = score;
          b = id;
        }
      });
      this.playerbanks.forEach((bank, id) => {
        bank.classList.remove(`waiting`);
        bank.classList.remove(`winner`);
        if (id === b) bank.classList.add(`game-winner`);
      });
      let remove = [];
      this.playerbanks.forEach((bank) => {
        remove = [...remove, ...bank.querySelectorAll(`game-tile`)];
      });
      remove = [...remove, ...this.discards.querySelectorAll(`game-tile`)];
      remove.forEach((t) => t.parentNode.removeChild(t));
      this.playerbanks.forEach((bank) => {
        new Array(13).fill(-1).forEach((t) => bank.appendChild(create(t)));
      });
      this.tracker.reset();
    }
    /**
     * Locally record the scores for a played hand.
     */
    recordScores(scores) {
      scores.forEach((score, b) => {
        let d = this.playerbanks[b].dataset;
        if (!d.score) d.score = 0;
        d.score = parseInt(d.score) + score;
      });
    }
    /**
     * At the end of the game, people can go through the scores
     * and see which tiles weres associated with that.
     */
    loadHandPostGame(disclosure) {
      this.endOfHand(disclosure, true);
    }
    /**
     * Triggered at the start of a hand, stating which
     * hand this is, and what its wind of the round is.
     */
    markHand(hand, wind) {
      this.el.dataset.wind = [`\u6771`, `\u5357`, `\u897F`, `\u5317`][wind];
    }
    /**
     * Mark the player with `id` as the currently active player.
     */
    activate(id) {
      this.playerbanks.forEach((bank) => bank.classList.remove(`active`));
      this.playerbanks[id].classList.add(`active`);
      if (id != this.id) {
        let latest = this.el.querySelector(`game-tile.latest`);
        if (latest) latest.unmark(`latest`);
      }
    }
    /**
     * Visually unmark this player as active (this function is
     * called specifically on whoever is currently activ)
     */
    disable() {
      this.el.classList.remove(`active`);
    }
    /**
     * Visually mark this player as waiting to win.
     */
    markWaiting(val) {
      if (val) this.el.classList.add(`waiting`);
      else this.el.classList.remove(`waiting`);
    }
    /**
     * Visually mark this player as having won.
     */
    markWinner(wincount) {
      this.el.dataset.wincount = wincount;
      this.el.classList.add(`winner`);
      this.el.classList.remove(`active`);
    }
    /**
     * Add a tile to this player`s tilebank.
     */
    append(t) {
      let old = this.el.querySelector(`game-tile.latest`);
      if (old) {
        old.unmark(`latest`);
        old.setTitle(``);
      }
      if (!t.isLocked()) {
        t.mark(`latest`);
        t.setTitle(`latest tile`);
      }
      this.el.appendChild(t);
      this.sortTiles();
    }
    /**
     * Remove a tile from this player`s tile bank
     */
    remove(tile) {
      this.el.removeChild(tile);
    }
    /**
     * Show this player as locking down a set formed
     * from tiles in their hand, and the current discard
     */
    lockClaim(tiles) {
      playClip(tiles.length === 4 ? `kong` : `multi`);
      this.removeLastDiscard();
      let locknum = 1 + this.getLockedTiles().length;
      tiles.forEach((tile) => {
        tile.lock(locknum);
        this.append(tile);
      });
      this.sortTiles();
    }
    /**
     * Move the fourth tile in a locked set of three from the
     * player`s hand to that locked set.
     */
    meldKong(tile) {
      let other = this.el.querySelector(`game-tile[locked][tile='${tile.getTileFace()}']`);
      tile.lock(other.getLockNumber());
      this.el.appendChild(tile);
      this.sortTiles();
    }
    /**
     * Triggered when a player discards a tile from their hand.
     */
    playerDiscarded(player, tile, playcounter) {
      playClip(playcounter === 1 ? `thud` : `click`);
      let bank = this.playerbanks[player.id];
      console.debug(`${this.id} sees discard ${tile} from ${player.id}`);
      if (player.id != this.id) {
        let blank = bank.querySelector(`[tile='-1']`);
        if (blank) bank.removeChild(blank);
      }
      let discard = create(tile);
      discard.mark(`discard`);
      discard.setFrom(player.id);
      this.discards.appendChild(discard);
      if (!config.BOT_PLAY && player.id !== this.id) {
        this.startCountDown(config.CLAIM_INTERVAL);
      }
      this.sortTiles(bank);
    }
    /**
     * See one or more tiles being revealed by a player.
     */
    see(tiles, player) {
      console.debug(`${this.id} sees ${tiles.map((t) => t.dataset ? t.getTileFace() : t)} from ${player.id}`);
      let bank = this.playerbanks[player.id];
      let locknum = 1 + bank.querySelectorAll(`[locked]`).length;
      tiles.forEach((tile) => {
        let face = tile.dataset ? tile.getTileFace() : tile;
        if (player.id != this.id) {
          let blank = bank.querySelector(`[tile='-1']`);
          if (blank) bank.removeChild(blank);
        }
        let e = create(face);
        if (tile.isHidden && tile.isHidden()) e.hide();
        e.lock(locknum);
        bank.appendChild(e);
      });
      this.sortTiles(bank);
    }
    /**
     * see a reveal by a player specifically as a result
     * of claiminig a tile.
     *
     * This function falls through to `see()`
     */
    seeClaim(tiles, player, claim) {
      playClip(tiles.length === 4 ? `kong` : `multi`);
      let bank = this.playerbanks[player.id];
      let blank = create(-1);
      bank.appendChild(blank);
      this.removeLastDiscard();
      this.see(tiles, player);
      if (!config.BOT_PLAY) {
        this.renderClaimAnnouncement(player.id, claim.claimtype);
      }
    }
    /**
     * Take note of a player having to give up a kong
     * because someone just robbed it to win.
     */
    playerGaveUpKongTile(pid, tilenumber2) {
      let bank = this.playerbanks[pid];
      let tile = bank.querySelector(`game-tile[locked][tile='${tilenumber2}']`);
      tile.remove();
    }
    /**
     * Render a UI element that notified the user that some
     * other player claimed the discard for some purpose.
     */
    renderClaimAnnouncement(pid, claimtype) {
      let label = `win`;
      if (claimtype === 16) label = `kong`;
      if (claimtype === 8) label = `pung`;
      if (claimtype < 8) label = `chow`;
      let ann = document.createElement(`div`);
      ann.classList.add(`announcement`);
      ann.textContent = `${label}!`;
      ann.dataset.player = pid;
      let parent = document.querySelector(`.board`);
      parent.appendChild(ann);
      setTimeout(() => ann.parentNode.removeChild(ann), 2300);
    }
    /**
     * Mark the fact that a player received `a tile`,
     * but we don`t know specifically which tile.
     */
    receivedTile(player) {
      if (player.id === this.id) return;
      let bank = this.playerbanks[player.id];
      bank.append(create(-1));
      this.sortTiles(bank);
    }
    /**
     * Sort all the tiles in a player`s tile bank
     * (either the user, or one of the bot players).
     */
    sortTiles(bank) {
      bank = bank || this.el;
      Array.from(bank.querySelectorAll(`game-tile`)).sort(this.tilebank_sort_function).forEach((tile) => bank.appendChild(tile));
    }
    /**
     * Get all `locked=locked` tiles in a player`s tile bank.
     */
    getLockedTiles(bank) {
      return (bank || this.el).querySelectorAll(`game-tile[locked]`);
    }
    /**
     * Get all tiles in a player`s tile bank that are not locked, and not bonus tiles
     */
    getAvailableTiles() {
      return this.el.querySelectorAll(`game-tile:not([bonus]):not([locked])`);
    }
    /**
     * Find a single instance of a tile with the specified tile number,
     * or undefined if no such tile exists in the player`s hand.
     */
    getSingleTileFromHand(tileNumber) {
      return this.el.querySelector(`game-tile[tile='${tileNumber}']:not([locked])`);
    }
    /**
     * Get every instance of a specific tile in the player`s hand.
     */
    getAllTilesInHand(tileNumber) {
      return this.el.querySelectorAll(`game-tile[tile='${tileNumber}']:not([locked])`);
    }
    /**
     * Get either all tiles, or all `not locked` tiles.
     */
    getTiles(allTiles) {
      return this.el.querySelectorAll(`game-tile${allTiles ? `` : `:not([locked])`}`);
    }
    /**
     * Get the list of tiles as tile numbers, or all `not locked` tiles as tile numbers.
     */
    getTileFaces(allTiles) {
      return Array.from(this.getTiles(allTiles)).map((t) => t.getTileFace());
    }
    /**
     * Sort tiles ordered as:
     * 1: bonus tiles
     * 2: locked tiles, sorted
     * 3: unlocked tiles, sorted
     * 4: concealed tiles
     */
    tilebank_sort_function(a, b) {
      try {
        let la = a.getLockNumber();
        let lb = b.getLockNumber();
        a = a.getTileFace();
        b = b.getTileFace();
        if (a > 33 || b > 33) {
          if (a > 33 && b > 33) return a - b;
          if (a > 33) return -1;
          return 1;
        }
        if (la || lb) {
          if (la && lb) return la === lb ? a - b : la - lb;
          if (la) return -1;
          return 1;
        }
        if (a === -1) return 1;
        if (b === -1) return -1;
        return a - b;
      } catch (e) {
        console.log(a, b);
        console.log(a.constructor.name, b.constructor.name);
        throw e;
      }
    }
  };

  // src/js/core/players/ui/client-ui.js
  var ClientUI = class extends ClientUIMaster {
    constructor(player, tracker) {
      super(player, tracker);
      this.listeners = [];
      this.longPressTimeout = false;
    }
    listen(target, event, handler) {
      this.listeners.push({ target, event, handler });
      let opts = {};
      if (event.indexOf("touch") !== -1) opts.passive = true;
      target.addEventListener(event, handler, opts);
    }
    removeListeners(target, event) {
      let removals = this.listeners.filter((data) => data.target === target && data.event === event);
      removals.forEach((data) => {
        let opts = {};
        if (data.event.indexOf("touch") !== -1) opts.passive = true;
        data.target.removeEventListener(data.event, data.handler, opts);
      });
      this.listeners = this.listeners.filter((data) => data.target !== target || data.event !== event);
      return () => removals.forEach((data) => this.listen(data.target, data.event, data.handler));
    }
    removeAllListeners() {
      let removals = this.listeners;
      removals.forEach((data) => {
        let opts = {};
        if (data.event.indexOf("touch") !== -1) opts.passive = true;
        data.target.removeEventListener(data.event, data.handler, opts);
      });
      this.listeners = [];
      return () => removals.forEach((data) => this.listen(data.target, data.event, data.handler));
    }
    pause(lock) {
      super.pause(lock);
      if (this.claimTimer) this.claimTimer.pause();
    }
    resume() {
      super.resume();
      if (this.claimTimer) this.claimTimer.resume();
    }
    /**
     * Called by `determineDiscard` in human.js, this function
     * lets the user pick a tile to discard through the GUI.
     */
    listenForDiscard(resolve, suggestions, lastClaim, winbypass) {
      let tiles = this.getAvailableTiles();
      let missing = this.player.missingSuit;
      if (missing !== void 0) {
        let forced = Array.from(tiles).filter((t) => {
          let face = t.getTileFace();
          return face < 27 && (face / 9 | 0) === missing;
        });
        if (forced.length) tiles = forced;
      }
      let currentTile = this.currentTile = this.player.latest;
      let curid = currentTile ? Array.from(tiles).indexOf(currentTile) : 0;
      if (curid === -1) curid = 0;
      this.markCurrentTile(curid);
      this.highlightBotSuggestions(suggestions);
      if (tiles.length === 0) return resolve(void 0);
      if (lastClaim && lastClaim.claimtype === CLAIM2.WIN) return resolve(void 0);
      let { winner } = this.player.tilesNeeded();
      if (winner && !winbypass && this.player.canWinNow()) return this.askForWinConfirmation(resolve);
      tiles.forEach((tile) => tile.mark("selectable"));
      this.listen(document, "keydown", (evt) => this.listenForDiscardFromKeys(evt, tiles, suggestions, resolve));
      this.listenForDiscardFromMouse(tiles, suggestions, resolve);
    }
    /**
     * Mouse/touch interaction for discard selection.
     */
    listenForDiscardFromMouse(tiles, suggestions, resolve) {
      tiles.forEach((tile) => this.addMouseEventsToTile(tile, suggestions, resolve));
    }
    /**
     * Add both mouse and touch event handling to all
     * (discardable) tiles in the player's tilebank.
     */
    addMouseEventsToTile(tile, suggestions, resolve) {
      console.log(tile, suggestions);
      this.listen(tile, "mouseover", (evt) => this.highlightTile(tile));
      this.listen(tile, "click", (evt) => this.discardCurrentHighlightedTile(suggestions, resolve));
      this.listen(tile, "mousedown", (evt) => this.initiateLongPress(evt, suggestions, resolve));
      this.listen(tile, "touchstart", (evt) => this.initiateLongPress(evt, suggestions, resolve));
    }
    /**
     * Keyboard interaction for discard selection.
     */
    listenForDiscardFromKeys(evt, tiles, suggestions, resolve) {
      let code = evt.keyCode;
      let willBeHandled = [VK_LEFT, VK_RIGHT, VK_UP, VK_DOWN, VK_SIGNAL, VK_START, VK_END].some((supported) => supported[code]);
      if (!willBeHandled) return;
      if (VK_SIGNAL[code] && evt.repeat) return;
      evt.preventDefault();
      let tlen = tiles.length;
      let currentTile = this.currentTile;
      let curid = this.curid;
      if (VK_LEFT[code]) curid = currentTile === false ? tlen - 1 : curid === 0 ? tlen - 1 : curid - 1;
      if (VK_RIGHT[code]) curid = currentTile === false ? 0 : curid === tlen - 1 ? 0 : curid + 1;
      if (VK_START[code]) curid = 0;
      if (VK_END[code]) curid = tlen - 1;
      currentTile = this.markCurrentTile(curid);
      if (VK_UP[code] || VK_SIGNAL[code]) {
        if (!vk_signal_lock) {
          lock_vk_signal();
          this.currentTile.unmark("highlight");
          this.discardCurrentHighlightedTile(suggestions, resolve);
        }
      }
      if (VK_DOWN[code]) this.spawnDeclarationModal(suggestions, resolve);
    }
    /**
     * Highlight a particular tile
     */
    highlightTile(tile) {
      let tiles = this.getAvailableTiles();
      let curid = Array.from(tiles).indexOf(tile);
      this.markCurrentTile(curid);
    }
    /**
     * Highlight a particular tile
     */
    markCurrentTile(curid) {
      let tiles = this.getAvailableTiles();
      if (tiles.length === 0) return;
      this.curid = curid;
      this.currentTile = tiles[curid];
      tiles.forEach((tile) => tile.unmark("highlight"));
      this.currentTile.mark("highlight");
      return this.currentTile;
    }
    /**
     * Initiate a longpress timeout. This will get cancelled by
     * the discard action, as well as by touch-up events.
     */
    initiateLongPress(evt, suggestions, resolve) {
      let releaseEvents = ["mouseup", "dragend", "touchend"];
      if (evt.type === "mousedown" && evt.which !== 1) return;
      if (!this.longPressTimeout) {
        this.longPressTimeout = setTimeout(() => {
          console.log("removing document mouseup/touchend");
          releaseEvents.forEach((event) => this.removeListeners(document, event));
          this.cancelLongPress();
          let restoreClickHandling = this.removeListeners(evt.target, "click");
          this.spawnDeclarationModal(suggestions, resolve, restoreClickHandling);
        }, 1e3);
      }
      let cancelPress = (evt2) => this.cancelLongPress(evt2);
      releaseEvents.forEach((event) => this.listen(document, event, cancelPress));
    }
    /**
     * cancel a long-press timeout
     */
    cancelLongPress(evt) {
      if (this.longPressTimeout) {
        this.longPressTimeout = clearTimeout(this.longPressTimeout);
      }
    }
    /**
     * Highlight the tile that the superclass would discard if they were playing.
     */
    highlightBotSuggestions(suggestions) {
      if (config.SHOW_BOT_SUGGESTION && suggestions) {
        suggestions.forEach((suggestion) => {
          if (!suggestion) return;
          let suggestedTile = this.getSingleTileFromHand(suggestion.getTileFace());
          if (suggestedTile) {
            suggestedTile.mark("suggestion");
            suggestedTile.setTitle("Bot-recommended discard.");
          } else {
            console.log(`The bot got confused and wanted you to throw out something that's not in your hand...!`);
            console.log(suggestion);
          }
          ;
        });
      }
    }
    /**
     * The user can win with the tiles they currently have. Do they want to?
     */
    askForWinConfirmation(resolve) {
      let cancel = () => resolve(void 0);
      modal.choiceInput("\u53EF\u4EE5\u80E1\u724C\uFF0C\u8981\u80E1\u5417\uFF1F", [
        { label: "\u80E1\uFF01", value: "win" },
        { label: "\u4E0D\u80E1\uFF0C\u518D\u7B49\u7B49", value: "" }
      ], (result) => {
        if (result) {
          if (!this.player.lastClaim) {
            this.player.selfdraw = true;
          }
          resolve(void 0);
        } else this.listenForDiscard(resolve, void 0, void 0, true);
      }, cancel);
    }
    /**
     * Discard a selected tile from the player's hand
     */
    discardCurrentHighlightedTile(suggestions = [], resolve) {
      let tiles = this.getAvailableTiles();
      this.cancelLongPress();
      suggestions.forEach((suggestion) => {
        if (suggestion) {
          suggestion.unmark("suggestion");
          suggestion.setTitle("");
        }
      });
      let latest = this.player.latestTile;
      if (latest) latest.unmark("latest");
      tiles.forEach((tile) => tile.unmark("selectable", "highlight", "suggestion"));
      this.removeAllListeners();
      resolve(this.currentTile);
    }
    /**
     * Called in several places in `listenForDiscard`, this function
     * spawns a modal that allows the user to declaring they can
     * form a kong or that they have won on their own turn.
     */
    spawnDeclarationModal(suggestions, resolve, restore) {
      let currentTile = this.currentTile;
      let face = currentTile.getTileFace();
      let allInHand = this.getAllTilesInHand(face);
      let canKong = false;
      if (allInHand.length === 4) canKong = true;
      else if (this.player.locked.some((set) => set.every((t) => t.getTileFace() == face))) canKong = true;
      let { winpaths } = this.player.tilesNeeded();
      let canWin = winpaths.length > 0;
      if (!canWin) {
        let allTiles = this.getTileFaces(true).filter((t) => t < 34);
        canWin = this.player.rules.checkForLimit(allTiles);
      }
      let options = [
        { label: "on second thought, never mind", value: CLAIM2.IGNORE },
        canKong ? { label: "I'm declaring a kong", value: CLAIM2.KONG } : false,
        canWin ? { label: "I just won", value: CLAIM2.WIN } : false
      ].filter((v) => v);
      modal.choiceInput("Declare a kong or win?", options, (result) => {
        if (result === CLAIM2.IGNORE) {
          if (restore) return restore();
        }
        if (result === CLAIM2.KONG) {
          currentTile.exception = CLAIM2.KONG;
          currentTile.kong = [...allInHand];
          ;
          return this.discardCurrentHighlightedTile(suggestions, resolve);
        }
        if (result === CLAIM2.WIN) {
          this.currentTile = void 0;
          return this.discardCurrentHighlightedTile(suggestions, resolve);
        }
      });
    }
    /**
     * Called by `determineClaim` in human.js, this function
     * lets the user decide whether or not to claim the discard
     * in order to form a specific set, or even win.
     */
    listenForClaim(pid, discard, suggestion, resolve, interrupt, claimTimer) {
      let tile = this.discards.lastChild;
      let mayChow = this.player.mayChow(pid);
      this.claimTimer = claimTimer;
      this.setClaimTimerCleanup(() => {
        this.removeAllListeners();
        this.hideClaimBar();
      });
      if (config.SHOW_CLAIM_SUGGESTION) {
        this.tryClaimHighlight(pid, tile, mayChow);
      }
      if (config.SHOW_BOT_SUGGESTION && suggestion) {
        if (suggestion && suggestion.claimtype) {
          tile.mark("suggestion");
        }
      }
      this.pause_protection = false;
      this.setupInputListening(tile, mayChow, interrupt, resolve);
      this.showClaimBar(tile, mayChow, interrupt, resolve);
    }
    /**
     * 构造当前弃牌可执行的申牌动作（碰/杠/胡/过）。
     * 与 triggerClaimDialog 共用同一套判断，保证行为一致。
     */
    buildClaimActions(tile, mayChow) {
      let face = tile.getTileFace();
      let suit = face < 27 ? face / 9 | 0 : -1;
      let missing = this.player.missingSuit;
      let canClaimSuit = missing === void 0 || suit !== missing;
      let actions = [];
      if (canClaimSuit && this.canPung(tile)) actions.push({ label: "\u78B0", act: "pung", value: CLAIM2.PUNG });
      if (canClaimSuit && this.canKong(tile)) actions.push({ label: "\u6760", act: "kong", value: CLAIM2.KONG });
      if (this.player.canWinNow()) actions.push({ label: "\u80E1", act: "win", value: CLAIM2.WIN });
      actions.push({ label: "\u8FC7", act: "pass", value: CLAIM2.IGNORE });
      return actions;
    }
    /** 在牌河下方显示醒目的碰/杠/胡/过快捷按钮 */
    showClaimBar(tile, mayChow, interrupt, resolve) {
      let bar = document.querySelector(".claim-bar");
      if (!bar) return;
      let actions = this.buildClaimActions(tile, mayChow);
      if (actions.length <= 1) {
        bar.classList.add("hidden");
        return;
      }
      bar.innerHTML = "";
      actions.forEach((action) => {
        let btn = document.createElement("button");
        btn.textContent = action.label;
        btn.dataset.act = action.act;
        btn.addEventListener("click", (evt) => {
          evt.stopPropagation();
          this.registerUIInput(interrupt);
          this.removeAllListeners();
          this.hideClaimBar();
          tile.unmark("highlight");
          tile.unmark("suggestion");
          tile.unmark("selectable");
          if (action.value === CLAIM2.WIN) {
            let cancel = () => this.ignoreDiscard(tile, interrupt, resolve);
            return this.spawnWinDialog(tile, resolve, cancel);
          }
          resolve({ claimtype: action.value });
        });
        bar.appendChild(btn);
      });
      bar.classList.remove("hidden");
    }
    /** 隐藏碰/杠/胡/过快捷操作栏 */
    hideClaimBar() {
      let bar = document.querySelector(".claim-bar");
      if (bar) bar.classList.add("hidden");
    }
    /**
     * Set up all the event listening necessary to enable
     * keyboard and mouse triggers for claims.
     */
    setupInputListening(tile, mayChow, interrupt, resolve) {
      tile.mark("selectable");
      let discards = this.discards;
      this.listen(tile, "click", (evt) => this.triggerClaimDialog(tile, mayChow, interrupt, resolve));
      this.listen(discards, "click", (evt) => this.safelyIgnoreDicard(evt, tile, mayChow, interrupt, resolve));
      this.listen(discards, "mousedown", (evt) => this.verifyPauseProtection());
      this.listen(discards, "touchstart", (evt) => this.verifyPauseProtection());
      this.listen(document, "keydown", (evt) => this.handleKeyDuringClaim(evt, tile, mayChow, interrupt, resolve));
    }
    /**
     * Set the pause protection flag based on
     * the current pause state.
     */
    verifyPauseProtection() {
      if (this.paused) {
        this.pause_protection = true;
      }
    }
    /**
     * Get the distance from a click event to the
     * center of the specified tile.
     */
    getDistanceToTile(evt, tile) {
      let bbox = tile.getBoundingClientRect();
      let midpoint = { x: (bbox.left + bbox.right) / 2, y: (bbox.top + bbox.bottom) / 2 };
      let vector = { x: midpoint.x - evt.clientX, y: midpoint.y - evt.clientY };
      return Math.sqrt(vector.x ** 2 + vector.y ** 2);
    }
    /**
     * Register that user interaction has occurred.
     */
    registerUIInput(interrupt) {
      if (this.countdownTimer) this.countdownTimer.cancel();
      interrupt();
    }
    /**
     * Handle key events during listenForClaim.
     */
    handleKeyDuringClaim(evt, tile, mayChow, interrupt, resolve) {
      if (vk_signal_lock) return;
      let code = evt.keyCode;
      let willBeHandled = VK_LEFT[code] || VK_RIGHT[code] || VK_UP[code] || VK_SIGNAL[code];
      if (!willBeHandled) return;
      evt.preventDefault();
      this.removeAllListeners();
      if (VK_UP[code] || VK_SIGNAL[code]) return this.triggerClaimDialog(tile, mayChow, interrupt, resolve);
      return this.ignoreDiscard(tile, interrupt, resolve);
    }
    /**
     * Let the game know we're not interested in
     * claiming the current discard for anything.
     */
    ignoreDiscard(tile, interrupt, resolve) {
      this.registerUIInput(interrupt);
      this.hideClaimBar();
      tile.unmark("highlight");
      tile.unmark("suggestion");
      tile.unmark("selectable");
      this.removeAllListeners();
      resolve({ claimtype: CLAIM2.IGNORE });
    }
    /**
     * This adds a safety region around the discarded tile, for
     * fat fingers, as well as unpause protection (not registering
     * as real "click" if we just resumed from a paused state).
     */
    safelyIgnoreDicard(evt, tile, mayChow, interrupt, resolve) {
      if (this.pause_protection) {
        return this.pause_protection = false;
      }
      if (this.getDistanceToTile(evt, tile) > 40) {
        return this.ignoreDiscard(tile, interrupt, resolve);
      }
      this.triggerClaimDialog(tile, mayChow, interrupt, resolve);
    }
    /**
     * Can we highlight the latest discard as a signal
     * to the user that it's (technically, but not
     * necessarily practically) a claimable tile.
     */
    tryClaimHighlight(pid, tile, mayChow) {
      let face = tile.getTileFace();
      let suit = face / 9 | 0;
      let { lookout } = this.player.tilesNeeded();
      let types = lookout[face];
      if (types) {
        for (let type of types) {
          if (CLAIM2.CHOW <= type && type < CLAIM2.PUNG && !mayChow) continue;
          return tile.mark("highlight");
        }
      }
      this.tryChowHighlight(tile, mayChow, face, suit);
    }
    /**
     * If we already have a chow with this tile in it, then
     * we might not actually _need_ this tile, and so lookout
     * won't list it. Even though it's a legal claim.
     */
    tryChowHighlight(tile, mayChow, face, suit) {
      if (mayChow && face < 27 && this.getSingleTileFromHand(face)) {
        let n1 = face < 26 && this.getSingleTileFromHand(face + 1), sn1 = (face + 1) / 9 | 0, n2 = face < 25 && this.getSingleTileFromHand(face + 2), sn2 = (face + 2) / 9 | 0, p2 = face > 1 && this.getSingleTileFromHand(face - 2), sp2 = (face - 2) / 9 | 0, p1 = face > 0 && this.getSingleTileFromHand(face - 1), sp1 = (face - 1) / 9 | 0, c1 = n2 && n1 && sn2 === suit && sn1 === suit, c2 = n1 && p1 && sn1 === suit && sp1 === suit, c3 = p2 && p1 && sp2 === suit && sp1 === suit;
        if (c1 || c2 || c3) tile.mark("highlight");
      }
    }
    /**
     * Set up the dialog spawning for when the user elects to stake a claim.
     */
    triggerClaimDialog(tile, mayChow, interrupt, resolve) {
      this.registerUIInput(interrupt);
      this.removeAllListeners();
      this.hideClaimBar();
      let cancel = () => this.ignoreDiscard(tile, interrupt, resolve);
      console.debug(this.player.id, tile, mayChow, this, this.canPung(tile));
      let face = tile.getTileFace();
      let suit = face < 27 ? face / 9 | 0 : -1;
      let missing = this.player.missingSuit;
      let canClaimSuit = missing === void 0 || suit !== missing;
      modal.choiceInput("\u8981\u78B0\u3001\u6760\u8FD8\u662F\u80E1\uFF1F", [
        { label: "\u8FC7", value: CLAIM2.IGNORE },
        mayChow && this.canChow(tile, CLAIM2.CHOW1) ? { label: "\u5403 (\u25AE\u25AF\u25AF)", value: CLAIM2.CHOW1 } : false,
        mayChow && this.canChow(tile, CLAIM2.CHOW2) ? { label: "\u5403 (\u25AF\u25AE\u25AF)", value: CLAIM2.CHOW2 } : false,
        mayChow && this.canChow(tile, CLAIM2.CHOW3) ? { label: "\u5403 (\u25AF\u25AF\u25AE)", value: CLAIM2.CHOW3 } : false,
        canClaimSuit && this.canPung(tile) ? { label: "\u78B0", value: CLAIM2.PUNG } : false,
        canClaimSuit && this.canKong(tile) ? { label: "\u6760", value: CLAIM2.KONG } : false,
        this.player.canWinNow() ? { label: "\u80E1", value: CLAIM2.WIN } : false
      ], (result) => {
        tile.unmark("highlight");
        tile.unmark("suggestion");
        tile.unmark("selectable");
        this.removeAllListeners();
        if (result === CLAIM2.WIN) return this.spawnWinDialog(tile, resolve, cancel);
        resolve({ claimtype: result });
      }, cancel);
    }
    /**
     * Do we want to rob a kong to win?
     */
    spawnKongRobDialog(pid, tiles, tilesRemaining, suggestions, resolve) {
      let tile = tiles[0].getTileFace();
      let claim = false;
      if (suggestions && suggestions[0]) claim = suggestions[0];
      else {
        (() => {
          let { lookout, waiting } = this.player.tilesNeeded();
          if (!waiting) return;
          let need = lookout[tile];
          if (!need) return;
          let reasons = need.filter((v) => v.indexOf("32") !== 0);
          if (reasons.length === 0) return;
          claim = {
            from: pid,
            tile,
            claimtype: CLAIM2.WIN,
            wintype: reasons[0] | 0
          };
        })();
      }
      if (!claim) return resolve();
      modal.choiceInput("\u62A2\u6760\u80E1\uFF1F", [
        { label: "\u62A2\u6760\uFF01", value: "win" },
        { label: "\u7B97\u4E86", value: "" }
      ], (result) => {
        if (result) return resolve(claim);
        resolve();
      }, () => resolve());
    }
    /**
     * Called in `listenForClaim`, this function spawns a modal
     * that allows tlistenForClhe user to claim a discard for the purposes
     * of declaring a win.
     */
    spawnWinDialog(discard, resolve, cancel) {
      if (!this.player.canWinNow()) return cancel();
      let { lookout } = this.player.tilesNeeded();
      let winOptions = { pair: false, chow: false, pung: false };
      let claimList = lookout[discard.getTileFace()];
      if (claimList) {
        claimList.forEach((type) => {
          if (parseInt(type) === CLAIM2.WIN) {
            let subtype = parseInt(type.split("s")[1]);
            if (subtype === CLAIM2.PAIR) winOptions.pair = true;
            if (subtype >= CLAIM2.CHOW && subtype < CLAIM2.PUNG) winOptions.chow = true;
            if (subtype >= CLAIM2.PUNG) winOptions.pung = true;
          }
        });
      }
      let options = [
        { label: "\u4E0D\u80E1", value: CLAIM2.IGNORE },
        winOptions.pair ? { label: "\u5BF9\u5012", value: CLAIM2.PAIR } : false,
        winOptions.chow && this.canChow(discard, CLAIM2.CHOW1) ? { label: "\u987A\u5B50 (\u25AE\u25AF\u25AF)", value: CLAIM2.CHOW1 } : false,
        winOptions.chow && this.canChow(discard, CLAIM2.CHOW2) ? { label: "\u987A\u5B50 (\u25AF\u25AE\u25AF)", value: CLAIM2.CHOW2 } : false,
        winOptions.chow && this.canChow(discard, CLAIM2.CHOW3) ? { label: "\u987A\u5B50 (\u25AF\u25AF\u25AE)", value: CLAIM2.CHOW3 } : false,
        winOptions.pung ? { label: "\u574E\u78B0", value: CLAIM2.PUNG } : false
      ];
      modal.choiceInput("\u8FD9\u5F20\u724C\u600E\u4E48\u80E1\uFF1F", options, (result) => {
        if (result === CLAIM2.IGNORE) resolve({ claimtype: CLAIM2.IGNORE });
        else resolve({ claimtype: CLAIM2.WIN, wintype: result });
      }, cancel);
    }
  };

  // src/js/core/players/human.js
  var HumanPlayer = class extends BotPlayer {
    constructor(id, chicken = false) {
      super(id, chicken);
      this.ui = new ClientUI(this, this.tracker);
    }
    /**
     * Let the human player figure out what to discard
     * through the UI. However, have the underlying bot
     * perform their discard logic and offer the tile
     * they come with as a play suggestion.
     */
    determineDiscard(tilesRemaining, resolve) {
      const giveAllSuggestions = true;
      super.determineDiscard(tilesRemaining, (suggestion) => {
        if (config.BOT_PLAY) return resolve(suggestion && suggestion.length ? suggestion[0] : suggestion);
        if (suggestion && !suggestion.length) suggestion = [suggestion];
        this.ui.listenForDiscard((discard) => {
          if (discard) this.selfdraw = false;
          if (discard && discard.exception === CLAIM2.KONG) {
            let kong = discard.kong;
            if (kong.length === 4) this.lockClaim(kong, true);
            else this.meldKong(kong[0]);
          }
          resolve(discard);
        }, suggestion, this.lastClaim);
      }, giveAllSuggestions);
    }
    /**
     * Let the human player figure out whether to make
     * a claim through the UI. However, have the underlying
     * bot perform their claim logic and offer the claim
     * they come with as a play suggestion.
     */
    determineClaim(pid, discard, tilesRemaining, resolve, interrupt, claimTimer) {
      super.determineClaim(pid, discard, tilesRemaining, (suggestion) => {
        if (config.BOT_PLAY) return resolve(suggestion);
        this.ui.listenForClaim(pid, discard, suggestion, resolve, interrupt, claimTimer);
      });
    }
    /**
     * Let the human player figure out whether to rob a
     * kong, if it means they can win. However, have the
     * underlyaing bot perform their analysis and offer
     * their conclusion as a play suggestion.
     */
    robKong(pid, tiles, tilesRemaining, resolve) {
      super.robKong(pid, tiles, tilesRemaining, (suggestion) => {
        if (config.BOT_PLAY) return resolve(suggestion);
        this.ui.spawnKongRobDialog(pid, tiles, tilesRemaining, suggestion, resolve);
      });
    }
  };

  // src/js/core/game/wall/wall.js
  var base = [...new Array(27)].map((_, i) => i);
  var BASE = base.concat(base).concat(base).concat(base);
  var Wall = class {
    constructor(players) {
      this.players = players;
      this.reset();
    }
    // shuffle utility function, also used by WallHack
    getBase() {
      return BASE.slice();
    }
    // shuffle utility function, also used by WallHack
    shuffle(list) {
      list = list.slice();
      let shuffled = [];
      while (list.length) {
        let pos = config.PRNG.nextFloat() * list.length | 0;
        shuffled.push(list.splice(pos, 1)[0]);
      }
      return shuffled;
    }
    /**
     * Reset the wall to a full set of tiles, then shuffle them.
     */
    reset() {
      this.tiles = this.shuffle(this.getBase());
      this.deadSize = 16;
      this.dead = false;
      this.remaining = this.tiles.length - this.dead;
      if (config.WALL_HACK) {
        WallHack.set(this, WallHack.hacks[config.WALL_HACK]);
      }
    }
    /**
     * Get one or more tiles from this pile of tiles.
     */
    get(howMany = 1) {
      let left = this.tiles.length - howMany;
      this.remaining = left - this.deadSize;
      this.players.forEach((p) => p.markTilesLeft(this.remaining));
      this.dead = this.tiles.length - howMany <= this.deadSize;
      if (howMany === 1) return this.tiles.shift();
      return this.tiles.splice(0, howMany);
    }
  };

  // src/js/core/game/game.js
  var Game = class {
    constructor(players) {
      this.players = players;
      this.wall = new Wall(players);
      this.scoreHistory = [];
      this._playLock = false;
      this.GAME_START = false;
      this.resume = () => {
      };
    }
    /**
     * Start a game of mahjong!
     */
    async startGame(whenDone) {
      document.body.classList.remove(`finished`);
      this.GAME_START = Date.now();
      this.currentpid = 0;
      this.wind = 0;
      this.windOfTheRound = 0;
      this.hand = 0;
      this.draws = 0;
      this.totalDraws = 0;
      this.totalPlays = 0;
      this.finish = whenDone;
      this.rules = Ruleset.getRuleset(config.RULES);
      let players = this.players;
      await players.asyncAll((p) => p.gameWillStart(this, this.rules));
      this.fixValues = () => {
      };
      config.log(`starting game.`);
      this.startHand();
    }
    /**
     * Pause this game. Which is harder than it sounds,
     * really what this function does is it sets a
     * local lock that we can check at every point
     * in the code where we can reasonably pause.
     *
     * Being paused is then effected by waiting for
     * the lock to be released again.
     *
     * Note that the corresponding `.resume()` is
     * not part of the class definition, and is built
     * only as needed by when `pause()` is invoked.
     */
    async pause() {
      if (!this.GAME_START) return;
      console.debug("pausing game");
      let players = this.players;
      this._playLock = new Promise((resolve) => {
        this.resume = async () => {
          console.debug("resuming game");
          this._playLock = false;
          await players.asyncAll((p) => p.resume());
          resolve();
        };
      });
      await players.asyncAll((p) => p.pause(this._playLock));
      return this.resume;
    }
    /**
     * A utility function that works together with
     * the pause lock to ensure that when we're paused,
     * execution is suspended until the lock is released.
     */
    async continue(where = "unknown") {
      if (this._playLock) {
        console.debug(`paused at ${where}`);
        await this._playLock;
      }
    }
    /**
     * Triggered immediately after `startGame`, as well as
     * at the end of every `play()` cycle, this function
     * keeps getting called for as long as there are hands
     * left to play in this particular game.
     */
    async startHand(result = {}) {
      await this.continue();
      let players = this.players;
      if (result.winner) {
        let winner = result.winner;
        if (this.rules.pass_on_east_win || winner.wind !== 0) {
          let windWas = this.wind;
          this.wind = (this.wind + (this.rules.reverse_wind_direction ? 3 : 1)) % 4;
          if (windWas === (this.rules.reverse_wind_direction ? 1 : 3)) {
            this.wind = 0;
            this.windOfTheRound++;
            if (this.windOfTheRound === 4) {
              let ms = Date.now() - this.GAME_START;
              let s = (ms / 10 | 0) / 100;
              let finalScores = players.map((p) => p.getScore());
              let highest = finalScores.reduce((t, v) => v > t ? v : t, 0);
              let gamewinner = finalScores.indexOf(highest);
              console.log(`
full game played: player ${gamewinner} is the winner!`);
              console.log(`(game took ${s}s. ${this.totalPlays} plays: ${this.hand} hands, ${this.totalDraws} draws)`);
              await players.asyncAll((p) => p.endOfGame(finalScores));
              return this.finish(s);
            }
          }
        } else console.debug(`Winner player was East, winds will not rotate.`);
      }
      this.totalPlays++;
      if (!result.draw && !config.FORCE_DRAW) {
        this.hand++;
        this.draws = 0;
      } else {
        config.log(`Hand was a draw.`);
        this.draws++;
        this.totalDraws++;
      }
      await players.asyncAll((p) => {
        let offset = parseInt(p.id);
        let playerwind = (this.wind + offset) % 4;
        if (this.rules.reverse_wind_direction) {
          playerwind = (4 + this.wind - offset) % 4;
        }
        p.reset(playerwind, this.windOfTheRound, this.hand, this.draws);
      });
      if (config.PAUSE_ON_HAND && this.hand === config.PAUSE_ON_HAND) {
        config.HAND_INTERVAL = 60 * 60 * 1e3;
      }
      let pre = result.draw ? "Res" : "S";
      let logNotice = `${pre}tarting hand ${this.hand}.`;
      let style = `color: red; font-weight: bold; font-size: 120%; border-bottom: 1px solid black;`;
      console.log(`
${typeof process === "undefined" ? `%c` : ``}${logNotice}`, typeof process === "undefined" ? style : ``);
      config.log(`
${logNotice}`);
      if (this.fixValues) {
        this.fixValues();
        this.fixValues = () => {
        };
      }
      logNotice = `this.hand=${this.hand}; this.draws=${this.draws}; config.PRNG.seed(${config.PRNG.seed()}); this.wind=${this.wind}; this.windOfTheRound=${this.windOfTheRound};`;
      console.log(logNotice);
      config.log(logNotice);
      this.wall.reset();
      logNotice = `wall: ${this.wall.tiles}`;
      console.debug(logNotice);
      config.log(logNotice);
      config.log(`initial deal`);
      await this.dealTiles();
      players.forEach((p) => {
        let message = `tiles for ${p.id}: ${p.getTileFaces()}`;
        console.debug(message);
        config.log(message);
      });
      config.log(`prepare play`);
      await this.preparePlay(config.FORCE_DRAW || this.draws > 0);
      players.forEach((p) => {
        let message = `tiles for ${p.id}: ${p.getTileFaces()} [${p.getLockedTileFaces()}]`;
        console.debug(message);
        config.log(message);
      });
      await players.asyncAll((p) => p.playWillStart());
      this.PLAY_START = Date.now();
      this.play();
    }
    /**
     * Called as part of `startHand`, this function deals
     * 13 play tiles to each player, making sure that any
     * bonus tiles are compensated for.
     */
    async dealTiles() {
      await this.continue("dealTiles");
      let wall = this.wall;
      let players = this.players;
      let runDeal = async (player, done) => {
        let bank = wall.get(13);
        for (let t = 0, tile; t < bank.length; t++) {
          tile = bank[t];
          await players.asyncAll((p) => p.receivedTile(player));
          let revealed = player.append(tile);
          if (revealed) {
            await players.asyncAll((p) => p.see(revealed, player));
            bank.push(wall.get());
          }
        }
        done();
      };
      return Promise.all(players.map((p) => {
        return new Promise((done) => runDeal(p, done));
      }));
    }
    /**
     * Called as part of `startHand`, right after `dealTiles`,
     * this function preps all players for the start of actual
     * game play.
     */
    async preparePlay(redraw) {
      await this.continue("preparePlay");
      this.currentPlayerId = this.wind % 4;
      this.discard = void 0;
      this.counter = 0;
      let players = this.players;
      await Promise.all(players.map((p) => {
        return new Promise((ready) => p.handWillStart(redraw, ready));
      }));
      if (this.rules.missing_suit) {
        await Promise.all(players.map((p) => {
          return new Promise((done) => this.resolveMissingSuit(p, done));
        }));
      }
      await Promise.all(players.map((p) => {
        return new Promise((done) => this.resolveKongs(p, done));
      }));
    }
    /**
     * 四川麻将「定缺」：每位玩家声明一门要打缺的花色。
     * 手里已经缺一门时自动确定，三门都有时由玩家（或机器人）选择牌最少的一门。
     */
    async resolveMissingSuit(player, done) {
      await this.continue("resolveMissingSuit");
      let suits = player.suitsInHand();
      if (suits.size <= 2) {
        player.missingSuit = [0, 1, 2].find((s) => !suits.has(s));
        config.log(`${player.id} \u5B9A\u7F3A: ${player.missingSuit} (\u81EA\u52A8)`);
        return done();
      }
      let counts = [0, 0, 0];
      player.getTileFaces().forEach((face) => {
        if (face < 27) counts[face / 9 | 0]++;
      });
      if (player.ui && !config.BOT_PLAY) {
        let fallback = () => {
          let min2 = Math.min(...counts);
          let options = [0, 1, 2].filter((s) => counts[s] === min2);
          player.missingSuit = options[config.PRNG.nextFloat() * options.length | 0];
          done();
        };
        modal.choiceInput("\u8BF7\u5B9A\u7F3A\uFF1A\u6253\u5B8C\u8FD9\u95E8\u724C\u624D\u53EF\u4EE5\u78B0\u3001\u6760\u3001\u80E1", [
          { label: `\u6761\uFF08${counts[0]}\u5F20\uFF09`, value: 0 },
          { label: `\u4E07\uFF08${counts[1]}\u5F20\uFF09`, value: 1 },
          { label: `\u7B52\uFF08${counts[2]}\u5F20\uFF09`, value: 2 }
        ], (suit) => {
          player.missingSuit = suit;
          config.log(`${player.id} \u5B9A\u7F3A: ${suit}`);
          if (player.ui) player.ui.showMissingSuit?.(suit);
          done();
        }, fallback);
      } else {
        let min2 = Math.min(...counts);
        let options = [0, 1, 2].filter((s) => counts[s] === min2);
        player.missingSuit = options[config.PRNG.nextFloat() * options.length | 0];
        config.log(`${player.id} \u5B9A\u7F3A: ${player.missingSuit} (\u673A\u5668\u4EBA)`);
        done();
      }
    }
    /**
     * Called as the last step in `preparePlay`, to give
     * players an opportunity to declare any hidden kongs
     * before the first player gets to "draw one, play one".
     */
    async resolveKongs(player, done) {
      await this.continue("resolveKongs");
      let players = this.players;
      let kong;
      do {
        kong = await player.checkKong();
        if (kong) {
          await this.processKong(player, kong);
        }
      } while (kong);
      done();
    }
    /**
     * When a player declares a kong, show this to all other
     * players and issue them a compensation tile. Which
     * may, of course, be a bonus tile, so keep going until
     * the player no longer reveals their just-dealt tile.
     */
    async processKong(player, kong, melded = false) {
      console.debug(`${player.id} plays kong ${kong[0].getTileFace()} (melded: ${melded})`);
      config.log(`${player.id} locks [${kong.map((t) => t.getTileFace())}]`);
      let players = this.players;
      let robbed = await Promise.all(
        players.map((p) => new Promise((resolve) => p.seeKong(kong, player, this.wall.remaining, resolve)))
      );
      for (let [pid, claim] of robbed.entries()) {
        if (claim) {
          claim.by = pid;
          return claim;
        }
      }
      let revealed = false;
      do {
        let tile = this.wall.get();
        config.log(`${player.id} <  ${tile} (supplement)`);
        revealed = player.append(tile);
        if (revealed) {
          await players.asyncAll((p) => p.see(revealed, player));
        }
      } while (revealed);
    }
    /**
     * if a kong got robbed, then this hand is over and we should exit play()
     */
    async processKongRob(claim) {
      let pid = claim.from;
      let players = this.players;
      let tile = players[pid].giveUpKongTile(claim.tile);
      await players.asyncAll((p) => p.playerGaveUpKongTile(pid, claim.tile));
      let winner = players[claim.by];
      winner.robbed = true;
      this.currentPlayerId = winner.id;
      let robbed = true;
      winner.receiveDiscardForClaim(claim, tile, robbed);
      return this.processWin(winner, pid);
    }
    /**
     * This is the last call in `startHand`, and is our main game
     * loop. This function coordinates players drawing a tile
     * (either from the wall, or as a claimed discard from a
     * previous player), rewarding claims on discards, and
     * determining whether the hand has been won or drawn based
     * on whether or not players are witholding their discard,
     * or the wall has run out of tiles to deal from.
     */
    async play(claim) {
      await this.continue("start of play()");
      let hand = this.hand;
      let players = this.players;
      let wall = this.wall;
      if (claim) this.currentPlayerId = claim.p;
      let discard = this.discard;
      let discardpid = discard ? discard.getFrom() : void 0;
      let currentPlayerId = this.currentPlayerId;
      this.playDelay = hand === config.PAUSE_ON_HAND && this.counter === config.PAUSE_ON_PLAY ? 60 * 60 * 1e3 : config.PLAY_INTERVAL;
      let player = players[currentPlayerId];
      await players.asyncAll((p) => p.activate(currentPlayerId));
      this.counter++;
      console.debug(`%chand ${hand}, play ${this.counter}`, `color: red; font-weight: bold;`);
      console.debug(`current seed: ${config.PRNG.seed()}`);
      if (!claim) {
        discard = false;
        discardpid = false;
        let claim2 = await this.dealTile(player);
        if (claim2) return this.processKongRob(claim2);
      } else {
        config.log(`${player.id} <  ${discard.getTileFace()} (${claim.claimtype})`);
        let tiles = player.receiveDiscardForClaim(claim, discard);
        config.log(`${player.id} has [${player.getTileFaces()}], [${player.getLockedTileFaces()}]`);
        await players.asyncAll((p) => p.seeClaim(tiles, player, discard, claim));
        if (tiles.length === 4) {
          let kong = tiles;
          let robbed = await Promise.all(
            players.map((p) => new Promise((resolve) => p.robKong(player.id, kong, this.wall.remaining, resolve)))
          );
          for (let [pid, claim2] of robbed.entries()) {
            if (claim2) {
              claim2.by = pid;
              return this.processKongRob(claim2);
            }
          }
          await this.dealTile(player);
        }
      }
      do {
        if (discard) discard.unmark("discard");
        discard = this.discard = await new Promise((resolve) => player.getDiscard(wall.remaining, resolve));
        if (!discard) return this.processWin(player, discardpid);
        if (discard.exception === CLAIM2.KONG) {
          let kong = discard.kong;
          let melded = kong.length === 1;
          let claim2 = await this.processKong(player, kong, melded);
          if (claim2) return this.processKongRob(claim2);
          discard = false;
        }
      } while (!discard);
      await this.processDiscard(player);
      await this.continue("just before getAllClaims() in play()");
      claim = await this.getAllClaims();
      if (claim) return this.processClaim(player, claim);
      if (wall.dead) {
        console.log(`Hand ${hand} is a draw.`);
        await players.asyncAll((p) => p.endOfHand());
        let nextHand = () => this.startHand({ draw: true });
        if (!config.BOT_PLAY) {
          return modal.choiceInput("\u672C\u5C40\u6D41\u5C40", [{ label: "\u7EE7\u7EED", value: "ok" }], nextHand, nextHand);
        } else return setTimeout(nextHand, this.playDelay);
      }
      await this.continue("just before scheduling the next play() call");
      await players.asyncAll((p) => p.nextPlayer());
      do {
        this.currentPlayerId = (this.currentPlayerId + 1) % 4;
      } while (this.rules.blood_battle && players[this.currentPlayerId].has_won);
      return setTimeout(() => {
        player.disable();
        this.play();
      }, config.BOT_PLAY ? config.BOT_PLAY_DELAY : this.playDelay);
    }
    /**
     * Called as part of `play()` during the "draw one"
     * phase, this function simply gets a tile from the
     * wall, and then deals it to the indicated player.
     */
    async dealTile(player) {
      let wall = this.wall;
      let revealed = false;
      do {
        let tile = wall.get();
        let players = this.players;
        await players.asyncAll((p) => p.receivedTile(player));
        console.debug(`${player.id} receives ${tile} - ${player.getTileFaces()}`);
        config.log(`${player.id} <  ${tile} - ${player.getTileFaces()} - PRNG: ${config.PRNG.seed()}`);
        revealed = player.append(tile);
        if (revealed) {
          await players.asyncAll((p) => p.see(revealed, player));
        } else {
          let kong = await player.checkKong(tile);
          if (kong) {
            console.debug(`${player.id} plays self-drawn kong ${kong[0].getTileFace()} during play`);
            let claim = await this.processKong(player, kong);
            if (claim) return claim;
          }
        }
      } while (revealed);
    }
    /**
     * Called as part of `play()` during the "play one"
     * phase, this function is triggered when the player
     * opts _not_ to discard a tile, instead discarding
     * the value `undefined`. This signals that the player
     * has managed to form a winning hand during the
     * "draw on" phase of their turn, and we should
     * wrap up this hand of play, calculate the scores,
     * and schedule a call to `startHand` so that play
     * can move on to the next hand (or end, if this
     * was the last hand to be played and it resolved
     * in a way that would normally rotate the winds).
     */
    async processWin(player, discardpid) {
      if (this.rules.blood_battle) return this.processWinSichuan(player, discardpid);
      let hand = this.hand;
      let players = this.players;
      let currentPlayerId = this.currentPlayerId;
      let windOfTheRound = this.windOfTheRound;
      player.markWinner();
      let play_length = Date.now() - this.PLAY_START;
      let message = `Player ${currentPlayerId} wins hand ${hand}! (hand took ${play_length}ms)`;
      console.log(message);
      config.log(message);
      let fullDisclosure = players.map((p) => p.getDisclosure());
      console.debug("disclosure array:", fullDisclosure);
      await players.asyncAll((p) => p.endOfHand(fullDisclosure));
      console.debug("SCORING TILES");
      let scores = fullDisclosure.map((d, id) => this.rules.scoreTiles(d, id, windOfTheRound, this.wall.remaining));
      let eastid = 0;
      players.forEach((p) => {
        if (p.wind === 0) eastid = p.id;
      });
      let adjustments = this.rules.settleScores(scores, player.id, eastid, discardpid);
      await players.asyncAll((p) => {
        config.log(`${p.id}: ${adjustments[p.id]}, hand: ${p.getTileFaces()}, [${p.getLockedTileFaces()}], (${p.bonus}), discards: ${fullDisclosure[p.id].discards}`);
        p.recordScores(adjustments);
      });
      this.scoreHistory.push({ fullDisclosure, scores, adjustments });
      scores[player.id].winner = true;
      if (config.HAND_INTERVAL > 0) {
        modal.setScores(hand, this.rules, scores, adjustments, () => {
          this.startHand({ winner: player });
        });
      } else this.startHand({ winner: player });
    }
    /**
     * 血战到底结算：本局可多人先后胡牌。胡牌者退出本局（牌亮出），
     * 其余玩家继续打；点炮只有点炮者付，自摸则所有未胡的玩家各付。
     */
    async processWinSichuan(player, discardpid) {
      let players = this.players;
      player.markWinner();
      let fullDisclosure = players.map((p) => p.getDisclosure());
      let score = this.rules.scoreTiles(
        fullDisclosure[player.id],
        player.id,
        this.windOfTheRound,
        this.wall.remaining
      );
      let fan = score.total;
      let selfdraw = discardpid === false || discardpid === void 0;
      let adjustments = [0, 0, 0, 0];
      let payerText;
      if (selfdraw) {
        let payers = players.filter((p) => !p.has_won && p.id !== player.id);
        payers.forEach((p) => {
          adjustments[p.id] -= fan * 2;
          adjustments[player.id] += fan * 2;
        });
        payerText = `${payers.length}\u5BB6\u81EA\u6478`;
      } else {
        let pid = discardpid;
        adjustments[pid] -= fan * 3;
        adjustments[player.id] += fan * 3;
        payerText = `${pid}\u53F7\u70B9\u70AE`;
      }
      players.forEach((p) => p.recordScores(adjustments));
      let scores = players.map((p, i) => i === player.id ? score : { score: 0, doubles: 0, total: 0, log: [], fan: 0 });
      this.scoreHistory.push({ fullDisclosure, scores, adjustments });
      config.log(`\u8840\u6218\u5230\u5E95\uFF1A${player.id}\u80E1\u724C ${fan}\u756A (${payerText})`);
      let remaining = players.filter((p) => !p.has_won).length;
      let message = `${player.id}\u53F7\u80E1\u724C \xB7 ${fan}\u756A\uFF08${payerText}\uFF09
${score.log.join("\u3001")}`;
      let advance = () => {
        if (remaining <= 1 || this.wall.dead) {
          return this.startHand({ winner: player, draw: this.wall.dead });
        }
        let next = (player.id + 1) % 4;
        while (players[next].has_won) next = (next + 1) % 4;
        this.currentPlayerId = next;
        return this.play();
      };
      if (config.HAND_INTERVAL > 0 && !config.BOT_PLAY) {
        modal.choiceInput(message, [{ label: "\u63A5\u7740\u6253", value: "ok" }], advance, advance);
      } else if (config.HAND_INTERVAL > 0) {
        setTimeout(advance, config.HAND_INTERVAL);
      } else advance();
    }
    /**
     * Called as part of `play()` during the "play one"
     * phase, this function processes the discard as
     * declared by the current player. Note that this
     * function only deals with actual discards: if the
     * player opted not to discard because they were
     * holding a winning tile, this function is not called.
     */
    async processDiscard(player) {
      let discard = this.discard;
      console.debug(`${player.id} discarded ${discard.getTileFace()}`);
      config.log(`${player.id}  > ${discard.getTileFace()}`);
      player.remove(discard);
      discard.setFrom(player.id);
      discard.reveal();
      await this.players.asyncAll((p) => p.playerDiscarded(player, discard, this.counter));
    }
    /**
     * Called as part of `play()` during the "play one"
     * phase, after `processDiscard()` takes place, this
     * function ask all players to state whether they are
     * interested in the discarded tile, and if so: what
     * kind of play they intend to make with that tile.
     *
     * This is asynchronous code in that all players are
     * asked to make their determinations simultaneously,
     * and the game is on hold until all claims (including
     * passes) are in.
     *
     * If there are multiple claims, claims are ordered
     * by value, and the higest claim "wins".
     */
    async getAllClaims() {
      await this.continue("getAllClaims");
      let players = this.players;
      let currentpid = this.currentPlayerId;
      let discard = this.discard;
      let claims = await Promise.all(
        players.map((p2) => p2.has_won ? Promise.resolve({ claimtype: CLAIM2.IGNORE }) : new Promise((resolve) => p2.getClaim(currentpid, discard, this.wall.remaining, resolve)))
      );
      if (this.rules.no_chow || this.rules.missing_suit) {
        let tile = discard.getTileFace();
        let suit = tile < 27 ? tile / 9 | 0 : -1;
        claims = claims.map((c, pid) => {
          if (c.claimtype === CLAIM2.IGNORE || players[pid].has_won) return c;
          let p2 = players[pid];
          if (this.rules.no_chow && c.claimtype >= CLAIM2.CHOW && c.claimtype < CLAIM2.PUNG) {
            return { claimtype: CLAIM2.IGNORE };
          }
          if (this.rules.missing_suit && p2.missingSuit !== void 0) {
            if ((c.claimtype === CLAIM2.PUNG || c.claimtype === CLAIM2.KONG) && suit === p2.missingSuit) {
              return { claimtype: CLAIM2.IGNORE };
            }
            if (c.claimtype === CLAIM2.WIN && !p2.canWinNow()) {
              return { claimtype: CLAIM2.IGNORE };
            }
          }
          return c;
        });
      }
      console.debug("all claims are in");
      let claim = CLAIM2.IGNORE;
      let win = void 0;
      let p = -1;
      claims.forEach((c, pid) => {
        if (c.claimtype > claim) {
          claim = c.claimtype;
          win = c.wintype ? c.wintype : void 0;
          p = pid;
        }
      });
      if (currentpid === 0 && !config.BOT_PLAY && config.BOT_DELAY_BEFORE_DISCARD_ENDS) {
        await new Promise((resolve) => {
          setTimeout(() => resolve(), config.BOT_DELAY_BEFORE_DISCARD_ENDS);
        });
      }
      let winningClaim = p === -1 ? void 0 : { claimtype: claim, wintype: win, p };
      return winningClaim;
    }
    /**
     * Called in `play()` during the "play one" phase, after
     * `getAllClaims()` resolves, this function schedules the
     * "recursive" call to `play()` with the winning claim
     * passed in, so that the next "draw one" resolves the
     * claim, instead of drawing a new tile from the wall.
     */
    processClaim(player, claim) {
      let discard = this.discard;
      player.disable();
      setTimeout(() => this.play(claim), config.BOT_PLAY ? config.BOT_PLAY_DELAY : this.playDelay);
    }
  };

  // src/js/core/game/game-manager.js
  var GameManager = class {
    constructor(players) {
      const wallHack = config.WALL_HACK;
      this.players = players || [
        new HumanPlayer(0, wallHack),
        new BotPlayer(1, wallHack),
        new BotPlayer(2, wallHack),
        new BotPlayer(3, wallHack)
      ];
    }
    /**
     * Create a game, with document blur/focus event handling
     * bound to game pause/resume functionality.
     */
    newGame() {
      let game = new Game(this.players);
      globalThis.currentGame = {
        game,
        players: this.players
      };
      let gameBoard = document.querySelector(".board");
      gameBoard.focus();
      return game;
    }
  };

  // src/js/page/play-or-watch.js
  (function() {
    if (config.PLAY_IMMEDIATELY) play();
    else offerChoice();
    function play() {
      let manager = new GameManager();
      let game = manager.newGame();
      game.startGame(() => {
        document.body.classList.add("finished");
        let gameui = game.players.find((p) => p.ui).ui;
        config.flushLog();
        return modal.showFinalScores(
          gameui,
          game.rules,
          game.scoreHistory,
          () => {
            document.body.classList.remove("finished");
            rotateWinds.reset();
            offerChoice();
          }
        );
      });
    }
    function offerChoice() {
      const options = [
        { description: "\u56DB\u5DDD\u8840\u6218\u5230\u5E95 \xB7 108\u5F20\u724C \xB7 \u7F3A\u4E00\u95E8 \xB7 \u4E0D\u80FD\u5403 \xB7 \u4E00\u80E1\u5230\u5E95" },
        { label: "\u6211\u8981\u6253\u4E00\u5C40\uFF01", value: "play" },
        { label: "\u770B\u7535\u8111\u6253\u724C", value: "watch" },
        {
          description: "\u4E5F\u53EF\u4EE5\u5148\u8C03\u6574\u8BBE\u7F6E\uFF1A",
          align: "center"
        },
        { label: "\u6E38\u620F\u8BBE\u7F6E", value: "settings", back: true },
        { label: "\u66F4\u6362\u76AE\u80A4", value: "theming", back: true },
        {
          description: "\uFF08\u6253\u724C\u8FC7\u7A0B\u4E2D\u4E5F\u80FD\u6253\u5F00\u8BBE\u7F6E\uFF09",
          align: "center"
        }
      ];
      options.fixed = true;
      modal.choiceInput(
        "Welcome! What would you like to do?",
        options,
        (result) => {
          config.BOT_PLAY = result === "watch";
          if (result === "watch") config.FORCE_OPEN_BOT_PLAY = true;
          if (result === "settings") return modal.pickPlaySettings();
          if (result === "theming") return modal.pickTheming();
          play();
        }
      );
    }
  })();
})();
