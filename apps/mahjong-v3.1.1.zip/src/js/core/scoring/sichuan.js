import { config } from "../../../config.js";
import { Ruleset } from "./ruleset.js";
import { tilesNeeded } from "../algorithm/tiles-needed.js";

/**
 * 四川血战到底 ruleset.
 *
 * Differences from the classic rulesets:
 *  - only 108 numbered tiles (no winds, dragons, flowers): see wall.js
 *  - chow (吃) is forbidden
 *  - every player must declare a missing suit (缺一门定缺) and discard
 *    those tiles before they may win, pung or kong
 *  - play continues after a win: up to three winners per hand (血战到底)
 *  - payment: self-draw → every still-active player pays; discard win →
 *    only the discarder pays
 *
 * Scoring is in 番 (fan) with a 1-point base. Settlement itself is handled
 * by Game.processWinSichuan, because classic Ruleset.settleScores assumes
 * exactly one winner per hand.
 */
class Sichuan extends Ruleset {

  constructor() {
    super(
      Ruleset.POINTS_DOUBLES,
      0,      // starting score (relative)
      32,     // fan cap
      0,      // points for winning: handled by our own fan calculation
      false,  // no-point hand does not exist
      false,  // losers never settle amongst themselves
      false,  // no east doubling
      false,  // handled in processWinSichuan
      false,  // handled in processWinSichuan
      false,  // no reverse wind direction
      true    // wind passes on every win
    );
    // flags consumed by game/players
    this.blood_battle = true;
    this.no_chow = true;
    this.missing_suit = true;
    this.base_points = 1;
  }

  /** Human-friendly names for the three suits (0 bamboo 条, 1 chars 万, 2 dots 筒). */
  getSuitName(suit) {
    return ["条", "万", "筒"][suit] || "?";
  }

  /**
   * Compute the fan value of a completed hand.
   * Used by Game.processWinSichuan for each winner.
   */
  scoreTiles(disclosure, id, windOfTheRound, tilesLeft) {
    if (!disclosure.winner) return { score: 0, doubles: 0, total: 0, log: [], fan: 0 };

    let concealed = disclosure.concealed.slice().filter(t => t < 34);
    let locked = disclosure.locked || [];
    let kongCount = locked.filter(set => set.length === 4).length;

    // all tiles in the hand, for suit counting
    let faces = concealed.concat(
      ...locked.map(set => set.map(t => t.getTileFace ? t.getTileFace() : t))
    );
    let suits = new Set(faces.filter(t => t < 27).map(t => (t / 9) | 0));
    let onesuit = suits.size === 1;

    let log = [];
    let fan = 0;

    // ---- special hand: seven pairs (七对 / 龙七对) ----
    let counts = new Array(34).fill(0);
    concealed.forEach(t => counts[t]++);
    let sevenPairs = concealed.length === 14 && locked.length === 0 &&
                     counts.every(c => c % 2 === 0);
    let dragonSeven = sevenPairs && counts.some(c => c === 4);

    if (dragonSeven) {
      fan += 4;
      log.push("龙七对 4番");
    } else if (sevenPairs) {
      fan += 2;
      log.push("七对 2番");
    } else {
      // normal hand: work out whether it is all pungs (对对胡)
      let { winpaths } = tilesNeeded(concealed, locked);
      let path = winpaths[0] || [];
      let sets = path.map(set => {
        let tiles = set.tiles().map(t => t.getTileFace ? t.getTileFace() : t);
        return { type: set.type, tiles };
      });
      let allPungs = sets.filter(s => s.type === 'pung' || s.type === 'kong').length >= 3 &&
                     sets.every(s => s.type !== 'chow');
      if (allPungs) {
        fan += 2;
        log.push("对对胡 2番");
      } else {
        fan += 1;
        log.push("平胡 1番");
      }
    }

    if (onesuit) {
      fan += 4;
      log.push("清一色 4番");
    }
    if (kongCount) {
      fan += kongCount;
      log.push(`${kongCount}根 ${kongCount}番`);
    }
    if (tilesLeft <= 0) {
      fan += 1;
      log.push("海底捞月 1番");
    }
    fan = Math.min(fan, this.limit);

    return {
      score: fan,
      doubles: 0,
      total: fan,
      fan,
      log,
      limit: false,
      wind: 0,
      wotr: 0
    };
  }

  /**
   * Never let the generic ruleset award limit hands that need honour tiles.
   */
  checkForLimit(allTiles, lockedSize) {
    if (allTiles.length < 14) return;
    // 九莲宝灯 is a valid one-suit limit hand; thirteen orphans is not
    // possible with the 108-tile set, so skip it.
    const tiles = allTiles.slice().map(t => t | 0).sort();
    if (this.limits.hasNineGates(tiles, lockedSize)) return "九莲宝灯";
  }

  generateLimitObject(limit, selfdraw) {
    return {
      limit,
      log: [`${limit} 16番`],
      score: 0,
      doubles: 0,
      fan: 16,
      total: 16,
      limitHand: true
    };
  }
}

Ruleset.register(Sichuan);

export { Sichuan };
