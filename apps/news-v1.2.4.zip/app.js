/*
 * 每日资讯 —— 小盒子 WebView 应用
 * 数据源：开源 60s API（多镜像自动切换）+ 公开 RSS 转 JSON 服务
 * 密钥：无。所有数据只读，失败时展示本机缓存。
 */
(function () {
  'use strict';

  var CACHE_KEY = 'news_cache_v2';
  var BASE_KEY = 'news_base_v1';
  var BASES = [
    'https://api.cczo.cc/60s',
    'https://60s.superjeason.qzz.io',
    'https://60s.okbaike.com',
    'https://60s.viki.moe'
  ];
  var RSS2JSON = 'https://api.rss2json.com/v1/api.json';
  var FEEDS = {
    finance: 'https://www.chinanews.com.cn/rss/finance.xml',
    ai: 'https://techcrunch.com/category/artificial-intelligence/feed/'
  };
  var AI_WORDS = /AI|人工智能|大模型|生成式|GPT|OpenAI|ChatGPT|算力|芯片|机器人|深度学习|神经网络/i;

  var TABS = [
    { id: 'brief', name: '今日速览' },
    { id: 'tech', name: '国内科技' },
    { id: 'finance', name: '财经' },
    { id: 'ai', name: 'AI' },
    { id: 'global', name: '全球科技' }
  ];

  var $ = function (id) { return document.getElementById(id); };
  var cache = readJSON(CACHE_KEY, {});
  var baseIndex = readJSON(BASE_KEY, 0);
  if (typeof baseIndex !== 'number' || baseIndex < 0 || baseIndex >= BASES.length) baseIndex = 0;
  var current = 'brief';
  var loading = false;
  var toastTimer = null;
  var detailCtx = null;
  var swiped = false; // 滑动切栏后屏蔽误触卡片

  function readJSON(key, fallback) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) { return fallback; }
  }
  function writeJSON(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* 存储满则忽略 */ }
  }

  function clean(s) {
    if (!s) return '';
    var t = String(s).replace(/<[^>]*>/g, ' ').replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ');
    var ta = document.createElement('textarea');
    ta.innerHTML = t;
    return ((ta.value || '') + '').replace(/\s+/g, ' ').trim();
  }

  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function fmtTime(ts) {
    var d = new Date(ts);
    if (isNaN(d.getTime())) return '';
    return pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function fetchJSON(url, timeout) {
    return new Promise(function (resolve, reject) {
      var done = false;
      var ctrl = typeof AbortController === 'function' ? new AbortController() : null;
      var timer = setTimeout(function () {
        if (done) return;
        done = true;
        if (ctrl) ctrl.abort();
        reject(new Error('请求超时'));
      }, timeout || 10000);
      var opt = { cache: 'no-store' };
      if (ctrl) opt.signal = ctrl.signal;
      fetch(url, opt).then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      }).then(function (data) {
        if (done) return;
        done = true; clearTimeout(timer); resolve(data);
      }, function (err) {
        if (done) return;
        done = true; clearTimeout(timer); reject(err);
      });
    });
  }

  /* 依次尝试镜像，成功后记住可用的那个 */
  function fetch60(path) {
    var order = [];
    for (var i = 0; i < BASES.length; i++) order.push(BASES[(baseIndex + i) % BASES.length]);
    return new Promise(function (resolve, reject) {
      var k = 0;
      function next() {
        if (k >= order.length) { reject(new Error('全部镜像暂不可用')); return; }
        var idx = k;
        var host = order[k++];
        fetchJSON(host + path, 9000).then(function (r) {
          if (r && r.code === 200 && r.data != null) {
            var real = BASES.indexOf(host);
            if (real >= 0 && real !== baseIndex) { baseIndex = real; writeJSON(BASE_KEY, baseIndex); }
            resolve(r.data);
          } else next();
        }, next);
      }
      next();
    });
  }

  function fetchRss(feedUrl) {
    var url = RSS2JSON + '?rss_url=' + encodeURIComponent(feedUrl) + '&count=24';
    return fetchJSON(url, 13000).then(function (r) {
      if (!r || r.status !== 'ok') throw new Error((r && r.message) || 'RSS 读取失败');
      return (r.items || []).map(function (it) {
        return {
          title: clean(it.title),
          desc: clean(it.description || it.content),
          link: it.link || '',
          meta: (it.pubDate || '').replace('T', ' ').slice(0, 16),
          source: clean((r.feed && r.feed.title) || 'RSS'),
          ts: Date.parse(it.pubDate) || 0
        };
      }).filter(function (it) { return it.title; });
    });
  }

  function loadBrief() {
    return fetch60('/v2/60s').then(function (d) {
      var items = (d.news || []).map(function (t, i) {
        return {
          title: clean(t),
          desc: '',
          link: '',
          meta: (d.date || '') + ' · 第 ' + (i + 1) + ' 条',
          source: '60秒读懂世界'
        };
      });
      return {
        items: items,
        source: '60秒读懂世界 · ' + (d.date || ''),
        tip: d.tip || '',
        bundleLink: d.link || ''
      };
    });
  }

  function loadTech() {
    return fetch60('/v2/it-news?limit=30').then(function (list) {
      var items = (list || []).map(function (it) {
        return {
          title: clean(it.title),
          desc: clean(it.description),
          link: it.link || '',
          meta: (it.created || '').replace('T', ' ').slice(0, 16),
          source: 'IT之家 · 实时科技'
        };
      });
      return { items: items, source: 'IT之家 RSS · 实时科技资讯' };
    });
  }

  function loadFinance() {
    return fetchRss(FEEDS.finance).then(function (items) {
      return { items: items, source: '中新网财经 · RSS' };
    });
  }

  function loadAI() {
    var rss = fetchRss(FEEDS.ai);
    var local = fetch60('/v2/it-news?limit=30').catch(function () { return []; });
    return Promise.all([rss, local]).then(function (res) {
      var zh = (res[1] || []).filter(function (it) { return AI_WORDS.test(it.title + ' ' + it.desc); })
        .map(function (it) {
          return {
            title: it.title, desc: it.desc, link: it.link,
            meta: it.meta, source: 'IT之家 · AI', ts: it.ts || 0
          };
        });
      var items = (res[0] || []).concat(zh);
      if (!items.length) throw new Error('AI 资讯暂不可用');
      items.sort(function (a, b) { return (b.ts || 0) - (a.ts || 0); });
      return { items: items.slice(0, 26), source: 'TechCrunch AI + IT之家 AI' };
    });
  }

  function loadGlobal() {
    return fetch60('/v2/hacker-news/top?limit=20').then(function (list) {
      var items = (list || []).map(function (it) {
        return {
          title: clean(it.title),
          desc: '',
          link: it.link || ('https://news.ycombinator.com/item?id=' + it.id),
          meta: (it.score || 0) + ' 分 · ' + (it.author || '') + ' · ' + (it.created || '').slice(0, 16),
          source: 'Hacker News · 全球科技'
        };
      });
      return { items: items, source: 'Hacker News · 全球科技热榜' };
    });
  }

  function loadTab(tab, force) {
    if (loading) return Promise.resolve(false);
    var c = cache[tab];
    if (!force && c && c.items && c.items.length && Date.now() - c.ts < 5 * 60 * 1000) {
      setStatus('更新于 ' + fmtTime(c.ts));
      render();
      return Promise.resolve(false);
    }
    loading = true;
    setStatus('正在获取最新资讯…', 'loading');
    $('refreshBtn').disabled = true;
    var task;
    if (tab === 'brief') task = loadBrief();
    else if (tab === 'tech') task = loadTech();
    else if (tab === 'finance') task = loadFinance();
    else if (tab === 'ai') task = loadAI();
    else task = loadGlobal();

    return task.then(function (res) {
      cache[tab] = {
        items: res.items, source: res.source, tip: res.tip || '',
        bundleLink: res.bundleLink || '',
        ts: Date.now(), stale: false
      };
      writeJSON(CACHE_KEY, cache);
      setStatus('更新于 ' + fmtTime(cache[tab].ts));
      toast('已更新 ' + TAB_NAME(tab));
    }, function (err) {
      if (c && c.items && c.items.length) {
        c.stale = true;
        writeJSON(CACHE_KEY, cache);
        setStatus('网络不可用 · 显示缓存', 'stale');
        toast('网络不可用，显示上次缓存');
      } else {
        setStatus('加载失败', 'stale');
        renderEmpty('加载失败：' + (err && err.message ? err.message : '未知错误'));
      }
    }).then(function () {
      loading = false;
      $('refreshBtn').disabled = false;
      render();
      return true;
    });
  }

  function TAB_NAME(id) {
    for (var i = 0; i < TABS.length; i++) if (TABS[i].id === id) return TABS[i].name;
    return id;
  }

  function setStatus(text, cls) {
    var el = $('status');
    el.textContent = text;
    el.className = 'status' + (cls ? ' ' + cls : '');
  }

  function toast(text) {
    var el = $('toast');
    el.textContent = text;
    el.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('on'); }, 2000);
  }

  function searchUrl(title) {
    return 'https://www.bing.com/search?q=' + encodeURIComponent(title || '');
  }

  function setAction(el, show, url) {
    if (show && url) el.dataset.url = url;
    else if (el.dataset.url) delete el.dataset.url;
    el.classList.toggle('hidden', !(show && url));
  }

  function showDetail(tab, idx) {
    var c = cache[tab];
    if (!c || !c.items || !c.items[idx]) return;
    detailCtx = { tab: tab, idx: idx, item: c.items[idx] };
    var it = detailCtx.item;
    $('detailSource').textContent = it.source || '每日资讯';
    $('detailTitle').textContent = it.title;
    $('detailMeta').textContent = it.meta || '';
    $('detailBody').textContent = it.desc || (
      it.link ? '订阅源未提供摘要，可点「打开原文」阅读全文。' : '订阅源未提供摘要，可点「搜索标题」查找相关报道。'
    );
    $('detailBody').scrollTop = 0;
    setAction($('detailOpen'), true, it.link);
    setAction($('detailBundle'), tab === 'brief', c.bundleLink);
    setAction($('detailSearch'), true, searchUrl(it.title));
    $('detail').classList.add('on');
    $('detail').setAttribute('aria-hidden', 'false');
  }

  function hideDetail() {
    detailCtx = null;
    $('detail').classList.remove('on');
    $('detail').setAttribute('aria-hidden', 'true');
  }

  function openLink(url) {
    if (!url) return;
    hideDetail();
    window.location.href = url;
  }

  function renderEmpty(msg) {
    var list = $('list');
    list.innerHTML = '';
    var box = document.createElement('div');
    box.className = 'empty';
    var b = document.createElement('b');
    b.textContent = msg || '暂无资讯';
    var btn = document.createElement('button');
    btn.className = 'btn';
    btn.type = 'button';
    btn.textContent = '重新加载';
    btn.addEventListener('click', function () { loadTab(current, true); });
    box.appendChild(b);
    box.appendChild(btn);
    list.appendChild(box);
    $('footInfo').textContent = '';
  }

  function render() {
    var c = cache[current];
    if (!c || !c.items || !c.items.length) { renderEmpty('暂无资讯，点右上角刷新'); return; }
    var list = $('list');
    list.innerHTML = '';
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i];
      var card = document.createElement('article');
      card.className = 'card';
      card.tabIndex = 0;

      var h = document.createElement('h2');
      // 今日速览的 60 秒标题较长，允许多换一行完整显示
      if (current === 'brief') h.className = 'brief-title';
      var num = document.createElement('span');
      num.className = 'num';
      num.textContent = (i + 1) + '. ';
      h.appendChild(num);
      h.appendChild(document.createTextNode(it.title));
      card.appendChild(h);

      if (it.desc) {
        var p = document.createElement('p');
        p.textContent = it.desc;
        card.appendChild(p);
      }
      var meta = document.createElement('div');
      meta.className = 'meta';
      meta.textContent = (it.source || '') + ' · ' + (it.meta || '');
      card.appendChild(meta);

      (function (idx) {
        card.addEventListener('click', function () {
          if (swiped) { swiped = false; return; }
          showDetail(current, idx);
        });
        card.addEventListener('keydown', function (e) {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); showDetail(current, idx); }
        });
      })(i);
      list.appendChild(card);
    }
    $('footInfo').textContent = (c.stale ? '缓存 · ' : '') + (c.source || '') + (c.tip ? ' · ' + c.tip.slice(0, 30) : '');
  }

  function TAB_INDEX(id) {
    for (var i = 0; i < TABS.length; i++) if (TABS[i].id === id) return i;
    return -1;
  }

  /* 点击栏目与左右滑动共用同一套切换逻辑 */
  function switchTab(tab) {
    if (!tab || tab === current || TAB_INDEX(tab) < 0) return;
    hideDetail();
    current = tab;
    var nodes = document.querySelectorAll('.tab');
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].classList.toggle('active', nodes[i].getAttribute('data-tab') === tab);
    }
    $('list').scrollTop = 0;
    loadTab(tab, false);
  }

  function bindSwipe() {
    var app = document.querySelector('.app');
    var start = null;
    var THRESHOLD = 50; // 最小水平位移（px）
    app.addEventListener('touchstart', function (e) {
      if ($('detail').classList.contains('on') || e.touches.length !== 1) { start = null; return; }
      var t = e.touches[0];
      start = { x: t.clientX, y: t.clientY, time: Date.now() };
      swiped = false;
    }, { passive: true });
    app.addEventListener('touchmove', function (e) {
      if (!start || e.touches.length !== 1) return;
      var t = e.touches[0];
      var dx = t.clientX - start.x;
      var dy = t.clientY - start.y;
      // 明确是横向手势时阻止浏览器边缘返回，纵向滚动不受影响
      if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy) && e.cancelable) e.preventDefault();
    }, { passive: false });
    app.addEventListener('touchend', function (e) {
      if (!start || e.changedTouches.length !== 1) { start = null; return; }
      var s = start;
      start = null;
      var t = e.changedTouches[0];
      var dx = t.clientX - s.x;
      var dy = t.clientY - s.y;
      if (Date.now() - s.time > 800) return; // 太慢不算滑动
      if (Math.abs(dx) < THRESHOLD || Math.abs(dx) < Math.abs(dy) * 1.2) return;
      var idx = TAB_INDEX(current);
      var next = idx + (dx < 0 ? 1 : -1);
      if (next < 0 || next >= TABS.length) return;
      swiped = true;
      switchTab(TABS[next].id);
      toast(TAB_NAME(TABS[next].id));
    }, { passive: true });
    app.addEventListener('touchcancel', function () { start = null; }, { passive: true });
  }

  function bind() {
    $('tabs').addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('.tab') : null;
      if (!btn) return;
      switchTab(btn.getAttribute('data-tab'));
    });
    $('refreshBtn').addEventListener('click', function () { loadTab(current, true); });
    bindSwipe();

    $('detailClose').addEventListener('click', hideDetail);
    $('detail').addEventListener('click', function (e) { if (e.target === $('detail')) hideDetail(); });
    $('detailOpen').addEventListener('click', function (e) { openLink(e.currentTarget.dataset.url); });
    $('detailBundle').addEventListener('click', function (e) { openLink(e.currentTarget.dataset.url); });
    $('detailSearch').addEventListener('click', function (e) { openLink(e.currentTarget.dataset.url); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && $('detail').classList.contains('on')) hideDetail();
    });
  }

  function init() {
    var now = new Date();
    var week = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'][now.getDay()];
    $('dateLine').textContent = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()) + ' ' + week;
    bind();
    render();
    loadTab(current, false);
  }

  /* 供端到端测试使用，不影响正常交互 */
  window.__news = {
    loadTab: loadTab,
    cache: function () { return cache; },
    current: function () { return current; },
    switchTab: switchTab,
    base: function () { return BASES[baseIndex]; },
    clean: clean,
    showDetail: showDetail,
    hideDetail: hideDetail,
    detail: function () { return detailCtx; },
    detailUrl: function () { return $('detailOpen').dataset.url || ''; },
    searchUrl: searchUrl
  };

  init();
})();
