/**
 * 节拍器 · 纯前端，无网络、无依赖
 * 计时：Web Audio lookahead scheduler（JS 定时只负责"提前排期"，实际发声由音频时钟决定），
 *       避免 setInterval 抖动造成的节奏不稳。
 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var KEY = 'metronome.settings.v1';

  var settings = { bpm: 120, meter: 4, sub: 1, vol: 70, sound: 'click' };
  try {
    var saved = JSON.parse(localStorage.getItem(KEY) || '{}');
    for (var k in saved) if (k in settings) settings[k] = saved[k];
  } catch (e) { /* 首次安装或存档损坏，用默认值 */ }

  var ctx = null, master = null, noiseBuf = null;
  var running = false, timerId = null, rafId = null;
  var nextNoteTime = 0, beatIndex = 0, subIndex = 0;
  var drawQueue = [], pendingVisual = [];
  var taps = [], wakeLock = null;

  var LOOKAHEAD = 25;        // ms，排期循环间隔
  var SCHEDULE_AHEAD = 0.12; // s，提前排期窗口

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.className = 'toast on';
    clearTimeout(t._t); t._t = setTimeout(function () { t.className = 'toast'; }, 1600);
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(settings)); } catch (e) {}
  }

  /* ---------- 音频 ---------- */

  function ensureAudio() {
    if (ctx) {
      if (ctx.state === 'suspended') ctx.resume();
      return;
    }
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { toast('此设备不支持 Web Audio'); return; }
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = settings.vol / 100;
    master.connect(ctx.destination);
    // 木鱼音色用的短噪声缓冲
    var len = Math.floor(ctx.sampleRate * 0.05);
    noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    var ch = noiseBuf.getChannelData(0);
    for (var i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;
  }

  /** 在指定音频时刻打一下；kind: 'accent' | 'beat' | 'sub' */
  function clickAt(t, kind) {
    if (!ctx || !master) return;
    var g = ctx.createGain();
    g.connect(master);
    var amp = kind === 'sub' ? 0.20 : (kind === 'accent' ? 0.95 : 0.60);
    var dur = settings.sound === 'bell' ? 0.22 : 0.045;

    if (settings.sound === 'wood') {
      // 短噪声 + 低频木腔
      var src = ctx.createBufferSource();
      src.buffer = noiseBuf;
      var bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = kind === 'accent' ? 1500 : 1050;
      bp.Q.value = 1.6;
      src.connect(bp); bp.connect(g);
      g.gain.setValueAtTime(amp, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.035);
      src.start(t); src.stop(t + 0.05);
    } else {
      var osc = ctx.createOscillator();
      var freq = settings.sound === 'bell'
        ? (kind === 'accent' ? 1320 : kind === 'beat' ? 990 : 780)
        : (kind === 'accent' ? 1100 : kind === 'beat' ? 820 : 640);
      osc.type = settings.sound === 'bell' ? 'sine' : 'square';
      osc.frequency.setValueAtTime(freq, t);
      if (settings.sound === 'click') {
        osc.frequency.exponentialRampToValueAtTime(freq * 0.72, t + 0.03);
      }
      osc.connect(g);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(amp, t + 0.002);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      osc.start(t); osc.stop(t + dur + 0.02);
    }
  }

  /* ---------- 排期 ---------- */

  function schedule() {
    if (!running || !ctx) return;
    var beatDur = 60 / settings.bpm;
    while (nextNoteTime < ctx.currentTime + SCHEDULE_AHEAD) {
      var inBar = beatIndex % settings.meter;
      var kind = inBar === 0 ? 'accent' : 'beat';
      clickAt(nextNoteTime, kind);
      if (settings.sub > 1) {
        for (var s = 1; s < settings.sub; s++) {
          clickAt(nextNoteTime + beatDur * s / settings.sub, 'sub');
        }
      }
      // 视觉事件按音频时间入队，rAF 出队，保证灯光与声音同步
      drawQueue.push({ time: nextNoteTime, beat: inBar, bar: Math.floor(beatIndex / settings.meter) + 1 });
      nextNoteTime += beatDur;
      beatIndex++;
    }
  }

  function draw() {
    if (!running) return;
    var now = ctx ? ctx.currentTime : 0;
    while (drawQueue.length && drawQueue[0].time <= now) {
      pendingVisual.push(drawQueue.shift());
    }
    if (pendingVisual.length) {
      var ev = pendingVisual.pop();
      pendingVisual.length = 0;
      lightBeat(ev.beat, ev.bar);
      swingRod(ev.beat);
    }
    rafId = requestAnimationFrame(draw);
  }

  function lightBeat(beat, bar) {
    var dots = $('dots').children;
    for (var i = 0; i < dots.length; i++) dots[i].className = 'dot' + (i === 0 ? ' accent' : '');
    if (dots[beat]) dots[beat].className += ' active';
    $('barCount').textContent = '第 ' + bar + ' 小节';
  }

  function swingRod(beat) {
    var rod = $('rod');
    rod.style.transitionDuration = (60 / settings.bpm) + 's';
    rod.style.transform = 'rotate(' + (beat % 2 === 0 ? '-24deg' : '24deg') + ')';
  }

  /* ---------- 播放控制 ---------- */

  function start() {
    ensureAudio();
    if (!ctx) return;
    ctx.resume();
    running = true;
    beatIndex = 0;
    subIndex = 0;
    drawQueue.length = 0;
    pendingVisual.length = 0;
    nextNoteTime = ctx.currentTime + 0.08;
    $('playBtn').textContent = '停止';
    $('playBtn').className = 'play running';
    schedule();
    timerId = setInterval(schedule, LOOKAHEAD);
    rafId = requestAnimationFrame(draw);
    requestWakeLock();
  }

  function stop() {
    running = false;
    clearInterval(timerId); timerId = null;
    cancelAnimationFrame(rafId); rafId = null;
    drawQueue.length = 0; pendingVisual.length = 0;
    $('playBtn').textContent = '开始';
    $('playBtn').className = 'play';
    $('rod').style.transform = 'rotate(0deg)';
    var dots = $('dots').children;
    for (var i = 0; i < dots.length; i++) dots[i].className = 'dot' + (i === 0 ? ' accent' : '');
    releaseWakeLock();
  }

  function requestWakeLock() {
    if (!navigator.wakeLock || !navigator.wakeLock.request) { $('wakeBadge').className = 'battery'; return; }
    navigator.wakeLock.request('screen').then(function (lock) {
      wakeLock = lock;
      $('wakeBadge').className = 'battery on';
    }).catch(function () { $('wakeBadge').className = 'battery'; });
  }
  function releaseWakeLock() {
    if (wakeLock) { try { wakeLock.release(); } catch (e) {} wakeLock = null; }
    $('wakeBadge').className = 'battery';
  }

  /* ---------- UI 同步 ---------- */

  function renderDots() {
    var html = '';
    for (var i = 0; i < settings.meter; i++) html += '<div class="dot' + (i === 0 ? ' accent' : '') + '"></div>';
    $('dots').innerHTML = html;
  }

  function renderBpm() {
    $('bpmNum').textContent = settings.bpm;
    $('bpmRange').value = settings.bpm;
    var ps = $('bpmRange').parentNode.querySelectorAll('.bpm-presets button');
    for (var i = 0; i < ps.length; i++) {
      ps[i].className = Number(ps[i].getAttribute('data-bpm')) === settings.bpm ? 'on' : '';
    }
  }

  function setBpm(v) {
    settings.bpm = clamp(Math.round(v), 30, 240);
    renderBpm(); save();
  }

  function markSeg(container, attr, value) {
    var bs = $(container).children;
    for (var i = 0; i < bs.length; i++) {
      bs[i].className = Number(bs[i].getAttribute(attr)) === Number(value) ? 'on' : '';
    }
  }

  /* ---------- 事件 ---------- */

  $('playBtn').addEventListener('click', function () { running ? stop() : start(); });
  $('minusBtn').addEventListener('click', function () { setBpm(settings.bpm - 1); });
  $('plusBtn').addEventListener('click', function () { setBpm(settings.bpm + 1); });
  $('bpmRange').addEventListener('input', function () { setBpm(Number(this.value)); });

  var presets = document.querySelectorAll('.bpm-presets button');
  for (var i = 0; i < presets.length; i++) {
    presets[i].addEventListener('click', function () { setBpm(Number(this.getAttribute('data-bpm'))); });
  }

  $('meterSeg').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    settings.meter = Number(b.getAttribute('data-meter'));
    markSeg('meterSeg', 'data-meter', settings.meter);
    renderDots(); save();
    if (running) { stop(); start(); }
  });

  $('subSeg').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    settings.sub = Number(b.getAttribute('data-sub'));
    markSeg('subSeg', 'data-sub', settings.sub);
    save();
  });

  $('soundSeg').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    settings.sound = b.getAttribute('data-sound');
    var bs = $('soundSeg').children;
    for (var i = 0; i < bs.length; i++) {
      bs[i].className = bs[i] === b ? 'on' : '';
    }
    save();
  });

  $('volRange').addEventListener('input', function () {
    settings.vol = Number(this.value);
    $('volVal').textContent = settings.vol;
    if (master) master.gain.value = settings.vol / 100;
    save();
  });

  $('tapBtn').addEventListener('click', function () {
    var now = Date.now();
    var btn = this;
    btn.className = 'tap tapping';
    setTimeout(function () { btn.className = 'tap'; }, 90);
    if (taps.length && now - taps[taps.length - 1] > 2000) taps = [];
    taps.push(now);
    if (taps.length > 6) taps.shift();
    if (taps.length >= 2) {
      var sum = 0, n = 0;
      for (var i = 1; i < taps.length; i++) { sum += taps[i] - taps[i - 1]; n++; }
      setBpm(clamp(Math.round(60000 / (sum / n)), 30, 240));
      toast('测速 ' + settings.bpm + ' BPM' + (running ? ' · 下一拍生效' : ''));
    } else {
      toast('继续敲…');
    }
  });

  $('wakeBadge').addEventListener('click', function () {
    if (wakeLock) { releaseWakeLock(); toast('已关闭屏幕常亮'); }
    else { requestWakeLock(); toast('已请求屏幕常亮'); }
  });

  document.addEventListener('visibilitychange', function () {
    if (document.hidden && running) stop();
  });

  /* ---------- 初始化 ---------- */

  renderDots(); renderBpm();
  $('volRange').value = settings.vol;
  $('volVal').textContent = settings.vol;
  markSeg('meterSeg', 'data-meter', settings.meter);
  markSeg('subSeg', 'data-sub', settings.sub);
  var sb = $('soundSeg').children;
  for (var j = 0; j < sb.length; j++) {
    sb[j].className = sb[j].getAttribute('data-sound') === settings.sound ? 'on' : '';
  }
})();
