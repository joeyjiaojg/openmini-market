/**
 * 24点 · 纯前端
 * 求解器：枚举两两运算递归合并，判断是否可得 24；出题保证有解。
 * 表达式校验：自写解析器（不用 eval），确保四张牌各用一次。
 * 无网络、无依赖。统计存 localStorage（仅本机）。
 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var STAT_KEY = 'point24_stat_v1';
  var hand = [], expr = '', level = 'medium', seconds = 0, timerId = null, running = false, solved = false;
  var stat = loadStat();
  var SUITS = ['♠','♥','♦','♣'];
  var LEVEL_NAME = { easy: '简单', medium: '中等', hard: '困难' };

  function loadStat() {
    try { var s = JSON.parse(localStorage.getItem(STAT_KEY)); if (s && typeof s.count === 'number') return s; } catch (e) {}
    return { count: 0, best: 0 };
  }
  function saveStat() { try { localStorage.setItem(STAT_KEY, JSON.stringify(stat)); } catch (e) {} }
  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.className = 'toast on';
    clearTimeout(t._t); t._t = setTimeout(function () { t.className = 'toast'; }, 1800);
  }
  function fmtTime(s) { var m = Math.floor(s / 60), ss = s % 60; return (m < 10 ? '0' : '') + m + ':' + (ss < 10 ? '0' : '') + ss; }
  function updateStat() {
    $('stat').textContent = '已解 ' + stat.count + ' · 最快 ' + (stat.best ? fmtTime(stat.best) : '--');
  }

  // ---------- 求解器 ----------
  function solve(nums) {
    // nums: [{v, e}], 返回表达式字符串或 null
    if (nums.length === 1) return Math.abs(nums[0].v - 24) < 1e-6 ? nums[0].e : null;
    for (var i = 0; i < nums.length; i++) for (var j = i + 1; j < nums.length; j++) {
      var a = nums[i], b = nums[j], rest = [];
      for (var k = 0; k < nums.length; k++) if (k !== i && k !== j) rest.push(nums[k]);
      var tries = [
        { v: a.v + b.v, e: '(' + a.e + '+' + b.e + ')' },
        { v: a.v - b.v, e: '(' + a.e + '-' + b.e + ')' },
        { v: b.v - a.v, e: '(' + b.e + '-' + a.e + ')' },
        { v: a.v * b.v, e: '(' + a.e + '×' + b.e + ')' },
        { v: b.v / a.v, e: '(' + b.e + '÷' + a.e + ')' }
      ];
      if (Math.abs(b.v) > 1e-9) tries.push({ v: a.v / b.v, e: '(' + a.e + '÷' + b.e + ')' });
      for (var t = 0; t < tries.length; t++) {
        var r = solve(rest.concat([tries[t]]));
        if (r) return r;
      }
    }
    return null;
  }
  function expressionFor(vals) {
    return solve(vals.map(function (v) { return { v: v, e: String(v) }; }));
  }
  function rand(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
  function newCards() {
    var max = level === 'easy' ? 9 : 13, tries = 0, vals, sol;
    do {
      vals = [rand(1, max), rand(1, max), rand(1, max), rand(1, max)];
      sol = expressionFor(vals);
      tries++;
    } while (!sol && tries < 200);
    // 困难：偏向大数且有解的题
    if (level === 'hard') {
      tries = 0;
      do {
        vals = [rand(1, max), rand(1, max), rand(1, max), rand(1, max)];
        sol = expressionFor(vals);
        tries++;
      } while ((!sol || vals.filter(function (v) { return v >= 10; }).length < 2) && tries < 200);
    }
    return { vals: vals, sol: sol };
  }
  function newGame() {
    var c = newCards();
    hand = c.vals.map(function (v, i) { return { v: v, suit: SUITS[i % 4], color: (i % 4 === 1 || i % 4 === 2) ? 'red' : '' }; });
    expr = ''; seconds = 0; running = false; solved = false;
    clearInterval(timerId); timerId = null;
    $('timer').textContent = '00:00';
    $('diffBadge').textContent = LEVEL_NAME[level];
    renderCards(); renderExpr();
  }
  function renderCards() {
    $('cards').innerHTML = hand.map(function (c, i) {
      return '<div class="card ' + c.color + '" data-i="' + i + '">' +
        '<span class="suit">' + c.suit + '</span><span class="v">' + c.v + '</span><span class="suit">' + c.suit + '</span></div>';
    }).join('');
  }
  function renderExpr() {
    var e = $('expr');
    if (expr) { e.textContent = expr; e.className = 'expr'; }
    else { e.textContent = '点数字牌和运算符来组成算式'; e.className = 'expr placeholder'; }
    $('exprResult').textContent = ''; $('exprResult').className = 'expr-result';
  }
  function startTimer() {
    if (running || solved) return;
    running = true;
    timerId = setInterval(function () { seconds++; $('timer').textContent = fmtTime(seconds); }, 1000);
  }

  // ---------- 表达式解析（不用 eval） ----------
  function tokenize(s) {
    var out = [], i = 0;
    while (i < s.length) {
      var ch = s[i];
      if (ch === ' ') { i++; continue; }
      if (/[0-9]/.test(ch)) {
        var num = '';
        while (i < s.length && /[0-9]/.test(s[i])) num += s[i++];
        out.push({ t: 'num', v: parseInt(num, 10) });
      } else if ('+-*/()'.indexOf(ch) >= 0) { out.push({ t: 'op', v: ch }); i++; }
      else if (ch === '×') { out.push({ t: 'op', v: '*' }); i++; }
      else if (ch === '÷') { out.push({ t: 'op', v: '/' }); i++; }
      else if (ch === '−') { out.push({ t: 'op', v: '-' }); i++; }
      else return null;
    }
    return out;
  }
  function evaluate(tokens) {
    var pos = 0;
    function peek() { return tokens[pos]; }
    function factor() {
      var tk = peek();
      if (!tk) throw new Error('算式不完整');
      if (tk.t === 'num') { pos++; return tk.v; }
      if (tk.v === '-') { pos++; return -factor(); }
      if (tk.v === '(') { pos++; var v = exprP(); if (!peek() || peek().v !== ')') throw new Error('括号未闭合'); pos++; return v; }
      throw new Error('算式格式错误');
    }
    function term() {
      var v = factor();
      while (peek() && (peek().v === '*' || peek().v === '/')) {
        var op = peek().v; pos++; var r = factor();
        if (op === '/' && Math.abs(r) < 1e-9) throw new Error('不能除以 0');
        v = op === '*' ? v * r : v / r;
      }
      return v;
    }
    function exprP() {
      var v = term();
      while (peek() && (peek().v === '+' || peek().v === '-')) {
        var op = peek().v; pos++; var r = term();
        v = op === '+' ? v + r : v - r;
      }
      return v;
    }
    var val = exprP();
    if (pos !== tokens.length) throw new Error('算式格式错误');
    return val;
  }
  function append(k) {
    if (solved) return;
    if (k === 'back') { expr = expr.slice(0, -1); renderExpr(); return; }
    if (k === 'clear') { expr = ''; renderExpr(); return; }
    var s = String(k);
    expr += s; startTimer(); renderExpr();
  }
  function submit() {
    if (solved) return;
    if (!expr.trim()) { toast('先输入算式'); return; }
    var toks = tokenize(expr);
    if (!toks) { toast('算式含非法字符'); return; }
    var used = toks.filter(function (t) { return t.t === 'num'; }).map(function (t) { return t.v; }).sort(function (a, b) { return a - b; });
    var need = hand.map(function (c) { return c.v; }).sort(function (a, b) { return a - b; });
    if (used.length !== 4 || used.some(function (v, i) { return v !== need[i]; })) {
      $('exprResult').textContent = '每张牌必须用且只用一次'; $('exprResult').className = 'expr-result bad';
      toast('四张牌要各用一次'); return;
    }
    var val;
    try { val = evaluate(toks); } catch (e) { $('exprResult').textContent = e.message; $('exprResult').className = 'expr-result bad'; return; }
    if (Math.abs(val - 24) < 1e-6) {
      solved = true; clearInterval(timerId);
      stat.count++; if (!stat.best || seconds < stat.best) stat.best = seconds; saveStat(); updateStat();
      $('exprResult').textContent = '= ' + Math.round(val) + ' ✓ 正确！用时 ' + fmtTime(seconds);
      $('exprResult').className = 'expr-result ok';
      toast('答对了！');
    } else {
      $('exprResult').textContent = '= ' + (Math.round(val * 100) / 100) + '（还差一点）';
      $('exprResult').className = 'expr-result bad';
    }
  }
  function hint() {
    var s = expressionFor(hand.map(function (c) { return c.v; }));
    if (!s) { toast('这题无解，换一题吧'); return; }
    startTimer();
    expr = s; renderExpr();
    toast('提示：已填入一种解法');
  }

  // ---------- 事件 ----------
  $('keypad').addEventListener('click', function (e) {
    var b = e.target.closest('.key'); if (!b) return;
    append(b.dataset.k);
  });
  $('cards').addEventListener('click', function (e) {
    var c = e.target.closest('.card'); if (!c) return;
    append(hand[Number(c.dataset.i)].v);
  });
  $('submitBtn').addEventListener('click', submit);
  $('hintBtn').addEventListener('click', hint);
  $('newBtn').addEventListener('click', function () { newGame(); toast('新一题'); });
  $('levels').addEventListener('click', function (e) {
    var b = e.target.closest('.seg-btn'); if (!b) return;
    level = b.dataset.lv;
    Array.prototype.forEach.call(this.children, function (x) { x.classList.toggle('on', x === b); });
    newGame(); toast('难度：' + LEVEL_NAME[level]);
  });
  document.addEventListener('keydown', function (e) {
    var k = e.key;
    if (/^[0-9]$/.test(k)) { append(k); return; }
    if ('+-*/()'.indexOf(k) >= 0) { append(k); return; }
    if (k === 'Enter') { submit(); return; }
    if (k === 'Backspace') { e.preventDefault(); append('back'); }
  });

  updateStat(); newGame();

  window.__point24 = {
    state: function () { return { hand: hand.map(function(c){return c.v;}), expr: expr, solved: solved, seconds: seconds }; },
    solution: function () { return expressionFor(hand.map(function(c){return c.v;})); },
    setExpr: function (s) { expr = s; renderExpr(); },
    submit: submit,
    newGame: newGame
  };
})();
