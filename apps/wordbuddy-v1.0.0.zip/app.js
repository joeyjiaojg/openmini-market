/* WordBuddy 小盒子版 · 纯 ES5，离线运行，进度存 localStorage */
(function () {
  'use strict';

  var D = window.WB_DATA;
  var KEY = 'wordbuddy.progress.v1';
  var DAY = 86400000;
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  var state = {
    tab: 'home',
    level: 'gaokao',
    mode: 'new',        // new | due | all
    queue: [],
    idx: 0,
    flipped: false,
    quiz: null,         // 测验状态
    story: null,
    kind: 'B',
    browseQ: ''
  };

  // ---------- 词索引 ----------
  var byWord = {};
  (function () {
    for (var i = 0; i < D.words.length; i++) byWord[D.words[i].word] = D.words[i];
  })();

  // ---------- 进度 ----------
  var prog = { level: 'gaokao', cards: {} };
  try {
    var raw = localStorage.getItem(KEY);
    if (raw) {
      var p = JSON.parse(raw);
      if (p && p.cards) prog = p;
    }
  } catch (e) { /* 忽略损坏存档 */ }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(prog)); } catch (e) { toast('存储失败'); }
  }

  function card(w) {
    if (!prog.cards[w]) {
      prog.cards[w] = { word: w, due: 0, ease: 2.5, interval: 0, reps: 0,
        last_quality: 5, study_count: 0, fail_count: 0 };
    }
    return prog.cards[w];
  }

  function levelWordIds(lid) {
    for (var i = 0; i < D.levels.length; i++) {
      if (D.levels[i].id === lid) return D.levels[i].word_ids;
    }
    return [];
  }

  function isDue(c, now) {
    return c.interval > 0 && c.due <= (now || Date.now());
  }

  function rate(w, q) {
    var c = card(w);
    var now = Date.now();
    if (q < 0) q = 0;
    if (q > 5) q = 5;
    c.last_quality = q;
    if (q < 3) {
      c.reps = 0;
      c.interval = 0;
      c.ease = Math.max(1.3, c.ease - 0.2);
      c.fail_count += 1;
      c.due = now + 60000;
    } else {
      c.study_count += 1;
      if (c.reps === 0) c.interval = 1;
      else if (c.reps === 1) c.interval = 6;
      else c.interval = Math.round(c.interval * c.ease);
      c.reps += 1;
      var delta = 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02);
      c.ease = Math.max(1.3, c.ease + delta);
      c.due = now + c.interval * DAY;
    }
    save();
  }

  function levelStats(lid) {
    var ids = levelWordIds(lid);
    var learned = 0, due = 0, mastered = 0, now = Date.now();
    for (var i = 0; i < ids.length; i++) {
      var c = prog.cards[ids[i]];
      if (!c) continue;
      if (c.interval > 0) {
        learned++;
        if (c.interval >= 21) mastered++;
        if (isDue(c, now)) due++;
      }
    }
    return { total: ids.length, learned: learned, due: due, mastered: mastered };
  }

  function toast(msg) {
    var t = $('toast');
    t.textContent = msg;
    t.className = 'toast on';
    if (t._tm) clearTimeout(t._tm);
    t._tm = setTimeout(function () { t.className = 'toast'; }, 1800);
  }

  // ---------- 视图渲染 ----------

  function renderTop() {
    var right = '';
    if (state.tab === 'study' || state.tab === 'review') {
      right = '<button class="btn sm ghost" id="btnBack">返回</button>';
    } else {
      var s = levelStats(state.level);
      right = '<span class="pill">' + esc(levelName(state.level)) + '</span>';
    }
    $('top-right').innerHTML = right;
    var bb = $('dueBadge');
    var due = levelStats(state.level).due;
    if (due > 0) { bb.textContent = due > 99 ? '99+' : due; bb.className = 'badge on'; }
    else bb.className = 'badge';
  }

  function levelName(lid) {
    for (var i = 0; i < D.levels.length; i++) if (D.levels[i].id === lid) return D.levels[i].name;
    return lid;
  }

  function renderTabs() {
    var ts = document.querySelectorAll('.tab');
    for (var i = 0; i < ts.length; i++) {
      ts[i].className = 'tab' + (ts[i].getAttribute('data-tab') === state.tab ? ' on' : '');
    }
  }

  function render() {
    renderTabs();
    renderTop();
    var m = $('main');
    if (state.tab === 'home') renderHome(m);
    else if (state.tab === 'study') renderStudy(m);
    else if (state.tab === 'review') renderReview(m);
    else if (state.tab === 'story') renderStory(m);
  }

  function renderHome(m) {
    var totalAll = 0, learnedAll = 0, dueAll = 0;
    var h = '<h2>我的词书</h2><p class="sub">三套分组词库，点一个开始记。进度自动存在本机。</p>';
    h += '<div class="stat-grid">';
    for (var i = 0; i < D.levels.length; i++) {
      var s = levelStats(D.levels[i].id);
      totalAll += s.total; learnedAll += s.learned; dueAll += s.due;
    }
    h += '<div class="stat"><b>' + learnedAll + '</b><span>已学</span></div>';
    h += '<div class="stat"><b>' + dueAll + '</b><span>待复习</span></div>';
    h += '<div class="stat"><b>' + totalAll + '</b><span>总词数</span></div>';
    h += '</div>';

    for (var j = 0; j < D.levels.length; j++) {
      var lv = D.levels[j];
      var st = levelStats(lv.id);
      var pct = st.total ? Math.round(st.learned * 100 / st.total) : 0;
      h += '<div class="card level-card" data-lv="' + lv.id + '">'
        + '<div class="row"><div><div class="level-name">' + esc(lv.name) + '</div>'
        + '<div class="level-sub">' + esc(lv.subtitle || '') + '</div></div>'
        + '<span class="pill">' + pct + '%</span></div>'
        + '<div class="progress-line"><i style="width:' + pct + '%"></i></div>'
        + '<div class="sub" style="margin:0">已学 ' + st.learned + ' · 掌握 ' + st.mastered
        + ' · 待复习 ' + st.due + ' · 共 ' + st.total + ' 词</div>'
        + '</div>';
    }
    h += '<p class="sub" style="text-align:center;margin-top:18px">WordBuddy · 分组速记 · SM-2 记忆算法</p>';
    m.innerHTML = h;

    var cards = m.querySelectorAll('.level-card');
    for (var k = 0; k < cards.length; k++) {
      (function (el) {
        el.addEventListener('click', function () {
          state.level = el.getAttribute('data-lv');
          prog.level = state.level;
          save();
          state.mode = 'new';
          state.tab = 'study';
          buildQueue();
          render();
        });
      })(cards[k]);
    }
  }

  function buildQueue() {
    var ids = levelWordIds(state.level);
    var q = [], now = Date.now();
    for (var i = 0; i < ids.length; i++) {
      var c = prog.cards[ids[i]];
      if (state.mode === 'new') { if (!c || c.interval === 0) q.push(ids[i]); }
      else if (state.mode === 'due') { if (c && isDue(c, now)) q.push(ids[i]); }
      else q.push(ids[i]);
    }
    // 新学取前 40 个，避免一次太多
    if (state.mode === 'new' && q.length > 40) q = q.slice(0, 40);
    state.queue = q;
    state.idx = 0;
    state.flipped = false;
    state.quiz = null;
  }

  function renderStudy(m) {
    var s = levelStats(state.level);
    var h = '<div class="seg">'
      + '<button data-mode="new" class="' + (state.mode === 'new' ? 'on' : '') + '">新词 ' + (s.total - s.learned) + '</button>'
      + '<button data-mode="due" class="' + (state.mode === 'due' ? 'on' : '') + '">复习 ' + s.due + '</button>'
      + '<button data-mode="all" class="' + (state.mode === 'all' ? 'on' : '') + '">全部</button>'
      + '</div>';
    m.innerHTML = h + '<div id="studyBody"></div>';
    var segs = m.querySelectorAll('.seg button');
    for (var i = 0; i < segs.length; i++) {
      (function (el) {
        el.addEventListener('click', function () {
          state.mode = el.getAttribute('data-mode');
          buildQueue();
          render();
        });
      })(segs[i]);
    }
    renderCard();
    bindBack();
  }

  function renderCard() {
    var body = $('studyBody');
    if (!body) return;
    if (state.idx >= state.queue.length) {
      body.innerHTML = '<div class="empty">本轮完成 🎉<br><br><button class="btn" id="again">再来一轮</button></div>';
      $('again').addEventListener('click', function () { buildQueue(); renderCard(); });
      return;
    }
    var w = state.queue[state.idx];
    var info = byWord[w] || { word: w, gloss: '' };
    var pct = Math.round(state.idx * 100 / state.queue.length);
    var h = '<div class="sub">' + (state.idx + 1) + ' / ' + state.queue.length + '</div>'
      + '<div class="progress-line"><i style="width:' + pct + '%"></i></div>';
    if (!state.flipped) {
      h += '<div class="flash" id="flash"><div class="fword">' + esc(info.word) + '</div>'
        + '<div class="fpos">' + (info.star ? '<span class="star">★</span> ' : '')
        + esc(info.pos || '') + '</div><div class="fhint">点卡片看释义</div></div>'
        + '<div class="btn-row" style="margin-top:14px"><button class="btn ghost" id="skip">跳过</button>'
        + '<button class="btn" id="showAns">认识了 →</button></div>';
    } else {
      h += '<div class="flash"><div class="fword" style="font-size:26px">' + esc(info.word) + '</div>'
        + '<div class="fpos">' + esc(info.pos || '') + '</div>'
        + '<div class="fgloss">' + esc(info.gloss || '') + '</div></div>'
        + '<div class="btn-row" style="margin-top:14px">'
        + '<button class="btn red" data-q="1">忘了</button>'
        + '<button class="btn amber" data-q="3">模糊</button>'
        + '<button class="btn green" data-q="5">认识</button></div>';
    }
    body.innerHTML = h;
    if (!state.flipped) {
      $('flash').addEventListener('click', function () { state.flipped = true; renderCard(); });
      $('showAns').addEventListener('click', function () { state.flipped = true; renderCard(); });
      $('skip').addEventListener('click', function () { state.idx++; state.flipped = false; renderCard(); });
    } else {
      var bs = body.querySelectorAll('[data-q]');
      for (var i = 0; i < bs.length; i++) {
        (function (el) {
          el.addEventListener('click', function () {
            rate(w, parseInt(el.getAttribute('data-q'), 10));
            state.idx++;
            state.flipped = false;
            renderCard();
            renderTop();
          });
        })(bs[i]);
      }
    }
  }

  function renderReview(m) {
    var s = levelStats(state.level);
    var h = '<h2>复习 · ' + esc(levelName(state.level)) + '</h2>'
      + '<p class="sub">SM-2 到期卡片优先复习；拼写题按中文写英文。</p>'
      + '<div class="stat-grid">'
      + '<div class="stat"><b>' + s.due + '</b><span>待复习</span></div>'
      + '<div class="stat"><b>' + s.mastered + '</b><span>已掌握</span></div>'
      + '<div class="stat"><b>' + s.learned + '</b><span>已学</span></div></div>';
    if (s.due === 0 && !state.quiz) {
      h += '<div class="empty">暂时没有到期卡片<br><br>去「学习」记几个新词吧</div>';
      m.innerHTML = h;
      bindBack();
      return;
    }
    if (!state.quiz) {
      state.mode = 'due';
      buildQueue();
      h += '<button class="btn block" id="startQuiz">开始复习 ' + state.queue.length + ' 词</button>';
      m.innerHTML = h;
      $('startQuiz').addEventListener('click', function () { nextQuiz(); });
      bindBack();
      return;
    }
    renderQuiz(m);
    bindBack();
  }

  function nextQuiz() {
    if (state.idx >= state.queue.length) {
      state.quiz = null;
      state.idx = 0;
      render();
      toast('复习完成 🎉');
      return;
    }
    var w = state.queue[state.idx];
    var info = byWord[w] || { word: w, gloss: '' };
    // KET 或低龄用词用选择题，其余用拼写题
    var choice = state.level === 'ket';
    var q = { word: w, gloss: info.gloss || '', choice: choice, answered: false };
    if (choice) {
      var opts = [w];
      var pool = levelWordIds(state.level);
      var tries = 0;
      while (opts.length < 4 && tries < 40) {
        var cand = pool[Math.floor(Math.random() * pool.length)];
        if (opts.indexOf(cand) < 0 && byWord[cand]) opts.push(cand);
        tries++;
      }
      while (opts.length < 4) opts.push(opts[0]);
      for (var i = opts.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var t = opts[i]; opts[i] = opts[j]; opts[j] = t;
      }
      q.opts = opts;
    }
    state.quiz = q;
    render();
  }

  function renderQuiz(m) {
    var q = state.quiz;
    var h = '<div class="sub">' + (state.idx + 1) + ' / ' + state.queue.length + ' · ' + esc(q.gloss) + '</div>';
    if (q.choice) {
      h += '<div class="qword">' + esc(q.gloss) + '</div>';
      for (var i = 0; i < q.opts.length; i++) {
        var cls = 'choice';
        if (q.answered && q.opts[i] === q.word) cls += ' right';
        h += '<button class="' + cls + '" data-opt="' + esc(q.opts[i]) + '">' + esc(q.opts[i]) + '</button>';
      }
    } else {
      h += '<div class="qword">' + esc(q.gloss) + '</div>'
        + '<input id="qans" class="qinput" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="输入英文单词">'
        + '<div style="text-align:center;margin-top:14px"><button class="btn" id="qok">提交</button> '
        + '<button class="btn ghost" id="qskip">跳过</button></div>';
    }
    if (q.answered) {
      h += '<div class="feedback" style="color:' + (q.correct ? '#10b981' : '#ef4444') + '">'
        + (q.correct ? '✓ 正确' : '✗ 正确答案：' + esc(q.word)) + '</div>'
        + '<button class="btn block" id="qnext">下一题</button>';
    }
    m.innerHTML = h;
    if (q.choice && !q.answered) {
      var bs = m.querySelectorAll('[data-opt]');
      for (var k = 0; k < bs.length; k++) {
        (function (el) {
          el.addEventListener('click', function () {
            q.answered = true;
            q.correct = el.getAttribute('data-opt') === q.word;
            rate(q.word, q.correct ? 5 : 1);
            render();
          });
        })(bs[k]);
      }
    } else if (!q.answered) {
      $('qok').addEventListener('click', function () {
        var v = ($('qans').value || '').trim().toLowerCase();
        q.answered = true;
        q.correct = v === q.word.toLowerCase();
        rate(q.word, q.correct ? 5 : 1);
        render();
      });
      $('qskip').addEventListener('click', function () { state.idx++; nextQuiz(); });
      $('qans').addEventListener('keydown', function (e) {
        if (e.key === 'Enter') $('qok').click();
      });
    }
    if (q.answered) $('qnext').addEventListener('click', function () { state.idx++; nextQuiz(); });
  }

  function renderStory(m) {
    if (state.story != null) {
      var st = D.stories[state.story];
      var h = '<button class="back" id="storyBack">‹ 返回故事列表</button>'
        + '<h2>' + esc(st.title) + '</h2>';
      var ens = st.paras || [];
      var zhs = st.paras_zh || [];
      for (var i = 0; i < ens.length; i++) {
        h += '<div class="para-en">' + esc(ens[i]) + '</div>';
        if (zhs[i]) h += '<div class="para-zh">' + esc(zhs[i]) + '</div>';
      }
      m.innerHTML = h;
      $('storyBack').addEventListener('click', function () { state.story = null; render(); });
      return;
    }
    var hh = '<h2>双语故事</h2><p class="sub">' + D.stories.length + ' 篇双语小故事，边读边记目标词。</p>';
    for (var j = 0; j < D.stories.length; j++) {
      var s = D.stories[j];
      hh += '<div class="story-item" data-s="' + j + '"><div class="story-no">第 ' + s.no + ' 篇</div>'
        + '<div class="story-title">' + esc(s.title) + '</div></div>';
    }
    m.innerHTML = hh;
    var items = m.querySelectorAll('[data-s]');
    for (var k = 0; k < items.length; k++) {
      (function (el) {
        el.addEventListener('click', function () {
          state.story = parseInt(el.getAttribute('data-s'), 10);
          render();
          $('main').scrollTop = 0;
        });
      })(items[k]);
    }
  }

  function bindBack() {
    var b = $('btnBack');
    if (b) b.addEventListener('click', function () {
      state.tab = 'home';
      state.story = null;
      state.quiz = null;
      render();
    });
  }

  // ---------- 事件 ----------
  var tabs = document.querySelectorAll('.tab');
  for (var i = 0; i < tabs.length; i++) {
    (function (t) {
      t.addEventListener('click', function () {
        state.tab = t.getAttribute('data-tab');
        if (state.tab === 'study' && !state.queue.length) buildQueue();
        if (state.tab === 'review') state.quiz = null;
        render();
        $('main').scrollTop = 0;
      });
    })(tabs[i]);
  }

  render();
})();
