/**
 * 数独 · 纯前端
 * 题目生成：先随机生成完整解，再按难度挖空并保证唯一解。
 * 支持：笔记模式、错误高亮、提示、计时、四档难度。
 * 无网络、无依赖。
 */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var gridEl = $('grid');
  var puzzle = [], solution = [], values = [], notes = [], given = [];
  var sel = -1, noteMode = false, level = 'medium';
  var seconds = 0, timerId = null, started = false, done = false;
  var REMOVE = { easy: 36, medium: 46, hard: 52, expert: 58 };
  var LEVEL_NAME = { easy: '简单', medium: '中等', hard: '困难', expert: '专家' };

  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.className = 'toast on';
    clearTimeout(t._t); t._t = setTimeout(function () { t.className = 'toast'; }, 1800);
  }
  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function ok(b, r, c, n) {
    for (var i = 0; i < 9; i++) {
      if (b[r][i] === n || b[i][c] === n) return false;
    }
    var br = Math.floor(r / 3) * 3, bc = Math.floor(c / 3) * 3;
    for (var y = br; y < br + 3; y++) for (var x = bc; x < bc + 3; x++) if (b[y][x] === n) return false;
    return true;
  }
  /** 生成一个完整合法解 */
  function makeSolution() {
    var b = Array.from({ length: 9 }, function () { return new Array(9).fill(0); });
    function fill(pos) {
      if (pos === 81) return true;
      var r = Math.floor(pos / 9), c = pos % 9;
      var nums = shuffle([1,2,3,4,5,6,7,8,9]);
      for (var k = 0; k < 9; k++) {
        if (ok(b, r, c, nums[k])) {
          b[r][c] = nums[k];
          if (fill(pos + 1)) return true;
          b[r][c] = 0;
        }
      }
      return false;
    }
    fill(0);
    return b;
  }
  /** 统计解的个数，最多数到 limit 个即停 */
  function countSolutions(b, limit) {
    var cnt = 0;
    function rec() {
      if (cnt >= limit) return;
      var best = -1, bestNums = null;
      for (var r = 0; r < 9; r++) for (var c = 0; c < 9; c++) {
        if (b[r][c] === 0) {
          var cand = [];
          for (var n = 1; n <= 9; n++) if (ok(b, r, c, n)) cand.push(n);
          if (!cand.length) return;
          if (best < 0 || cand.length < bestNums.length) { best = r * 9 + c; bestNums = cand; }
        }
      }
      if (best < 0) { cnt++; return; }
      var br = Math.floor(best / 9), bc = best % 9;
      for (var i = 0; i < bestNums.length && cnt < limit; i++) {
        b[br][bc] = bestNums[i]; rec(); b[br][bc] = 0;
      }
    }
    rec();
    return cnt;
  }
  /** 按难度挖空，保证唯一解 */
  function makePuzzle(lv) {
    var sol = makeSolution();
    var p = sol.map(function (row) { return row.slice(); });
    var positions = shuffle(Array.from({ length: 81 }, function (_, i) { return i; }));
    var target = REMOVE[lv] || 46, removed = 0;
    for (var k = 0; k < positions.length && removed < target; k++) {
      var idx = positions[k], r = Math.floor(idx / 9), c = idx % 9;
      var saved = p[r][c]; p[r][c] = 0;
      var test = p.map(function (row) { return row.slice(); });
      if (countSolutions(test, 2) !== 1) p[r][c] = saved;
      else removed++;
    }
    return { puzzle: p, solution: sol };
  }

  // ---------- 渲染 ----------
  function idx(r, c) { return r * 9 + c; }
  function buildGrid() {
    gridEl.innerHTML = '';
    for (var r = 0; r < 9; r++) for (var c = 0; c < 9; c++) {
      var i = idx(r, c), cell = document.createElement('div');
      cell.className = 'cell' + (c === 2 || c === 5 ? ' br' : '') + (r === 2 || r === 5 ? ' bb' : '');
      cell.dataset.i = i;
      gridEl.appendChild(cell);
    }
  }
  function render() {
    var sr = sel >= 0 ? Math.floor(sel / 9) : -1, sc = sel >= 0 ? sel % 9 : -1;
    var sv = sel >= 0 ? values[sel] : 0;
    for (var i = 0; i < 81; i++) {
      var r = Math.floor(i / 9), c = i % 9, cell = gridEl.children[i];
      cell.className = 'cell' + (c === 2 || c === 5 ? ' br' : '') + (r === 2 || r === 5 ? ' bb' : '');
      if (given[i]) cell.className += ' given';
      if (sel >= 0 && (r === sr || c === sc)) cell.className += ' peer';
      if (sv && values[i] === sv && i !== sel) cell.className += ' same';
      if (i === sel) cell.className += ' sel';
      var v = values[i];
      if (v) {
        cell.textContent = v;
        cell.className += (v !== solution[r][c]) ? ' err' : '';
      } else if (notes[i] && notes[i].length) {
        cell.innerHTML = '<div class="notes">' +
          [1,2,3,4,5,6,7,8,9].map(function (n) { return '<span>' + (notes[i].indexOf(n) >= 0 ? n : '') + '</span>'; }).join('') + '</div>';
      } else cell.textContent = '';
    }
  }
  function newGame() {
    var g = makePuzzle(level);
    puzzle = g.puzzle; solution = g.solution;
    values = puzzle.map(function (row) { return row.slice(); }).reduce(function (a, row) { return a.concat(row); }, []);
    notes = new Array(81).fill(null);
    given = values.map(function (v) { return v !== 0; });
    sel = -1; done = false; seconds = 0; started = false;
    $('timer').textContent = '00:00'; setStatus(LEVEL_NAME[level] + ' · 选中格子开始');
    clearInterval(timerId); timerId = null;
    render();
  }
  function setStatus(s) { $('status').textContent = s; }
  function startTimer() {
    if (started || done) return;
    started = true;
    timerId = setInterval(function () {
      seconds++;
      var m = Math.floor(seconds / 60), s = seconds % 60;
      $('timer').textContent = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
    }, 1000);
  }
  function setNumber(n) {
    if (sel < 0 || given[sel] || done) return;
    startTimer();
    if (noteMode && n !== 0) {
      if (!notes[sel]) notes[sel] = [];
      var p = notes[sel].indexOf(n);
      if (p >= 0) notes[sel].splice(p, 1); else notes[sel].push(n);
      values[sel] = 0;
    } else {
      values[sel] = n; notes[sel] = null;
    }
    render();
    if (isSolved()) {
      done = true; clearInterval(timerId);
      setStatus('完成！用时 ' + $('timer').textContent);
      toast('恭喜完成数独！');
    }
  }
  function isSolved() {
    for (var i = 0; i < 81; i++) if (values[i] !== solution[Math.floor(i/9)][i % 9]) return false;
    return true;
  }
  function check() {
    var err = 0;
    for (var i = 0; i < 81; i++) {
      var r = Math.floor(i / 9), c = i % 9;
      if (values[i] && values[i] !== solution[r][c]) err++;
    }
    if (err) { toast('有 ' + err + ' 处不对，红色标出'); render(); }
    else toast('目前填写都正确');
  }
  function hint() {
    var empties = [];
    for (var i = 0; i < 81; i++) if (!given[i] && values[i] !== solution[Math.floor(i/9)][i % 9]) empties.push(i);
    if (!empties.length) { toast('没有需要提示的格子'); return; }
    var pick = empties[Math.floor(Math.random() * empties.length)];
    startTimer();
    values[pick] = solution[Math.floor(pick/9)][pick % 9]; notes[pick] = null;
    sel = pick; render();
    if (isSolved()) { done = true; clearInterval(timerId); setStatus('完成！'); toast('恭喜完成数独！'); }
    else toast('已填入一格');
  }

  // ---------- 事件 ----------
  gridEl.addEventListener('click', function (e) {
    var cell = e.target.closest('.cell'); if (!cell) return;
    sel = Number(cell.dataset.i); render();
  });
  $('pad').addEventListener('click', function (e) {
    var b = e.target.closest('.num'); if (!b) return;
    setNumber(Number(b.dataset.n));
  });
  $('noteBtn').addEventListener('click', function () {
    noteMode = !noteMode; this.textContent = '笔记：' + (noteMode ? '开' : '关');
    this.classList.toggle('on', noteMode); toast(noteMode ? '笔记模式已开' : '笔记模式已关');
  });
  $('hintBtn').addEventListener('click', hint);
  $('checkBtn').addEventListener('click', check);
  $('newBtn').addEventListener('click', function () { newGame(); toast('新题已生成'); });
  $('levels').addEventListener('click', function (e) {
    var b = e.target.closest('.seg-btn'); if (!b) return;
    level = b.dataset.lv;
    Array.prototype.forEach.call(this.children, function (x) { x.classList.toggle('on', x === b); });
    newGame(); toast('难度：' + LEVEL_NAME[level]);
  });

  buildGrid(); newGame();

  // 测试辅助
  window.__sudoku = {
    state: function () { return { solved: done, filled: values.filter(Boolean).length, given: given.filter(Boolean).length, seconds: seconds }; },
    values: function () { return values.slice(); },
    solution: function () { return solution.map(function (r) { return r.slice(); }); },
    solveAll: function () { values = solution.map(function (r) { return r.slice(); }).reduce(function (a,r){return a.concat(r);},[]); sel = 0; render(); if (isSolved()) { done=true; clearInterval(timerId); setStatus('完成！'); } },
    newGame: newGame
  };
})();
