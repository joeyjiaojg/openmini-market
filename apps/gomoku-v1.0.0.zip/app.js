/**
 * 五子棋 · 纯前端人机对战
 * 玩家执黑先手，AI 执白。棋型评估 + 攻防打分，三档难度。
 * 无网络、无依赖，全部状态在内存（刷新即新局，符合小盒子沙箱）。
 */
(function () {
  'use strict';

  var N = 15, EMPTY = 0, BLACK = 1, WHITE = 2;
  var board = [], turn = BLACK, over = false, level = 2, lastMove = null, hintPt = null;
  var history = [];               // 每步 {x,y,color}
  var win = { p: 0, c: 0, d: 0 };
  var winLine = null;
  var canvas = document.getElementById('board');
  var ctx = canvas.getContext('2d');
  var CELL = 34, PAD = 18, size = 0, dpr = 1;
  var $ = function (id) { return document.getElementById(id); };

  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.className = 'toast on';
    clearTimeout(t._t); t._t = setTimeout(function () { t.className = 'toast'; }, 1800);
  }

  // ---------- 棋盘绘制 ----------
  function layout() {
    var wrap = canvas.parentElement;
    var avail = Math.min(wrap.clientWidth, wrap.clientHeight) - 4;
    if (avail < 180) avail = 180;
    size = avail;
    dpr = window.devicePixelRatio || 1;
    canvas.style.width = size + 'px'; canvas.style.height = size + 'px';
    canvas.width = Math.round(size * dpr); canvas.height = Math.round(size * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    CELL = (size - PAD * 2) / (N - 1);
    draw();
  }
  function px(i) { return PAD + i * CELL; }
  function draw() {
    ctx.clearRect(0, 0, size, size);
    // 木纹底
    var g = ctx.createLinearGradient(0, 0, size, size);
    g.addColorStop(0, '#e0c184'); g.addColorStop(1, '#c39b57');
    ctx.fillStyle = g; ctx.fillRect(0, 0, size, size);
    // 网格
    ctx.strokeStyle = 'rgba(90,60,25,0.72)'; ctx.lineWidth = 1;
    ctx.beginPath();
    for (var i = 0; i < N; i++) {
      ctx.moveTo(px(0), px(i)); ctx.lineTo(px(N - 1), px(i));
      ctx.moveTo(px(i), px(0)); ctx.lineTo(px(i), px(N - 1));
    }
    ctx.stroke();
    // 星位
    var stars = [[3,3],[3,11],[11,3],[11,11],[7,7]];
    ctx.fillStyle = 'rgba(80,50,20,0.85)';
    stars.forEach(function (p) { ctx.beginPath(); ctx.arc(px(p[0]), px(p[1]), 3, 0, 6.284); ctx.fill(); });
    // 胜利连线
    if (winLine) {
      ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(px(winLine[0]), px(winLine[1]));
      ctx.lineTo(px(winLine[2]), px(winLine[3])); ctx.stroke();
    }
    // 棋子
    for (var y = 0; y < N; y++) for (var x = 0; x < N; x++) {
      if (board[y][x]) stone(x, y, board[y][x]);
    }
    // 最后一手标记
    if (lastMove) {
      ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(px(lastMove.x), px(lastMove.y), CELL * 0.22, 0, 6.284); ctx.stroke();
    }
    // 提示点
    if (hintPt) {
      ctx.strokeStyle = '#2c7'; ctx.lineWidth = 2; ctx.setLineDash([4, 3]);
      ctx.beginPath(); ctx.arc(px(hintPt.x), px(hintPt.y), CELL * 0.38, 0, 6.284); ctx.stroke();
      ctx.setLineDash([]);
    }
  }
  function stone(x, y, c) {
    var cx = px(x), cy = px(y), r = CELL * 0.44;
    var g = ctx.createRadialGradient(cx - r * 0.35, cy - r * 0.35, r * 0.1, cx, cy, r);
    if (c === BLACK) { g.addColorStop(0, '#5a5a5a'); g.addColorStop(1, '#0d0d0d'); }
    else { g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#cfcfcf'); }
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 6.284); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1; ctx.stroke();
  }

  // ---------- 规则 ----------
  function inB(x, y) { return x >= 0 && y >= 0 && x < N && y < N; }
  function initBoard() {
    board = []; history = []; over = false; turn = BLACK; lastMove = null; hintPt = null; winLine = null;
    for (var y = 0; y < N; y++) { board[y] = []; for (var x = 0; x < N; x++) board[y][x] = EMPTY; }
    setStatus('轮到你 · 执黑');
    draw();
  }
  var DIRS = [[1,0],[0,1],[1,1],[1,-1]];
  /** 落子后判断是否成五，返回连线端点或 null */
  function checkWin(x, y, c) {
    for (var d = 0; d < 4; d++) {
      var dx = DIRS[d][0], dy = DIRS[d][1], n = 1, a = 1, b = 1;
      while (inB(x + dx * a, y + dy * a) && board[y + dy * a][x + dx * a] === c) { n++; a++; }
      while (inB(x - dx * b, y - dy * b) && board[y - dy * b][x - dx * b] === c) { n++; b++; }
      if (n >= 5) return [x - dx * (b - 1), y - dy * (b - 1), x + dx * (a - 1), y + dy * (a - 1)];
    }
    return null;
  }
  function full() { for (var y = 0; y < N; y++) for (var x = 0; x < N; x++) if (!board[y][x]) return false; return true; }
  function place(x, y, c) {
    board[y][x] = c; lastMove = { x: x, y: y }; history.push({ x: x, y: y, color: c });
    var line = checkWin(x, y, c);
    if (line) { winLine = line; over = true; return line; }
    if (full()) { over = true; return 'draw'; }
    turn = c === BLACK ? WHITE : BLACK;
    return null;
  }

  // ---------- AI 评估 ----------
  // 某方向从 (x,y) 向两侧数同色连续子，两端是否空（活）
  function lineInfo(x, y, dx, dy, c) {
    var cnt = 1, open = 0, i;
    for (i = 1; i <= 5; i++) {
      var nx = x + dx * i, ny = y + dy * i;
      if (!inB(nx, ny) || board[ny][nx] !== c) {
        if (inB(nx, ny) && board[ny][nx] === EMPTY) open++;
        break;
      }
      cnt++;
    }
    for (i = 1; i <= 5; i++) {
      var mx = x - dx * i, my = y - dy * i;
      if (!inB(mx, my) || board[my][mx] !== c) {
        if (inB(mx, my) && board[my][mx] === EMPTY) open++;
        break;
      }
      cnt++;
    }
    return { cnt: cnt, open: open };
  }
  var SCORE = { 1: 1, 2: 8, 3: 60, 4: 600, 5: 100000 };
  function evalPoint(cx, cy, c) {
    var total = 0;
    for (var d = 0; d < 4; d++) {
      var info = lineInfo(cx, cy, DIRS[d][0], DIRS[d][1], c);
      var s = SCORE[Math.min(info.cnt, 5)] || 0;
      if (info.cnt >= 5) s = 100000;
      else if (info.open === 1) s = Math.round(s * 0.35);
      else if (info.open === 0) s = Math.round(s * 0.08);
      total += s;
    }
    return total;
  }
  // 候选点：已有棋子邻域，避免全盘扫描
  function candidates() {
    var set = {}, out = [];
    for (var y = 0; y < N; y++) for (var x = 0; x < N; x++) {
      if (!board[y][x]) continue;
      for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) {
        var nx = x + dx, ny = y + dy, k = ny * N + nx;
        if (inB(nx, ny) && !board[ny][nx] && !set[k]) { set[k] = 1; out.push({ x: nx, y: ny }); }
      }
    }
    if (!out.length) out.push({ x: 7, y: 7 });
    return out;
  }
  function bestMove(c) {
    var cand = candidates(), opp = c === BLACK ? WHITE : BLACK;
    var best = null, bestScore = -Infinity, i, p, sc;
    // 三级难度：1=只看攻防即时+随机，2=攻防评分，3=评分+对手反击折扣
    for (i = 0; i < cand.length; i++) {
      p = cand[i];
      var atk = evalPoint(p.x, p.y, c);
      var def = evalPoint(p.x, p.y, opp);
      sc = atk + (level === 1 ? def * 0.5 : def * 0.9);
      if (level === 3) {
        // 若我方此点暴露给对手立即成五，重罚（避免被反杀）
        board[p.y][p.x] = c;
        var counter = 0;
        for (var d = 0; d < 4; d++) {
          var q = lineInfo(p.x, p.y, DIRS[d][0], DIRS[d][1], opp);
          if (q.cnt >= 4) counter += 10000;
        }
        board[p.y][p.x] = EMPTY;
        sc -= counter;
      }
      if (level === 1) sc += Math.random() * 40;
      if (sc > bestScore) { bestScore = sc; best = p; }
    }
    return best || cand[0];
  }
  function aiMove() {
    if (over || turn !== WHITE) return;
    setStatus('电脑思考中…');
    var p = bestMove(WHITE);
    setTimeout(function () {
      if (over) return;
      var res = place(p.x, p.y, WHITE);
      draw();
      if (res === 'draw') { finish('draw'); return; }
      if (res) { finish('cpu', res); return; }
      setStatus('轮到你 · 执黑');
    }, 180 + Math.random() * 120);
  }

  // ---------- 状态与结算 ----------
  function setStatus(s) { $('status').textContent = s; }
  function refreshScore() { $('winP').textContent = win.p; $('winC').textContent = win.c; $('winD').textContent = win.d; }
  function finish(who, line) {
    over = true;
    if (who === 'player') { win.p++; toast('你赢了！'); setStatus('你赢了 · 再来一局'); }
    else if (who === 'cpu') { win.c++; toast('电脑获胜'); setStatus('电脑获胜 · 再来一局'); }
    else { win.d++; toast('和局'); setStatus('和局 · 再来一局'); }
    refreshScore(); draw();
  }
  function clickBoard(e) {
    if (over || turn !== BLACK) return;
    var r = canvas.getBoundingClientRect();
    var mx = e.clientX - r.left, my = e.clientY - r.top;
    var x = Math.round((mx - PAD) / CELL), y = Math.round((my - PAD) / CELL);
    if (!inB(x, y)) return;
    if (board[y][x] !== EMPTY) return;
    // 吸附：离交叉点太远不落子
    if (Math.abs(mx - px(x)) > CELL * 0.48 || Math.abs(my - px(y)) > CELL * 0.48) return;
    hintPt = null;
    var res = place(x, y, BLACK);
    draw();
    if (res === 'draw') { finish('draw'); return; }
    if (res) { finish('player', res); return; }
    aiMove();
  }
  function undo() {
    if (!history.length) { toast('没有可悔的棋'); return; }
    over = false; winLine = null; hintPt = null;
    // 悔到玩家上一次落子前：删掉末尾 1~2 步（电脑应手 + 玩家）
    var steps = history.length >= 2 && history[history.length - 1].color === WHITE ? 2 : 1;
    for (var i = 0; i < steps; i++) {
      var m = history.pop(); board[m.y][m.x] = EMPTY;
    }
    turn = BLACK; lastMove = history.length ? history[history.length - 1] : null;
    setStatus('轮到你 · 执黑'); draw(); toast('已悔棋');
  }
  function hint() {
    if (over || turn !== BLACK) return;
    var p = bestMove(BLACK);
    hintPt = p; draw(); toast('建议落在高亮处');
    setTimeout(function () { hintPt = null; draw(); }, 4000);
  }

  // ---------- 事件 ----------
  canvas.addEventListener('pointerdown', clickBoard);
  $('undoBtn').addEventListener('click', undo);
  $('hintBtn').addEventListener('click', hint);
  $('newBtn').addEventListener('click', function () { initBoard(); toast('新局开始'); });
  $('levels').addEventListener('click', function (e) {
    var b = e.target.closest('.seg-btn'); if (!b) return;
    level = Number(b.getAttribute('data-lv'));
    Array.prototype.forEach.call(this.children, function (x) { x.classList.toggle('on', x === b); });
    toast('难度：' + b.textContent);
  });
  window.addEventListener('resize', layout);

  refreshScore(); initBoard();
  // 等一帧再量尺寸，确保 flex 布局完成
  requestAnimationFrame(layout);

  // 测试辅助（不影响正常玩法）
  window.__gomoku = {
    state: function () { return { over: over, turn: turn, moves: history.length, win: JSON.parse(JSON.stringify(win)) }; },
    place: function (x, y, c) { var r = place(x, y, c || BLACK); draw(); if (r && r !== 'draw') finish(c === BLACK ? 'player' : 'cpu', r); return r; },
    reset: initBoard
  };
})();
